import numpy as np
import pandas as pd
from sklearn.datasets import make_blobs#使用make_blobs进行knn分类
from sklearn.neighbors import KNeighborsClassifier#导入KNN分类器
import matplotlib.pyplot as plt
from sklearn.datasets import make_circles,make_moons
from scipy.io import loadmat
import pandas as pd


def minist():
    # #####################读取minist数据集###############################################
    m = loadmat("E:\\seminosiyclustering\\UCIdata\\2k2k.mat")
    data = np.hstack((m["fea"], m["gnd"]))
    data = pd.DataFrame(data)
    return data


######################################################################################
def dbmoon(N=100, d=-2, r=10, w=2):
    N1 = 10 * N
    w2 = w / 2
    done = True
    data = np.empty(0)
    while done:
        # generate Rectangular data
        tmp_x = 2 * (r + w2) * (np.random.random([N1, 1]) - 0.5)
        tmp_y = (r + w2) * np.random.random([N1, 1])
        tmp = np.concatenate((tmp_x, tmp_y), axis=1)
        tmp_ds = np.sqrt(tmp_x * tmp_x + tmp_y * tmp_y)
        # generate double moon data ---upper
        idx = np.logical_and(tmp_ds > (r - w2), tmp_ds < (r + w2))
        idx = (idx.nonzero())[0]

        if data.shape[0] == 0:
            data = tmp.take(idx, axis=0)
        else:
            data = np.concatenate((data, tmp.take(idx, axis=0)), axis=0)
        if data.shape[0] >= N:
            done = False
    #print(data)
    #print('~~~~~~~~~~~~~~~~~~~')
    db_moon = data[0:N, :]
    labels0=np.zeros(N)
    newdb_moon=np.insert(db_moon, 2, values=labels0, axis=1)
    #print(newdb_moon)
    print('~~~~~~~~~~~~~~~~~~~')
    # generate double moon data ----down
    data_t = np.empty([N, 2])
    data_t[:, 0] = data[0:N, 0] + r
    data_t[:, 1] = -data[0:N, 1] - d
    labels1 = np.ones(N)
    newdata_t = np.insert(data_t, 2, values=labels1, axis=1)
    db_moon = np.concatenate((newdb_moon,  newdata_t), axis=0)
    db_moon = pd.DataFrame(db_moon)
    print(db_moon)
    return db_moon


def threepoint():
    data1 = make_blobs(n_samples=1000, random_state=7, centers=[[-1, -1], [0, 0], [1, 1]], cluster_std=0.2)
    X, y = data1
    data = np.insert(X, 2, values=y, axis=1)
    data = pd.DataFrame(data)
    return data


def circles():
    X, y = make_circles(n_samples=400, factor=0.3, noise=.03)
    data = np.insert(X, 2, values=y, axis=1)
    data = pd.DataFrame(data)
    return data


def moons():
    X, y = make_moons(n_samples=500, noise=.03)
    data = np.insert(X, 2, values=y, axis=1)
    data = pd.DataFrame(data)
    return data
