import xlrd
from matplotlib import pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

fig = plt.figure()
ax = Axes3D(fig)


def read_excel_xlsACC(path):
    workbook = xlrd.open_workbook(path)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    k = np.arange(3, 40, 2)
    bata = np.arange(1, 70, 4)
    k,bata=np.meshgrid(k, bata)
    #z1=worksheet.col_values(2)[1:]
    zACC=[]
    for i in range(1, worksheet.nrows):
        z2 = worksheet.cell_value(i, 3)
        #z3 = worksheet.cell_value(i, 4)
        zACC.append(z2)
    #print(zACC)
    #print(type(zACC))
    #print(len(zACC))

    zACC=np.array(zACC)
    #print(type(zNMI))
    zACC=zACC.reshape(18,19)
    #print(zNMI)
    ax.plot_surface(k,bata, zACC, cmap='rainbow')
          # 设置三个坐标轴信息
    ax.set_xlabel('k', color='b')
    ax.set_ylabel('bata', color='g')
    ax.set_zlabel('ACC', color='r')

    plt.draw()
    plt.show()
    #plt.savefig('3D.jpg')

    print()

if __name__ == '__main__':
    path='F:\\python实验\\result\\result.xlsx'
    read_excel_xlsACC(path)
