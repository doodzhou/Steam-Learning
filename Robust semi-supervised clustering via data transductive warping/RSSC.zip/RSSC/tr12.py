import re
import sys
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.datasets import fetch_20newsgroups
from pprint import pprint
from sklearn.cluster import KMeans

import numpy as np
from numpy.matlib import rand
import matplotlib.pyplot as plt
import random
import pandas as pd
from noisyclustering import suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
     NMI, nosioutput_xls, plot, nosielabel
import random
import time
from compareway import kmeansspectral, getsssc, getsssc0, getrsec, duibinnosi_xls, getcpsssce

import numpy as np
from scipy.io import arff
import pandas as pd
import WECK.member_generation.library_generation as lg
import WECK.constrained_methods.generate_constraints_link as gcl
import WECK.ensemble.ensemble_wrapper as ew
import time
import numpy as np
from WECK.utils.deal_constrains import deal_constrains
from PCPSNMF import *


def loadcstr():

    data = pd.read_csv('E://Datasets1//tr12.txt', header=None)
    data = np.array(data)
    # a = [58, 94, 78, 54, 82]
    data1 = data[data[:, -1] == 78]  # 58
    data1[:, -1] = 0
    data2 = data[data[:, -1] == 54]  # 94
    data2[:, -1] = 1
    data3 = data[data[:, -1] == 82]  # 78
    data3[:, -1] = 2
    # data4 = data[data[:, -1] == 54]
    # data4[:, -1] = 3
    # data5 = data[data[:, -1] == 82]
    # data5[:, -1] = 4
    cleandata = np.concatenate((np.concatenate((data1, data2), axis=0), data3), axis=0)  # 选择的干净数据
    # cleandata = np.concatenate((np.concatenate((cleandata1, data4), axis=0), data5), axis=0)
    seleindex = []
    # a = [58, 94, 78, 54, 82]
    a = [78, 54, 82]
    for i in a:
        index1 = np.where(data[:, -1] == i)[0].tolist()
        seleindex.append(index1)
    seleindex = sum(seleindex, [])  # 选择的干净的数据下标
    allindex = np.arange(len(data))
    reind = np.delete(allindex, seleindex)  # 剩余数据的索引
    redata = data[reind, :]  # 剩余数据作为噪声数据
    b = [58,94,77, 95, 100]
    df2 = []
    # nosiydata= pd.DataFrame(nosiydata)
    for imi2 in b:
        index = np.random.choice(np.where(redata[:, -1] == imi2)[0], 8, replace=False)  # 从3-10标签里抽取20个
        df2.append(index.tolist())
    df2 = sum(df2, [])
    nosiydata = redata[df2, :]
    nosiydata = nosiydata[:, 0:-1]
    return cleandata, nosiydata


def noisenorl(semidata, data2to10, noisenum):
    noisematrix = data2to10
    randi = random.sample(range(0, len(semidata)), noisenum)  # 从mn个数中随机取noisenum个数,noisenum为其他数字图像个数
    noiseindx = []
    for iio in range(noisenum):
        semidata1 = np.insert(semidata, randi[iio], noisematrix[iio], 0)
        semidata = semidata1
        noiseindx.append(randi[iio])
    noiseimdata = semidata
    return noiseimdata, randi


if __name__ == '__main__':
    cluster_num = 4
    k = 9
    bata = 50
    cleandata, nosiydata = loadcstr()
    cleandata = pd.DataFrame(cleandata)
    np.random.shuffle(cleandata)
    (semidata1, label, inndex) = suTOsemi(cleandata, 0.9, 2)
    noiseimdata, randi = noisenorl(semidata1, nosiydata, 40)
    labelssize, labelC = nosielabel(cleandata, 40, randi, 2)
    start1 = time.clock()
    normalL = getWbyKNNnol(noiseimdata, k)
    Y = getkr(bata, normalL, inndex)
    newnormalL = getnewWbyKNNnol(Y, k)
    end1 = time.clock()
    print('RSSC运行时间是: %s Seconds' % (end1 - start1))
    # c, clf = mapspectral(newnormalL, cluster_num, labelC)
    c, clf = mapspectral(newnormalL, cluster_num, labelC)
    getMIhat, acc = NMI(labelC, c)

    lkmeans, lspectlar, lkdd, lhc = kmeansspectral(noiseimdata, cluster_num, labelC)
    start2 = time.clock()
    lsssc = getsssc(noiseimdata, labelC, label, cluster_num, inndex)
    end2 = time.clock()
    print('sssc运行时间是: %s Seconds' % (end2 - start2))

    # WECR K-MEANS
    baseclustering_NUM = 100
    data = noiseimdata
    targets = labelC
    start = time.clock()
    lg.generate_libs_by_sampling_rate('experidata', data, targets, cluster_num, baseclustering_NUM)
    gcl.generate_diff_amount_constraints_wrapper('experidata', data, targets)
    deal_constrains(['experidata'])
    d = noiseimdata
    t = targets
    class_num = cluster_num
    real_performances, acc_performances, constrain_performances, ensemble_labels_sets = ew.do_ensemble_different_constraints_new_exp(
        'experidata_30-60_0.7_0.7_100_FSRSNC_pure', d, t, class_num, True)
    end = time.clock()
    index = constrain_performances.index(np.max(constrain_performances))
    labels_sets = ensemble_labels_sets[index]
    print("the best gama=", index * 0.1 + 0.1)
    print("the constrain_performances=", np.max(constrain_performances))
    print("the NMI score=", real_performances[index])
    print("the acc score=", acc_performances[index])
    print('WECK运行时间是: %s Seconds' % (end - start))

    # PCPSNMF
    mu = 0.5
    alpha = 1  # % optimal
    per = 5
    kk = 4
    startpc = time.clock()
    W = myKNN(noiseimdata, k=4)
    # testlabel, Z = trtepr(per, labelsub, k, Trans_datasub, subN)
    Z = MClink(per, labelC)
    Vn, K = CSNMF(W, mu, kk, Z, alpha)
    label = np.argmax(Vn, axis=1)  # 得到Vn每行的最大值
    endpc = time.clock()
    newssc = maplabels(labelC, label)
    getMIhat1 = MIhat(labelC, newssc)
    acc1 = clustering_acc(labelC, newssc)
    print('PCPSNMF运行时间是: %s Seconds' % (endpc - startpc))
    print(getMIhat1, acc1)

    start3 = time.clock()
    lrsec = getrsec(noiseimdata, cluster_num, labelC)
    end3 = time.clock()
    print('RSEC运行时间是: %s Seconds' % (end3 - start3))