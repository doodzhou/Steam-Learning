import re
import sys


def arff2txt(filename):
    txtfile = open('E://Datasets1//tr12.txt','w')
    arr = []
    lines = []
    arff_file = open(filename)
    for line in arff_file:
        if not (line.startswith("@")):
            if not (line.startswith("%")):
                line = line.strip("\n")
                line = line.split(',')
                arr.append(line)

    del arr[0]
    for child in arr:
        print(child)
        del child[10]
        if child[9] == "True":
            child[9] = 1
        else:
            child[9] = 0
        lines.append('\t'.join(map(str,child)))
    result = '\n'.join(lines)
    print (result)

    txtfile.writelines(result)
    txtfile.close()

filename = 'E://Datasets1//tr12.arff'
arff2txt(filename)