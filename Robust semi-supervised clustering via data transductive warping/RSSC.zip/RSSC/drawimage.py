from sklearn.cluster import KMeans

from noisyclustering import loaddata, suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
     NMI, nosioutput_xls, plot,plot1,plot2, nosielabel,sp,noiserate
from RSEC import Rsec,baseCls
from getNMI import maplabels
from sssc import indicator, getnormal, eigensystem, getmab, getvac
from kdd import __latent_decomposition, fit_predict
from WECK.WECRkmeans import *
import matplotlib.pyplot as plt
import WECK.member_generation.library_generation as lg
import WECK.constrained_methods.generate_constraints_link as gcl
import WECK.ensemble.ensemble_wrapper as ew
import time
import numpy as np
from WECK.utils.deal_constrains import deal_constrains
from PCPSNMF import *
_noise_postfix = ['noise_n_0']


def plotRSEC(noiseimdata, C):
    mark = [ '*b', '*g', '*r','*k','*c',  '#FAA460', '#FFC0CB', '#DB7093', '#FF4500', '#FF6347', '#FF69B4']
    # 这里'or'代表中的'o'代表画圈，'r'代表颜色为红色，后面的依次类推
    color = 0
    j = 0
    for i in C:
        plt.plot([noiseimdata[j:j + 1, 0]], [noiseimdata[j:j + 1, 1]], mark[i], markersize=4)
        j += 1
    plt.title('RSEC', fontweight='bold')
    plt.show()


def plotSSSC(noiseimdata, C):
    mark = [ '*b', '*g', '*r','*k', '*c', '#FAA460', '#FFC0CB', '#DB7093', '#FF4500', '#FF6347', '#FF69B4']
    # 这里'or'代表中的'o'代表画圈，'r'代表颜色为红色，后面的依次类推
    color = 0
    j = 0
    for i in C:
        plt.plot([noiseimdata[j:j + 1, 0]], [noiseimdata[j:j + 1, 1]], mark[i], markersize=4)
        j += 1
    plt.title('SSSC', fontweight='bold')
    plt.show()


def plotRSC(noiseimdata, C):
    mark = [ '*b', '*g', '*r','*k', '*c', '#FAA460', '#FFC0CB', '#DB7093', '#FF4500', '#FF6347', '#FF69B4']
    # 这里'or'代表中的'o'代表画圈，'r'代表颜色为红色，后面的依次类推
    color = 0
    j = 0
    for i in C:
        plt.plot([noiseimdata[j:j + 1, 0]], [noiseimdata[j:j + 1, 1]], mark[i], markersize=4)
        j += 1
    plt.title('RSC', fontweight='bold')
    plt.show()


def plotWECR(noiseimdata, C):
    mark = [ '*b', '*g', '*r','*k', '*c', '#FAA460', '#FFC0CB', '#DB7093', '#FF4500', '#FF6347', '#FF69B4']
    # 这里'or'代表中的'o'代表画圈，'r'代表颜色为红色，后面的依次类推
    color = 0
    j = 0
    for i in C:
        plt.plot([noiseimdata[j:j + 1, 0]], [noiseimdata[j:j + 1, 1]], mark[i], markersize=4)
        j += 1
    plt.title('WECR k-means', fontweight='bold')
    plt.show()


def plottrue(noiseimdata, C):
    mark = [ '*b', '*g', '*r','*k', '*c', '#FAA460', '#FFC0CB', '#DB7093', '#FF4500', '#FF6347', '#FF69B4']
    # 这里'or'代表中的'o'代表画圈，'r'代表颜色为红色，后面的依次类推
    color = 0
    j = 0
    for i in C:
        plt.plot([noiseimdata[j:j + 1, 0]], [noiseimdata[j:j + 1, 1]], mark[i], markersize=4)
        j += 1
    plt.title('True clustering of noisy data', fontweight='bold')
    plt.show()


def plotPCPS(noiseimdata, C):
    mark = ['*b', '*g', '*r','*k', '*c', '#FAA460', '#FFC0CB', '#DB7093', '#FF4500', '#FF6347', '#FF69B4']
    # 这里'or'代表中的'o'代表画圈，'r'代表颜色为红色，后面的依次类推
    color = 0
    j = 0
    for i in C:
        plt.plot([noiseimdata[j:j + 1, 0]], [noiseimdata[j:j + 1, 1]], mark[i], markersize=4)
        j += 1
    plt.title('PCPSNMF', fontweight='bold')
    plt.show()

def plotkmeans(noiseimdata, C):
    mark = ['*b', '*g', '*r' ,'*k', '*c', '#FAA460', '#FFC0CB', '#DB7093', '#FF4500', '#FF6347', '#FF69B4']
    # 这里'or'代表中的'o'代表画圈，'r'代表颜色为红色，后面的依次类推
    color = 0
    j = 0
    for i in C:
        plt.plot([noiseimdata[j:j + 1, 0]], [noiseimdata[j:j + 1, 1]], mark[i], markersize=4)
        j += 1
    plt.title('k-means', fontweight='bold')
    plt.show()


def nosiydata(semidata1, data):
    (noiseimdata, noisearray, noisenum, randi) = uninoisenorl(semidata1, 0.4, 0, 40, 2)  # #1--高斯噪声，2--均匀噪声
    labelssize, labelC = nosielabel(data, noisenum, randi, 1)
    return noiseimdata, labelC,labelssize,noisenum


if __name__ == '__main__':
    cluster_num = 3
    # count = 0
    bata = 50
    k = 33
    datas = loaddata()
    (semidata1, label, inndex) = suTOsemi(datas, 0.9, 1)  # #1--标签在第一列，2--标签在最后一列
    noiseimdata, labelC, labelssize, noisenum = nosiydata(semidata1, datas)
    # clean data

    plottrue(noiseimdata,labelC)
    
    # RSSC
    normalL = getWbyKNNnol(noiseimdata, k)
    Y = getkr(bata, normalL, inndex)
    newnormalL = getnewWbyKNNnol(Y, k)
    c, clf = mapspectral(newnormalL, cluster_num, labelC)
    #plot1(noiseimdata, c)  # 只显示噪声数据，用一种颜色表示,
    plot(noiseimdata, c)  # 显示RSSC的聚类结果
    noisrate1 = noiserate(c, labelssize, labelC, noisenum)
    #print("噪声识别率为:",noisrate1)

    # 谱聚类
    newC = sp(noiseimdata,cluster_num, labelC)
    plot2(noiseimdata, newC)  # 显示谱聚类的聚类结果
    noisrate2 = noiserate(newC, labelssize, labelC, noisenum)
    
    # RSEC
    basecls = baseCls(noiseimdata, cluster_num, 100)
    labelsec = Rsec(basecls, cluster_num, 0.1, 0.01)
    newRsec = maplabels(labelC, labelsec)
    plotRSEC(noiseimdata, newRsec)  # 显示RSEC的聚类结果

    # SSSC
    jl, labelnum, unlabelnum = indicator(labelC, label, cluster_num, inndex)
    ws, normals = getnormal(noiseimdata)
    vectors = eigensystem(normals, cluster_num)
    mab = getmab(vectors, jl, labelnum, cluster_num)
    ssc = getvac(vectors, mab, jl, unlabelnum, cluster_num, ws)
    newssc = maplabels(labelC, ssc)
    plotSSSC(noiseimdata, newssc)  # 显示SSSC的聚类结果

    # RSC
    Ag, Ac, H = __latent_decomposition(noiseimdata,cluster_num)
    labels = fit_predict(Ag, Ac, H,cluster_num)
    newlabels = maplabels(labelC, labels)
    plotRSC(noiseimdata, newlabels)  # 显示RSC的聚类结果

    #WECR K-MEANS
    baseclustering_NUM = 100
    data = noiseimdata
    targets = labelC
    lg.generate_libs_by_sampling_rate('experidata',data, targets,cluster_num,baseclustering_NUM)
    gcl.generate_diff_amount_constraints_wrapper('experidata',data, targets)
    deal_constrains(['experidata'])
    d= noiseimdata
    t = targets
    class_num = cluster_num
    real_performances, acc_performances, constrain_performances, ensemble_labels_sets = ew.do_ensemble_different_constraints_new_exp('experidata_15-30_0.7_0.7_100_FSRSNC_pure', d, t, class_num,True)
    index = constrain_performances.index(np.max(constrain_performances))
    labels_sets = ensemble_labels_sets[index]
    labels_set=[]
    for i in labels_sets[0]:
        labels_set.append(i)
    plotWECR(noiseimdata, labels_set)


    # PCPSNMF
    mu = 0.5
    alpha = 1  # % optimal
    per = 5
    kk = 4
    W = myKNN(noiseimdata, k=4)
    # testlabel, Z = trtepr(per, labelsub, k, Trans_datasub, subN)
    Z = MClink(per, labelC)
    Vn, K = CSNMF(W, mu, kk, Z, alpha)
    label = np.argmax(Vn, axis=1)  # 得到Vn每行的最大值
    newssc = maplabels(labelC, label)
    # getMIhat = MIhat(labelC, newssc)
    # acc = clustering_acc(labelC, newssc)
    # print(getMIhat, acc)
    plotPCPS(noiseimdata, newssc)

    # k-means
    estimator = KMeans(n_clusters=cluster_num)  # 构造聚类器
    estimator.fit(noiseimdata)  # 聚类
    label_pred = estimator.labels_
    newkmeans = maplabels(labelC, label_pred)
    plotkmeans(noiseimdata,newkmeans)





