import numpy as np
from sklearn.cluster import KMeans

# @SEMI-SUPERVISED SPECTRAL CLUSTERING文章 2018


# ####################生成指示向量,得到每个类有标签的数量和无标签的数量#################################
def indicator(labelC,  label, cluster_num, inndex):
    # label:  标签信息
    # labelC：添加噪声之后的噪声标签
    # cluster_num：最后得到的聚类数，因为有噪声，所以聚类数+1
    # inndex:有标签数据的索引号

    # ###################1、生成指示向量##############################
    unit = np.unique(labelC)  # #原数据有多个类
    jl = np.zeros((len(labelC), cluster_num))  # 为jl定义len(noiseimdata)行cluster_num列的数组用以存放指示向量,最后1列全为0
    inndex = inndex.reshape((1, len(inndex)))  # 有标签的索引号
    label = label.values.reshape((1, len(label)))  # 标签值
    numlist = []
    for i in range(inndex.shape[1]):
        small = [inndex[0, i], label[0, i]]
        numlist.append(small)  # 将索引号和对应的标签值组成列表
    numindex = [[] for _ in range(len(unit))]  # 同时创建cluster_num个空列表，用以存放不同的标签值对应的索引
    for iu1 in range(len(unit)):
        for ju in range(inndex.shape[1]):
            if numlist[ju][1] == unit[iu1]:
                numindex[iu1].append(numlist[ju][0])  # 此时每个numindex列表中存放的是不同的标签对应的索引
    for iu2 in range(len(unit)-1):
        for inum in range(len(numindex[iu2])):
            jl[numindex[iu2][inum], iu2] = 1  # 此时指示向量生成j[l]a=1:表示a类中有标签的数据表示为1

    # ###################2、得到每个类有标签的数量 ###########################
    labelnum = [[] for _ in range(len(unit)-1)]  # 存放有标签的数量
    for ila in range(len(unit)-1):
        labelnum[ila].append(len(numindex[ila]))
    lastlable = [0]
    labelnum.append(lastlable)  # 此时有标签的数量为[[a1],[a2],...[0]],[0]为噪声数据，它的有标签的数量为0

    # ###################3、得到无标签的数量#################################
    sumlabel = [[] for _ in range(len(unit))]  # 每个标签的总数量
    for isum in range(len(unit)):
        sumlabel[isum].append(labelC.tolist().count(unit[isum]))
    unlabelnum = [[] for _ in range(len(unit))]  # 每个类中没有标签的数量
    for unl in range(len(unit)):
        unlabelnum[unl].append(sumlabel[unl][0] - labelnum[unl][0])
    return jl, labelnum, unlabelnum


def metrics(a, b):
    return np.linalg.norm(a - b)


def gaussian(x, mu, p):
    return np.exp(- metrics(mu, x) ** 2 / p)


def getnormal(noiseimdata):
    # #######################得到权重矩阵W#####
    N = len(noiseimdata)
    p = noiseimdata.shape[1]
    W = np.zeros((N, N))
    for i in range(N):
        for j in range(N):
            W[i][j] = gaussian(noiseimdata[i], noiseimdata[j], p)
            W[j][i] = W[i][j]  # mutually

# ##########得到标准化的拉普拉斯矩阵########
    # compute the Degree Matrix: D=sum(W)
    D = np.sum(W, axis = 0)
    # compute the Laplacian Matrix: L=D-W
    L = np.diag(D) - W
    # normailze
    # D^(-1/2) L D^(-1/2)
    sqrtDegreeMatrix = np.diag(1.0 / (D ** (0.5)))
    ws = np.dot(np.dot(sqrtDegreeMatrix, W), sqrtDegreeMatrix)
    normals = np.dot(np.dot(sqrtDegreeMatrix, L), sqrtDegreeMatrix)
    return ws, normals


# #############计算normals的前k+1个最小的特征值及特征向量（k为聚类的簇数）######################
def eigensystem(normals, cluster_num):
    eigval, eigvec = np.linalg.eig(normals)
    inds = np.argsort(eigval)[:cluster_num + 1:1]  # 取前k+1个最小的特征值
    vectors = eigvec[:, inds]  # 前k+1个最小的特征值对应的特征向量 v0,v1,'''vk
    # eigvec = Vectors / np.linalg.norm(Vectors, axis=1, keepdims=True)
    return vectors


# ###################a, b =1, ··· ,k, 定义m[a][b]#######################################
def getmab(vectors, jl, labelnum, cluster_num):  # cluster_num为得到的聚类数
    mab = np.zeros((cluster_num, cluster_num), dtype = complex)
    for a in range(cluster_num-1):
        for b in range(cluster_num-1):
            mab[a][b] = np.dot(vectors[:, a + 1], jl[:, b]) / labelnum[b][0]  # 得到一个数
    return mab


# ####################a =1, ··· ,k, compute ˆva #########################################
def getvac(vectors, mab, jl, unlabelnum, cluster_num, ws):
    va = np.zeros((len(vectors), cluster_num))
    for a in range(cluster_num):
        for b in range(cluster_num):
            va[:, a] = mab[a, b] * jl[:, b] + unlabelnum[a][0] * vectors[:, a + 1]
    #va = (ws*va)/np.linalg.norm((ws*va), axis=1)[:, None]
    va = np.dot(ws, va)/np.linalg.norm(np.dot(ws, va))
# ####################用kmeans聚类#########################################################
    clf = KMeans(n_clusters=cluster_num)
    s = clf.fit(va.real)  # .real
    ssc = s.labels_
    return ssc
