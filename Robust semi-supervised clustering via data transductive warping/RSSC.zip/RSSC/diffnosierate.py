from noisyclustering import loaddata, suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
    noiserate, NMI, nosioutput_xls, plot, nosielabel
import numpy as np
from compareway import kmeansspectral, duibioutput_xls

# ##########################本方法添加不同的噪声比所得出的结果###############################
cluster_num = 4
lparament = []
lgetNMI = []
lacc = []
levaluation = []
lnoisrate = []
data = loaddata()
(semidata1, label, inndex) = suTOsemi(data, 0.9, 2)  ##1--标签在第一列，2--标签在最后一列
# M,C=MClink(5, 5,labels)
for norate in np.arange(0, 1.1, 0.1):
    norate = float(format(norate, '.1f'))
    (noiseimdata, noisearray, noisenum, randi) = uninoisenorl(semidata1, norate, 2, 8, 2)  ##1--高斯噪声，2--均匀噪声
    # xls_path = 'F:\\python实验\\result\\seeds-dataset\\result3.xlsx'
    labelC = nosielabel(data, noisenum, randi, 2)
    ##############################本方法########################################
    lparament.append(norate)  ##########参数组成的总列表
    lacc = []
    print(norate)
    # for k in np.arange(30, 40, 1):
    # for bata in np.arange(30, 55, 5):
    k = 33
    bata = 50
    normalL = getWbyKNNnol(noiseimdata, k)
    Y = getkr(bata, normalL, inndex)
    newnormalL = getnewWbyKNNnol(Y, k)
    c, clf = mapspectral(newnormalL, cluster_num)
    if norate == 0:
        noisratelist = [0, 0, 0]
    else:
        noisratelist, x0, x1, x2, x3 = noiserate(noiseimdata, noisearray, c)
    getMIhat, acc = NMI(labelC, c)  ##1--标签在第一列，2--标签在最后一列
    lgetNMI.append(getMIhat)  #############NMI组成的总列表
    lacc.append(acc)  #####################acca组成的总列表
    leval = [getMIhat, acc]
    levaluation.append(leval)
    lnoisrate.append(noisratelist)  ###########噪声识别率组成的总列表
nosioutput_xls( lparament, levaluation, lnoisrate)
