import numpy as np
from sklearn.datasets import fetch_20newsgroups
selected_categories = [
    'comp.graphics',
    'rec.motorcycles',
    'rec.sport.baseball',
    'misc.forsale',
    'sci.electronics',
    'sci.med',
    'talk.politics.guns',
    'talk.religion.misc']
# 加载数据集
newsgroups_train=fetch_20newsgroups(subset='train',
                                    categories=selected_categories,
                                    remove=('headers','footers','quotes'))
train_texts=newsgroups_train['data']
train_labels=newsgroups_train['target']
print(train_texts)
print(train_labels)