import math
import random
from turtle import pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from syntheticdata import moons, threepoint, circles
from getNMI import MIhat, clustering_acc, maplabels
from numpy.matlib import rand, size, full, mat
from sklearn import preprocessing
# from parament import ax  # ,out,bata, k,
from mpl_toolkits.mplot3d import Axes3D
import pandas as pd
import xlsxwriter as xlwt
import openpyxl
from sklearn.neighbors import kneighbors_graph
import networkx as nx


# #########################读取数据##############################3


def loaddata():  # 读取数据
    data = pd.read_csv('E:\\seminosiyclustering\\UCIdata\\seeds_dataset.txt',header=None, delim_whitespace=True)#3个类，10~20
    # data = pd.read_csv('E:\\pendigits\\pendigits(test).txt', header=None)
    # data =
    return data


# ##########################获取半监督数据###########################
def suTOsemi(data, alpha, type):
    # 此函数的功能是把有标记的数据集转换成半监督的数据集
    # data：为有标记的数据集
    # % alpha： 为样本转换成无标记的比例, 无标记的数据所占样本的比例
    # type的类型: 1 - --标签在第一列
    # 2 - ---标签在最后一列
    # data = data.getA()
    # data =data.astype('float')###########把矩阵转换成数组
    (m, n) = data.shape  # data数据的大小
    if type == 1:
        labels = data.iloc[:, 0]  # % 取data数据集的标签，标签在第一列
    elif type == 2:
        labels = data.iloc[:, n - 1]  # % 取data数据集的标签，标签在最后一列
    labels = np.array(labels)
    # ################如果标签不是数字，把标签换成数字
    cl = np.unique(labels)
    nl = cl.shape[0]
    for il in range(m):
        for ic in range(nl):
            if labels[il] == cl[ic]:
                labels[il] = ic
    ##########################################
    labels = labels.astype('float')
    nolab1 = math.ceil(alpha * m)  # % % 半监督里无标记的数据远远大于有标记的数据
    nolab = random.sample(range(0, m), nolab1)  # 从1~m中随机生成nolab个随机数
    # sn,sm=nolab.shape
    # if type == 1:
    for ino in range(nolab1):
        labels[nolab[ino]] = np.NaN
        # data[nolab[ino],0] = np.NaN  # 对半监督中无标签的数据置空值*******************
    # elif type == 2:
    #    for ino in range(nolab1):
    #        labels2[nolab[ino]] = np.NaN
    labels = pd.DataFrame(labels)
    labels = labels.iloc[:, 0]
    labels = labels.astype(float)
    idex1 = range(m)  # #数据总的对应的行号
    idex2 = labels.index[np.where(np.isnan(labels))[0]]  # #无标签的数据对应的行号
    inndex = np.delete(idex1, idex2)  # 有标签的数据对应的行号
    if type == 1:
        semidata = data.iloc[:, 1:n]  # ##########标签在第一列时半监督数据
    elif type == 2:
        semidata = data.iloc[:, 0:n - 1]  # #############标签在最后一列时半监督数据
    semidata = semidata.values  # #将dataframe转换成数组
    label = labels.dropna(axis=0, how='all')  # ##########带有标签的数据（值和行号）

    return semidata, label, inndex


'''
#####################输出勿连和必连数据###########################
def MClink(nM, nC,labels):
    u = np.unique(labels)
    k = len(u)

    ##############输出 must - link
    M = []
    label = labels.dropna(axis=0, how='all')
    u = np.unique(label)
    for i in range(k):  # k为聚类的个数
        idx = label[label.values == u[i]].index
        #res_list = list(combinations(idx, 2))
        res_list = list(product(idx, idx))
        ran_li = random.sample(res_list, nM)
        M.append(ran_li)####################M为必连数据的索引号，如下所示，每nM个为一个list，总共有k个list,构成一个大的list
        # [[(7, 40), (7, 10), (1, 5), (7, 33), (5, 40)],
         #[(75, 97), (73, 115), (97, 115), (73, 97), (75, 115)],
         #[(134, 176), (133, 134), (134, 137), (133, 176), (133, 137)]]

    ##############输出 cannot - link
    A = []
    for i1 in range(k):
        idx = label[label.values == u[i1]].index
        A.append(idx)
        A1 = list(combinations(A, 2))
        C = []
        # idx2=label[label.values == u[j1]].index
        for i2 in range(len(A1)):
            li = list(product(A1[i2][0], A1[i2][1]))
            ran_li2 = random.sample(li, nC)
            C.append(ran_li2)###########C为勿连数据，不同的类之间产生nC个数据，nC个为一个list，如下所示
            #[[(30, 115), (30, 97), (5, 73), (10, 97), (1, 115)],
            #[(1, 176), (40, 133), (1, 134), (5, 133), (10, 137)],
            #[(75, 134), (73, 137), (73, 176), (97, 137), (102, 137)]]

    return M, C
'''


# #########################输出噪声数据和标准的拉普拉斯矩阵##############################
def uninoisenorl(semidata, ratio, a, b, type2):
    # 此函数的功能是产生均匀噪声和加入噪声数据的数据总标签 % % % % % % %
    # ratio: 数据集中添加噪声数据的比例
    # type1 - -1: 添加高斯噪声 z = a + b. * rand(m, n):a为均值，b为方差
    # type - -2: 添加均匀分布的噪声：z = a + (b - a) * rand(M, N);
    (mn, nn) = semidata.shape
    # semidata = semidata.values#####将dataframe形式转为数组
    noisenum = math.ceil(ratio * mn)  # #添加的噪声的数量
    # noisematrix = np.mat(np.zeros((noisenum, nn)))  # 随机从m行中产生noisenum行，n列的矩阵
    if type2 == 1:
        noisematrix = a + b * rand(noisenum, nn)
    elif type2 == 2:
        noisematrix = a + (b - a) * rand(noisenum, nn)
    noisearray = np.array(noisematrix)  # ####将矩阵转为数组
    # print(noisearray)
    randi = random.sample(range(0, mn), noisenum)  # 从mn个数中随机取noisenum个数
    noiseindx = []
    for iio in range(noisenum):
        semidata = np.insert(semidata, randi[iio], noisearray[iio], 0)
        noiseindx.append(randi[iio])
    noiseimdata = semidata  # #########数组形式

    return noiseimdata, noisearray, noisenum, randi

# ######################得到噪声标签#########################################


def nosielabel(data, noisenum, randi, type):
    (md, nd) = data.shape  # data数据的大小
    if type == 1:
        labelC = data.iloc[:, 0]  # % 取data数据集的标签，标签在第一列
    elif type == 2:
        labelC = data.iloc[:, nd - 1]  # % 取data数据集的标签，标签在最后一列
    labelC = np.array(labelC)

    # ################如果标签不是数字，把标签换成数字，是数字从0开始
    clc = np.unique(labelC)
    nlc = clc.shape[0]
    for ilc in range(md):
        for icc in range(nlc):
            if labelC[ilc] == clc[icc]:
                labelC[ilc] = icc
    labelssize = clc.shape[0]
    for iio in range(noisenum):
        labelC = np.insert(labelC, randi[iio], labelssize, 0)  # ###########已知标签，把噪声数据的标签设为最后一个数
    return labelssize, labelC



# ############################求出标准的拉普拉斯#####################
def getWbyKNNnol(noiseimdata, k):  # ############## 利用KNN获得相似度矩阵
    A = kneighbors_graph(X=noiseimdata, n_neighbors=k, metric='euclidean', include_self=False, mode='connectivity')
    A = A.maximum(A.T)
    A = A.todense()
    A = A.A
    D = np.sum(A, axis=1)
    laplacianMatrix = np.diag(D) - A
    # laplacianMatrix =laplacianMatrix = D - A
    sqrtDegreeMatrix = np.diag(1.0 / (D ** (0.5)))
    normalL = np.dot(np.dot(sqrtDegreeMatrix, laplacianMatrix), sqrtDegreeMatrix)
    return normalL


# #########################获得转换后的向量Y####################################
def getkr(bata, normalL, inndex):
    # ##############bata为参数
    eigla, eigv = np.linalg.eig(normalL)  # normal的特征值eigla和特征向量eigv
    ml = len(eigla)
    I = np.mat(np.eye(ml, ml, dtype=int))
    Kr = np.linalg.pinv(normalL)
    S = np.mat(np.zeros((ml, ml)))
    mi = len(inndex)
    for i in range(mi):
        S[inndex[i], inndex[i]] = 1
    Y0 = np.linalg.inv(I + bata * np.linalg.pinv(Kr)) * (S * I)
    min_max_scaler = preprocessing.MinMaxScaler()
    Y = min_max_scaler.fit_transform(Y0)  # 把Y0缩放到[0,1]区间

    return Y


# ###################得到新的标准化的拉普拉斯矩阵###########################

def getnewWbyKNNnol(Y, k):  # ############## 利用KNN获得相似度矩阵
    newA = kneighbors_graph(X=Y, n_neighbors=k, metric='euclidean', include_self=False, mode='connectivity')
    newA = newA.maximum(newA.T)
    newAF = newA.todense()
    newAF = newAF.A
    newDF = np.sum(newAF, axis=1)
    newlaplacianMatrix = np.diag(newDF) - newAF
    # laplacianMatrix =laplacianMatrix = D - A
    newsqrtDegreeMatrix = np.diag(1.0 / (newDF ** (0.5)))
    newnormalL = np.dot(np.dot(newsqrtDegreeMatrix, newlaplacianMatrix), newsqrtDegreeMatrix)

    return newnormalL


# ###################聚类##################################
def mapspectral(newnormalL, cluster_num, labelC):
    # k为聚类的个数
    # eigval, eigvec = eigsh(newnormalL, cluster_num, D, which='SM')
    eigval, eigvec = np.linalg.eig(newnormalL)
    inds = np.argsort(eigval)[:cluster_num]  # [1:cluster_num+1:1]
    Vectors = eigvec[:, inds]
    # eigvec = Vectors / np.linalg.norm(Vectors, axis=1, keepdims=True)
    eigvec = Vectors / np.linalg.norm(Vectors, axis=1)[:, None]
    clf = KMeans(n_clusters=cluster_num)
    # if(isinstance(eigvec, complex)):  # 判断是否虚数
    #   eigvec = abs(eigvec)
    s = clf.fit(eigvec.real)  # .real
    C = s.labels_
    C = maplabels(labelC, C)  # #将噪声标签都对应在最后一个类
    # print(C)
    return C, clf


# ####################计算噪声比###########################
def noiserate(C, labelssize, labelC, noisenum):
    # #labelC为原来的含有噪声的标签
    # #C为聚类之后的标签
    # #labelssize：把噪声的标签设为最后一个数字
    labelC=labelC.tolist()
    C = C.tolist()
    count=0
    for ino in range(len(C)):
        if(labelC[ino]==C[ino]==labelssize):  # 如果两个标签对应位置的数字都为最后一个数字，则为识别的噪声标签
              count=count+1 # 识别噪声的数量
    noisrate=count/noisenum
    print(noisrate)
    return noisrate


# ####################绘图#################################
def plot(noiseimdata, C):
    mark = ['*r', '*b', '*g', '*k', '*y', '*c', '*m', '1r', '1b', '1g','1y']
    # 这里'or'代表中的'o'代表画圈，'r'代表颜色为红色，后面的依次类推
    color = 0
    j = 0
    for i in C:
        plt.plot([noiseimdata[j:j + 1, 0]],[noiseimdata[j:j + 1, 1]], mark[i], markersize=4)
        j += 1
    plt.show()


def getCenters(data, C):  # 获得中心位置
    centers = []
    for i in range(max(C) + 1):
        points_list = np.where(C == i)[0].tolist()
        centers.append(np.average(data[points_list], axis=0))
    return centers


# #####################计算NMI#############################

def NMI(labelC, c):
    getMIhat = MIhat(labelC, c)
    print(getMIhat)
    acc = clustering_acc(labelC, c)
    print(acc)
    # evaluation = [getMIhat, acc]
    # print(evaluation)
    return getMIhat, acc


# ####################将参数结果输出到表格中############################
def output_xls(lpara, levaluation, lnoisrate):
    book = xlwt.Workbook('E:\\seminosiyclustering\\result\\notebank\\result1.xlsx')  # 创建一个Excel
    sheet1 = book.add_worksheet('result')
    sheet1.write(0, 0, 'bata')
    sheet1.write(0, 1, 'k')
    sheet1.write(0, 2, 'getMIhat')
    sheet1.write(0, 3, 'acc')
    sheet1.write(0, 4, 'noisratelist')
    for ibata in range(len(lpara)):
        sheet1.write(ibata + 1, 0, lpara[ibata][0])  # 如果label是中文一定要解码
        sheet1.write(ibata + 1, 1, lpara[ibata][1])
        sheet1.write(ibata + 1, 2, levaluation[ibata][0])
        sheet1.write(ibata + 1, 3, levaluation[ibata][1])
        sheet1.write(ibata + 1, 4, max(lnoisrate[ibata]))
    # book.save(xls_path)
    book.close()  # 创建保存文件


# ##########将噪声比结果输出到表格中
# ##inoosphere,iris,plrx,seeds-dataset,fertitity,wine,ecoli,glass,breast
def nosioutput_xls(lpara, levaluation, lnoisrate):
    book = xlwt.Workbook('E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result1ccccccccccc.xlsx')  # 创建一个Excel
    sheet1 = book.add_worksheet('result')
    sheet1.write(0, 0, 'norate')
    sheet1.write(0, 1, 'nmi')
    sheet1.write(0, 2, 'acc')
    sheet1.write(0, 3, 'maxnoisrate')
    for ibata in range(len(lpara)):
        sheet1.write(ibata + 1, 0, lpara[ibata])  # 如果label是中文一定要解码
        sheet1.write(ibata + 1, 1, levaluation[ibata][0])
        sheet1.write(ibata + 1, 2, levaluation[ibata][1])
        sheet1.write(ibata + 1, 3, max(lnoisrate[ibata]))
    # book.save(xls_path)
    book.close()  # 创建保存文件


# ###################调用自定义函数运行############################

if __name__ == '__main__':
    cluster_num = 4
    data = loaddata()
    (semidata1, label, inndex) = suTOsemi(data, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列
    # M,C=MClink(5, 5,labels)
    (noiseimdata, noisearray, noisenum, randi) = uninoisenorl(semidata1, 0.4,10,20, 2)  # #1--高斯噪声，2--均匀噪声
    xls_path = 'F:\\python实验\\result\\seeds-dataset\\result5.xlsx'
    labelssize, labelC = nosielabel(data, noisenum, randi, 2)  # #1--标签在第一列，2--标签在最后一列
    # count = 0
    lparament = []
    lgetNMI = []
    lacc = []
    levaluation = []
    lnoisrate = []
    bata = 50
    k = 33
    # for bata in np.arange(1,70,4):#(500,5500,500):(1,70,4)
    #  for k in np.arange(3, 40, 2):
    # bata = out[item, 1]
    lpara = [bata, k]
    lparament.append(lpara)  # #########参数组成的总列表
    print(bata, k)
    normalL = getWbyKNNnol(noiseimdata, k)
    Y = getkr(bata, normalL, inndex)
    newnormalL = getnewWbyKNNnol(Y, k)
    c, clf = mapspectral(newnormalL, cluster_num, labelC)
    noisrate = noiserate(c, labelssize, labelC, noisenum)
    getMIhat, acc = NMI(labelC, c)
    lgetNMI.append(getMIhat)  # ############NMI组成的总列表
    lacc.append(acc)  # ####################acca组成的总列表
    leval = [getMIhat, acc]
    levaluation.append(leval)  # ##########评判指标组成的总列表
    lnoisrate.append(noisrate)  # ##########噪声识别率组成的总列表
    # output_xls(xls_path, lparament, levaluation, lnoisrate)
    # validation_accuracies=[lpara,noisratelist,evaluation]
    # print(validation_accuracies)
#    centers = getCenters(noiseimdata, c)

    plot(noiseimdata, c)

