from cgitb import text
from gettext import find

import xlrd
from matplotlib import pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle
from mpl_toolkits.mplot3d import Axes3D


# #######################读取第一个result1表###################################
def read_excel_xls1(path1):
    workbook = xlrd.open_workbook(path1)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI1 = []
    zACC1 = []
    zNoise1 = []
    for i2 in range(1, worksheet.nrows):
        nmi1 = worksheet.cell_value(i2, 1)
        zNMI1.append(nmi1)
        acc1 = worksheet.cell_value(i2, 2)
        zACC1.append(acc1)
    zNMI1 = np.array(zNMI1)
    zACC1 = np.array(zACC1)
    return zNMI1, zACC1


# #######################读取第二个result1表###################################
def read_excel_xls2(path2):
    workbook = xlrd.open_workbook(path2)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI2 = []
    zACC2 = []
    zNoise2 = []
    for i2 in range(1, worksheet.nrows):
        nmi2 = worksheet.cell_value(i2, 1)
        zNMI2.append(nmi2)
        acc2 = worksheet.cell_value(i2, 2)
        zACC2.append(acc2)
    zNMI2 = np.array(zNMI2)
    zACC2 = np.array(zACC2)
    return zNMI2, zACC2


# #######################读取第三个result1表###################################
def read_excel_xls3(path3):
    workbook = xlrd.open_workbook(path3)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI3 = []
    zACC3 = []
    zNoise3 = []
    for i3 in range(1, worksheet.nrows):
        nmi3 = worksheet.cell_value(i3, 1)
        zNMI3.append(nmi3)
        acc3 = worksheet.cell_value(i3, 2)
        zACC3.append(acc3)
    zNMI3 = np.array(zNMI3)
    zACC3 = np.array(zACC3)
    return zNMI3, zACC3


# #######################读取第四个result1表###################################
def read_excel_xls4(path4):
    workbook = xlrd.open_workbook(path4)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI4 = []
    zACC4 = []
    zNoise4 = []
    for i4 in range(1, worksheet.nrows):
        nmi4 = worksheet.cell_value(i4, 1)
        zNMI4.append(nmi4)
        acc4 = worksheet.cell_value(i4, 2)
        zACC4.append(acc4)
    zNMI4 = np.array(zNMI4)
    zACC4 = np.array(zACC4)
    return zNMI4, zACC4


# #######################读取第五个result1表###################################
def read_excel_xls5(path5):
    workbook = xlrd.open_workbook(path5)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI5 = []
    zACC5 = []
    for i5 in range(1, worksheet.nrows):
        nmi5 = worksheet.cell_value(i5, 1)
        zNMI5.append(nmi5)
        acc5 = worksheet.cell_value(i5, 2)
        zACC5.append(acc5)
    zNMI5 = np.array(zNMI5)
    zACC5 = np.array(zACC5)
    return zNMI5, zACC5


# #######################读取第一个对比算法评判标准的数据##############################
def read_diffno_xls1(nopath1):
    workbook = xlrd.open_workbook(nopath1)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    kNMI1 = []
    kACC1 = []
    sNMI1 = []
    sACC1 = []
    kddNMI1 = []
    kddACC1 = []
    hcNMI1 = []
    hcACC1 = []
    ssscNMI1 = []
    ssscACC1 = []
    rescNMI1 = []
    rescACC1 = []
    cpsssceNMI1 = []
    cpsssceACC1 = []
    PCPSNMFNMI = []
    PCPSNMFACC = []
    for ino in range(1, worksheet.nrows):
        knmi = worksheet.cell_value(ino, 1)
        kNMI1.append(knmi)
        acc5 = worksheet.cell_value(ino, 2)
        kACC1.append(acc5)
        snmi = worksheet.cell_value(ino, 3)
        sNMI1.append(snmi)
        sacc = worksheet.cell_value(ino, 4)
        sACC1.append(sacc)
        kddnmi = worksheet.cell_value(ino, 5)
        kddNMI1.append(kddnmi)
        kddacc = worksheet.cell_value(ino, 6)
        kddACC1.append(kddacc)
        hcnmi = worksheet.cell_value(ino, 7)
        hcNMI1.append(hcnmi)
        hcacc = worksheet.cell_value(ino, 8)
        hcACC1.append(hcacc)
        sssnmi = worksheet.cell_value(ino, 9)
        ssscNMI1.append(sssnmi)
        ssscacc = worksheet.cell_value(ino, 10)
        ssscACC1.append(ssscacc)
        rescnmi = worksheet.cell_value(ino, 11)
        rescNMI1.append(rescnmi)
        rescacc = worksheet.cell_value(ino, 12)
        rescACC1.append(rescacc)
        cpssscenmi = worksheet.cell_value(ino, 15)
        cpsssceNMI1.append(cpssscenmi)
        cpsssceacc = worksheet.cell_value(ino, 16)
        cpsssceACC1.append(cpsssceacc)
        pcpsnmi = worksheet.cell_value(ino, 17)
        PCPSNMFNMI.append(pcpsnmi)
        pcpsacc = worksheet.cell_value(ino, 18)
        PCPSNMFACC.append(pcpsacc)
    kNMI1 = np.array(kNMI1)
    kACC1 = np.array(kACC1)
    sNMI1 = np.array(sNMI1)
    sACC1 = np.array(sACC1)
    kddNMI1 = np.array(kddNMI1)
    kddACC1 = np.array(kddACC1)
    hcNMI1 = np.array(hcNMI1)
    hcACC1 = np.array(hcACC1)
    ssscNMI1 = np.array(ssscNMI1)
    ssscACC1 = np.array(ssscACC1)
    rescNMI1 = np.array(rescNMI1)
    rescACC1 = np.array(rescACC1)
    cpsssceNMI1 = np.array(cpsssceNMI1)
    cpsssceACC1 = np.array(cpsssceACC1)
    pcpsNMI1 = np.array(PCPSNMFNMI)
    pcpsACC1 = np.array(PCPSNMFACC)
    return kNMI1, kACC1, sNMI1, sACC1, kddNMI1, kddACC1,hcNMI1, hcACC1, ssscNMI1,ssscACC1,rescNMI1,rescACC1,cpsssceNMI1,cpsssceACC1,pcpsNMI1,pcpsACC1


# #####################读取第二个对比评判标准表############################3
def read_diffno_xls2(nopath2):
    workbook = xlrd.open_workbook(nopath2)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    kNMI2 = []
    kACC2 = []
    sNMI2 = []
    sACC2 = []
    kddNMI2 = []
    kddACC2 = []
    hcNMI2 = []
    hcACC2 = []
    ssscNMI2 = []
    ssscACC2 = []
    rescNMI2 = []
    rescACC2 = []
    cpsssceNMI2 = []
    cpsssceACC2 = []
    for ino in range(1, worksheet.nrows):
        knmi = worksheet.cell_value(ino, 1)
        kNMI2.append(knmi)
        kacc= worksheet.cell_value(ino, 2)
        kACC2.append(kacc)
        snmi = worksheet.cell_value(ino, 3)
        sNMI2.append(snmi)
        sacc = worksheet.cell_value(ino, 4)
        sACC2.append(sacc)
        kddnmi = worksheet.cell_value(ino, 5)
        kddNMI2.append(kddnmi)
        kddacc = worksheet.cell_value(ino, 6)
        kddACC2.append(kddacc)
        hcnmi = worksheet.cell_value(ino, 7)
        hcNMI2.append(hcnmi)
        hcacc = worksheet.cell_value(ino, 8)
        hcACC2.append(hcacc)
        sssnmi = worksheet.cell_value(ino, 9)
        ssscNMI2.append(sssnmi)
        ssscacc = worksheet.cell_value(ino, 10)
        ssscACC2.append(ssscacc)
        rescnmi = worksheet.cell_value(ino, 11)
        rescNMI2.append(rescnmi)
        rescacc = worksheet.cell_value(ino, 12)
        rescACC2.append(rescacc)
        cpssscenmi = worksheet.cell_value(ino, 15)
        cpsssceNMI2.append(cpssscenmi)
        cpsssceacc = worksheet.cell_value(ino, 16)
        cpsssceACC2.append(cpsssceacc)
    kNMI2 = np.array(kNMI2)
    kACC2 = np.array(kACC2)
    sNMI2 = np.array(sNMI2)
    sACC2 = np.array(sACC2)
    kddNMI2 = np.array(kddNMI2)
    kddACC2= np.array(kddACC2)
    hcNMI2 = np.array(hcNMI2)
    hcACC2 = np.array(hcACC2)
    ssscNMI2 = np.array(ssscNMI2)
    ssscACC2 = np.array(ssscACC2)
    rescNMI2 = np.array(rescNMI2)
    rescACC2 = np.array(rescACC2)
    cpsssceNMI2 = np.array(cpsssceNMI2)
    cpsssceACC2 = np.array(cpsssceACC2)

    return kNMI2, kACC2, sNMI2, sACC2, kddNMI2, kddACC2, hcNMI2, hcACC2, ssscNMI2,ssscACC2,rescNMI2,rescACC2,cpsssceNMI2,cpsssceACC2


# #####################读取第三个对比评判标准表############################3
def read_diffno_xls3(nopath3):
    workbook = xlrd.open_workbook(nopath3)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    kNMI3 = []
    kACC3 = []
    sNMI3 = []
    sACC3 = []
    kddNMI3 = []
    kddACC3 = []
    hcNMI3 = []
    hcACC3 = []
    ssscNMI3 = []
    ssscACC3 = []
    rescNMI3 = []
    rescACC3 = []
    cpsssceNMI3 = []
    cpsssceACC3 = []
    for ino in range(1, worksheet.nrows):
        knmi = worksheet.cell_value(ino, 1)
        kNMI3.append(knmi)
        kacc = worksheet.cell_value(ino, 2)
        kACC3.append(kacc)
        snmi = worksheet.cell_value(ino, 3)
        sNMI3.append(snmi)
        sacc = worksheet.cell_value(ino, 4)
        sACC3.append(sacc)
        kddnmi = worksheet.cell_value(ino, 5)
        kddNMI3.append(kddnmi)
        kddacc = worksheet.cell_value(ino, 6)
        kddACC3.append(kddacc)
        hcnmi = worksheet.cell_value(ino, 7)
        hcNMI3.append(hcnmi)
        hcacc = worksheet.cell_value(ino, 8)
        hcACC3.append(hcacc)
        sssnmi = worksheet.cell_value(ino, 9)
        ssscNMI3.append(sssnmi)
        ssscacc = worksheet.cell_value(ino, 10)
        ssscACC3.append(ssscacc)
        rescnmi = worksheet.cell_value(ino, 11)
        rescNMI3.append(rescnmi)
        rescacc = worksheet.cell_value(ino, 12)
        rescACC3.append(rescacc)
        cpssscenmi = worksheet.cell_value(ino, 15)
        cpsssceNMI3.append(cpssscenmi)
        cpsssceacc = worksheet.cell_value(ino, 16)
        cpsssceACC3.append(cpsssceacc)
    kNMI3 = np.array(kNMI3)
    kACC3 = np.array(kACC3)
    sNMI3 = np.array(sNMI3)
    sACC3 = np.array(sACC3)
    kddNMI3 = np.array(kddNMI3)
    kddACC3= np.array(kddACC3)
    hcNMI3 = np.array(hcNMI3)
    hcACC3 = np.array(hcACC3)
    ssscNMI3 = np.array(ssscNMI3)
    ssscACC3 = np.array(ssscACC3)
    rescNMI3 = np.array(rescNMI3)
    rescACC3 = np.array(rescACC3)
    cpsssceNMI3 = np.array(cpsssceNMI3)
    cpsssceACC3 = np.array(cpsssceACC3)
    return kNMI3, kACC3, sNMI3, sACC3, kddNMI3, kddACC3, hcNMI3, hcACC3, ssscNMI3,ssscACC3,rescNMI3,rescACC3,cpsssceNMI3,cpsssceACC3


# #####################读取第四个对比评判标准表############################3
def read_diffno_xls4(nopath4):
    workbook = xlrd.open_workbook(nopath4)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    kNMI4 = []
    kACC4 = []
    sNMI4 = []
    sACC4= []
    kddNMI4 = []
    kddACC4 = []
    hcNMI4 = []
    hcACC4 = []
    ssscNMI4 = []
    ssscACC4 = []
    rescNMI4 = []
    rescACC4 = []
    cpsssceNMI4 = []
    cpsssceACC4 = []
    for ino in range(1, worksheet.nrows):
        knmi = worksheet.cell_value(ino, 1)
        kNMI4.append(knmi)
        kacc = worksheet.cell_value(ino, 2)
        kACC4.append(kacc)
        snmi = worksheet.cell_value(ino, 3)
        sNMI4.append(snmi)
        sacc = worksheet.cell_value(ino, 4)
        sACC4.append(sacc)
        kddnmi = worksheet.cell_value(ino, 5)
        kddNMI4.append(kddnmi)
        kddacc = worksheet.cell_value(ino, 6)
        kddACC4.append(kddacc)
        hcnmi = worksheet.cell_value(ino, 7)
        hcNMI4.append(hcnmi)
        hcacc = worksheet.cell_value(ino, 8)
        hcACC4.append(hcacc)
        sssnmi = worksheet.cell_value(ino, 9)
        ssscNMI4.append(sssnmi)
        ssscacc = worksheet.cell_value(ino, 10)
        ssscACC4.append(ssscacc)
        rescnmi = worksheet.cell_value(ino, 11)
        rescNMI4.append(rescnmi)
        rescacc = worksheet.cell_value(ino, 12)
        rescACC4.append(rescacc)
        cpssscenmi = worksheet.cell_value(ino, 15)
        cpsssceNMI4.append(cpssscenmi)
        cpsssceacc = worksheet.cell_value(ino, 16)
        cpsssceACC4.append(cpsssceacc)
    kNMI4 = np.array(kNMI4)
    kACC4 = np.array(kACC4)
    sNMI4 = np.array(sNMI4)
    sACC4 = np.array(sACC4)
    kddNMI4 = np.array(kddNMI4)
    kddACC4= np.array(kddACC4)
    hcNMI4 = np.array(hcNMI4)
    hcACC4 = np.array(hcACC4)
    ssscNMI4 = np.array(ssscNMI4)
    ssscACC4 = np.array(ssscACC4)
    rescNMI4 = np.array(rescNMI4)
    rescACC4 = np.array(rescACC4)
    cpsssceNMI4 = np.array(cpsssceNMI4)
    cpsssceACC4 = np.array(cpsssceACC4)
    return kNMI4,kACC4,sNMI4,sACC4,kddNMI4,kddACC4, hcNMI4, hcACC4, ssscNMI4,ssscACC4,rescNMI4,rescACC4,cpsssceNMI4,cpsssceACC4


# #####################读取第五个对比评判标准表############################3
def read_diffno_xls5(nopath5):
    workbook = xlrd.open_workbook(nopath5)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    kNMI5 = []
    kACC5 = []
    sNMI5 = []
    sACC5 = []
    kddNMI5 = []
    kddACC5 = []
    hcNMI5 = []
    hcACC5 = []
    ssscNMI5 = []
    ssscACC5 = []
    rescNMI5 = []
    rescACC5 = []
    cpsssceNMI5 = []
    cpsssceACC5 = []
    for ino in range(1, worksheet.nrows):
        knmi = worksheet.cell_value(ino, 1)
        kNMI5.append(knmi)
        kacc = worksheet.cell_value(ino, 2)
        kACC5.append(kacc)
        snmi = worksheet.cell_value(ino, 3)
        sNMI5.append(snmi)
        sacc = worksheet.cell_value(ino, 4)
        sACC5.append(sacc)
        kddnmi = worksheet.cell_value(ino, 5)
        kddNMI5.append(kddnmi)
        kddacc = worksheet.cell_value(ino, 6)
        kddACC5.append(kddacc)
        hcnmi = worksheet.cell_value(ino, 7)
        hcNMI5.append(hcnmi)
        hcacc = worksheet.cell_value(ino, 8)
        hcACC5.append(hcacc)
        sssnmi = worksheet.cell_value(ino, 9)
        ssscNMI5.append(sssnmi)
        ssscacc = worksheet.cell_value(ino, 10)
        ssscACC5.append(ssscacc)
        rescnmi = worksheet.cell_value(ino, 11)
        rescNMI5.append(rescnmi)
        rescacc = worksheet.cell_value(ino, 12)
        rescACC5.append(rescacc)
        cpssscenmi = worksheet.cell_value(ino, 15)
        cpsssceNMI5.append(cpssscenmi)
        cpsssceacc = worksheet.cell_value(ino, 16)
        cpsssceACC5.append(cpsssceacc)
    kNMI5 = np.array(kNMI5)
    kACC5 = np.array(kACC5)
    sNMI5 = np.array(sNMI5)
    sACC5 = np.array(sACC5)
    kddNMI5 = np.array(kddNMI5)
    kddACC5= np.array(kddACC5)
    hcNMI5 = np.array(hcNMI5)
    hcACC5 = np.array(hcACC5)
    ssscNMI5 = np.array(ssscNMI5)
    ssscACC5 = np.array(ssscACC5)
    rescNMI5 = np.array(rescNMI5)
    rescACC5 = np.array(rescACC5)
    cpsssceNMI5 = np.array(cpsssceNMI5)
    cpsssceACC5 = np.array(cpsssceACC5)
    return kNMI5, kACC5, sNMI5, sACC5, kddNMI5, kddACC5, hcNMI5, hcACC5, ssscNMI5,ssscACC5,rescNMI5,rescACC5,cpsssceNMI5,cpsssceACC5


# ###########对比算法的平均值##################
def averageduibi(kNMI1, kACC1, sNMI1, sACC1, kddNMI1, kddACC1,hcNMI1, hcACC1, ssscNMI1,ssscACC1,rescNMI1,rescACC1 ,cpsssceNMI1,cpsssceACC1,pcpsNMI1,pcpsACC1,\
                 kNMI2, kACC2, sNMI2, sACC2, kddNMI2, kddACC2, hcNMI2, hcACC2, ssscNMI2,ssscACC2,rescNMI2,rescACC2,cpsssceNMI2,cpsssceACC2,\
                 kNMI3, kACC3, sNMI3, sACC3, kddNMI3, kddACC3, hcNMI3, hcACC3, ssscNMI3,ssscACC3,rescNMI3,rescACC3,cpsssceNMI3,cpsssceACC3,\
                 kNMI4, kACC4, sNMI4, sACC4, kddNMI4, kddACC4, hcNMI4, hcACC4, ssscNMI4,ssscACC4,rescNMI4,rescACC4,cpsssceNMI4,cpsssceACC4,\
                 kNMI5, kACC5, sNMI5, sACC5, kddNMI5, kddACC5, hcNMI5, hcACC5, ssscNMI5,ssscACC5,rescNMI5,rescACC5,cpsssceNMI5,cpsssceACC5):
    aveknmi =( kNMI1+kNMI2+kNMI3+kNMI4+kNMI5) / 5
    avekacc = (kACC1+kACC2+kACC3+kACC4+kACC5)/ 5
    avesnmi = (sNMI1+sNMI2+sNMI3+sNMI4+sNMI5) / 5
    avesacc = (sACC1+sACC2+sACC3+sACC4+sACC5) / 5
    avekddnmi = (kddNMI1+kddNMI2+kddNMI3+kddNMI4+kddNMI5) / 5
    avekddacc = (kddACC1+kddACC2+kddACC3+kddACC4+kddACC5) / 5
    avehcnmi = (hcNMI1+hcNMI2+hcNMI3+hcNMI4+hcNMI5)/5
    avehcacc = (hcACC1+hcACC2+hcACC3+hcACC4+hcACC5)/5
    avessscnmi = (ssscNMI1+ssscNMI2+ssscNMI3+ssscNMI4+ssscNMI5)/5
    avessscacc = (ssscACC1+ssscACC2+ssscACC3+ssscACC4+ssscACC5)/5
    averescnmi = (rescNMI1+rescNMI2+rescNMI3+rescNMI4+rescNMI5)/5
    averescacc = (rescACC1+rescACC2+rescACC3+rescACC4+rescACC5)/5
    avecpssscenmi = (cpsssceNMI1+cpsssceNMI2+cpsssceNMI3+cpsssceNMI4+cpsssceNMI5)/5
    avecpsssceacc = (cpsssceACC1+cpsssceACC2+cpsssceACC3+cpsssceACC4+cpsssceACC5)/5
    avgpcpsNMI1, avgpcpsACC1 = pcpsNMI1,pcpsACC1
    print(avecpssscenmi,avecpsssceacc)
    return aveknmi, avekacc, avesnmi, avesacc, avekddnmi, avekddacc,avehcnmi,avehcacc,avessscnmi,avessscacc,averescnmi,averescacc,avecpssscenmi,avecpsssceacc,avgpcpsNMI1,avgpcpsACC1


# #######################求原方法5个值的平均值################################
def average(zNMI1, zACC1, zNMI2, zACC2, zNMI3, zACC3, zNMI4, zACC4, zNMI5, zACC5):
    aveNMI = (zNMI1 + zNMI2 + zNMI3 + zNMI4 + zNMI5) / 5
    aveACC = (zACC1 + zACC2 + zACC3 + zACC4 + zACC5) / 5
    return aveNMI, aveACC


# #######################画出三维图######################################
def plot(aveNMI, aveACC, aveknmi, avekacc, avesnmi, avesacc, avekddnmi, avekddacc,avehcnmi,avehcacc,avessscnmi,avessscacc,averescnmi,averescacc,avecpssscenmi,avecpsssceacc,avgpcpsNMI1,avgpcpsACC1):
    norate = np.arange(0, 1.1, 0.1)  # 3, 40, 2)
    # ######################在同一个图中####################
    plt.figure(1)
    plt.plot(norate, aveNMI, color='red', label='RSSC', ls='solid', marker='*', markersize=9, linewidth=3)   # ls或linestyle
    plt.plot(norate, aveknmi, color='#87CEFA', label='K-means', ls='solid', marker='*', markersize=9, linewidth=3)  # , linewidth=2
    plt.plot(norate, avesnmi, color='blue', label='SC', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, avekddnmi, color='orange', label='RSC', ls='solid', marker='*', markersize=9, linewidth=3)
    #plt.plot(norate, avehcnmi, color='#DB7093', label='HC', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, avessscnmi, color='#DDA0DD', label='SSSC', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, averescnmi, color='#4682b4', label='RSEC', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, avecpssscenmi, color='#8A2BE2', label=' WECR k-means', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, avgpcpsNMI1, color='#2F4F4F', label=' PCPSNMF', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.grid(color="k", linestyle=":", axis='y')
    #plt.legend(loc='upper center', bbox_to_anchor=(0.5,1.15),ncol=4,borderaxespad=0,fancybox=True,shadow=True)
    plt.tick_params(labelsize=12)
    plt.xlabel('The ratio of random noise r', fontsize=14)
    plt.ylabel('NMI', fontsize = 14)

    plt.figure(2)
    plt.plot(norate, aveACC, color='red', label='RSSC', ls='solid', marker='*', markersize=9,linewidth=3)  # ls或linestyle
    plt.plot(norate, avekacc, color='#87CEFA', label='K-means', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, avesacc, color='blue', label='SC', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, avekddacc, color='orange', label='RSC', ls='solid', marker='*', markersize=9, linewidth=3)
    #plt.plot(norate, avehcacc, color='#DB7093', label='HC', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, avessscacc, color='#DDA0DD', label='SSSC', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, averescacc, color='#4682b4', label='RSEC', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, avecpsssceacc, color='#8A2BE2', label='WECR k-means', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, avgpcpsACC1, color='#2F4F4F', label='PCPSNMF', ls='solid', marker='*', markersize=9,
             linewidth=3)
    plt.grid(color="grey", linestyle=":", axis='y')
    #plt.legend(loc='upper center', bbox_to_anchor=(0.5,1.15),ncol=4,borderaxespad=0,fancybox=True,shadow=True)
    plt.tick_params(labelsize=12)
    plt.xlabel('The ratio of random noise r', fontsize = 14)
    plt.ylabel('ACC', fontsize = 14)
    plt.draw()
    plt.show()
    print()

def plotlegend():
    norate = np.arange(0,0.0001)  # 3, 40, 2)

    plt.plot(norate,  color='red', label='RSSC', ls='solid', marker='*', markersize=9,linewidth=3)  # ls或linestyle
    plt.plot(norate, color='#87CEFA', label='K-means', ls='solid', marker='*', markersize=9,linewidth=3)  # , linewidth=2
    plt.plot(norate, color='blue', label='SC', ls='solid', marker='*', markersize=9,linewidth=3)
    plt.plot(norate, color='orange', label='RSC', ls='solid', marker='*', markersize=9,linewidth=3)
    # plt.plot(norate, avehcnmi, color='#DB7093', label='HC', ls='solid', marker='*', markersize=9, linewidth=3)
    plt.plot(norate, color='#DDA0DD', label='SSSC', ls='solid', marker='*', markersize=9,linewidth=3)
    plt.plot(norate, color='#4682b4', label='RSEC', ls='solid', marker='*', markersize=9,linewidth=3)
    plt.plot(norate, color='#8A2BE2', label=' WECR k-means', ls='solid', marker='*', markersize=9,linewidth=3)
    plt.plot(norate,color='#2F4F4F', label=' PCPSNMF', ls='solid', marker='*', markersize=9,linewidth=3)
    plt.legend(loc='upper center',  ncol=8, borderaxespad=3, fancybox=True, shadow=True)
    plt.axis('off')
    plt.show()


if __name__ == '__main__':
    # #iris,seeds-dataset colum3d
    path1 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result1.xlsx'
    path2 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result2.xlsx'
    path3 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result3.xlsx'
    path4 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result4.xlsx'
    path5 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result5.xlsx'
    nopath1 = 'E:\\seminosiyclustering\\result\\duibisuanfa\\colum3d\\result1.xlsx'
    nopath2 = 'E:\\seminosiyclustering\\result\\duibisuanfa\\colum3d\\result2.xlsx'
    nopath3 = 'E:\\seminosiyclustering\\result\\duibisuanfa\\colum3d\\result3.xlsx'
    nopath4 = 'E:\\seminosiyclustering\\result\\duibisuanfa\\colum3d\\result4.xlsx'
    nopath5 = 'E:\\seminosiyclustering\\result\\duibisuanfa\\colum3d\\result5.xlsx'
    zNMI1, zACC1 = read_excel_xls1(path1)
    zNMI2, zACC2 = read_excel_xls1(path2)
    zNMI3, zACC3 = read_excel_xls1(path3)
    zNMI4, zACC4 = read_excel_xls1(path4)
    zNMI5, zACC5 = read_excel_xls1(path5)
    aveNMI, aveACC = average(zNMI1, zACC1, zNMI2, zACC2, zNMI3, zACC3,
                             zNMI4, zACC4, zNMI5, zACC5)
    kNMI1, kACC1, sNMI1, sACC1, kddNMI1, kddACC1,hcNMI1, hcACC1, ssscNMI1,ssscACC1,rescNMI1,rescACC1,cpsssceNMI1,cpsssceACC1,pcpsNMI1,pcpsACC1 = read_diffno_xls1(nopath1)
    kNMI2, kACC2, sNMI2, sACC2, kddNMI2, kddACC2, hcNMI2, hcACC2, ssscNMI2,ssscACC2,rescNMI2,rescACC2,cpsssceNMI2,cpsssceACC2 = read_diffno_xls2(nopath2)
    kNMI3, kACC3, sNMI3, sACC3, kddNMI3, kddACC3, hcNMI3, hcACC3, ssscNMI3,ssscACC3,rescNMI3,rescACC3,cpsssceNMI3,cpsssceACC3 = read_diffno_xls3(nopath3)
    kNMI4,kACC4,sNMI4,sACC4,kddNMI4,kddACC4, hcNMI4, hcACC4, ssscNMI4,ssscACC4,rescNMI4,rescACC4,cpsssceNMI4,cpsssceACC4 = read_diffno_xls4(nopath4)
    kNMI5, kACC5, sNMI5, sACC5, kddNMI5, kddACC5, hcNMI5, hcACC5, ssscNMI5,ssscACC5,rescNMI5,rescACC5,cpsssceNMI5,cpsssceACC5 = read_diffno_xls5(nopath5)
    aveknmi, avekacc, avesnmi, avesacc, avekddnmi, avekddacc,avehcnmi,avehcacc,avessscnmi,avessscacc,averescnmi,averescacc,avecpssscenmi,avecpsssceacc,avgpcpsnmi,avgpcpsacc = averageduibi(kNMI1, kACC1, sNMI1, sACC1, kddNMI1, kddACC1,hcNMI1, hcACC1, ssscNMI1,ssscACC1,rescNMI1,rescACC1 ,cpsssceNMI1,cpsssceACC1,pcpsNMI1,pcpsACC1,\
                                                                kNMI2, kACC2, sNMI2, sACC2, kddNMI2, kddACC2, hcNMI2, hcACC2, ssscNMI2,ssscACC2,rescNMI2,rescACC2,cpsssceNMI2,cpsssceACC2,\
                                                                kNMI3, kACC3, sNMI3, sACC3, kddNMI3, kddACC3, hcNMI3, hcACC3, ssscNMI3,ssscACC3,rescNMI3,rescACC3,cpsssceNMI3,cpsssceACC3,\
                                                                kNMI4,kACC4,sNMI4,sACC4,kddNMI4,kddACC4, hcNMI4, hcACC4, ssscNMI4,ssscACC4,rescNMI4,rescACC4,cpsssceNMI4,cpsssceACC4,\
                                                                kNMI5, kACC5, sNMI5, sACC5, kddNMI5, kddACC5, hcNMI5, hcACC5, ssscNMI5,ssscACC5,rescNMI5,rescACC5,cpsssceNMI5,cpsssceACC5)
    plot(aveNMI, aveACC, aveknmi, avekacc, avesnmi, avesacc, avekddnmi, avekddacc,avehcnmi,avehcacc,avessscnmi,avessscacc,averescnmi,averescacc,avecpssscenmi,avecpsssceacc,avgpcpsnmi,avgpcpsacc)
    # togplot(aveNMI, aveACC, aveNoise)
    #plotlegend()
