import numpy as np
from sklearn.cluster import KMeans
from noisyclustering import loaddata, suTOsemi,uninoisenorl,nosielabel
from getNMI import maplabels, MIhat, clustering_acc


# ######################首先构造标准化的拉普拉斯矩阵##################################
def euclidDistance(x1, x2, sqrt_flag=False):
    res = np.sum((x1-x2)**2)
    if sqrt_flag:
        res = np.sqrt(res)
    return res


def getnormal(noiseimdata,k,sigma):
    S = np.zeros((len(noiseimdata), len(noiseimdata)))
    for i in range(len(noiseimdata)):
        for j in range(i+1, len(noiseimdata)):
            S[i][j] = 1.0 * euclidDistance(noiseimdata[i], noiseimdata[j])
            S[j][i] = S[i][j]
    # #######################得到权重矩阵W#####
    N = len(S)
    A = np.zeros((N, N))

    for i in range(N):
        dist_with_index = zip(S[i], range(N))
        dist_with_index = sorted(dist_with_index, key=lambda x: x[0])
        neighbours_id = [dist_with_index[m][1] for m in range(k + 1)]  # xi's k nearest neighbours

        for j in neighbours_id:  # xj is xi's neighbour
            A[i][j] = np.exp(-S[i][j] / 2 / sigma / sigma)
            A[j][i] = A[i][j]  # mutually

    # ##########得到标准化的拉普拉斯矩阵########
    # compute the Degree Matrix: D=sum(W)
    D = np.sum(A, axis=0)
    # compute the Laplacian Matrix: L=D-W
    L = np.diag(D) - A
    # normailze
    # D^(-1/2) L D^(-1/2)
    sqrtDegreeMatrix = np.diag(1.0 / (D ** (0.5)))
    ws = np.dot(np.dot(sqrtDegreeMatrix, A), sqrtDegreeMatrix)
    normals = np.dot(np.dot(sqrtDegreeMatrix, L), sqrtDegreeMatrix)
    return normals


# ######################构造prior matrix D矩阵#################################
def pmd(noiseimdata, cluster_num):
    nd = len(noiseimdata)
    D1 = np.zeros(nd, nd)
    dl = np.ones(cluster_num, cluster_num)
    for idl in range(cluster_num):
        dl[idl, idl] = 0
    for id1 in range(cluster_num):
        for id2 in range(cluster_num):
            D1[id1, id2] = dl[id1, id2]
    return D1


# ########################Obtain P by solving (4) using Algorithm 2###########
def solverHHYP(D, Q, L, Y, alpha, bata):
    P = np.zeros(len(D), len(D));
    # temp = H + Lambd / alpha;
    temp = Q - (Y + L) / alpha
    for ip in range(len(D)):
        for jp in range(len(D)):
            if D[ip, jp] == 0:
                P[ip, jp] = temp
            else:
                P[ip, jp] = np.sign(temp)*max(abs(temp)-bata*D[ip, jp]/alpha, 0)
    return P


# ########################This subroutine solves the capped simplex projection problem####
def cappedsimplexprojection(y0,k):
    n = len(y0)
    x = np.zeros((n,1))
    if (k < 0) or (k > n):
        print('the sum constraint is infeasible!')
    if k == 0:
        e = 0.5 * sum((x - y0)*(x - y0))
    if k == n:
        x = np.ones((n, 1))
        e = 0.5 * sum((x - y0)*(x - y0))
    idx = np.argsort(y0.T)  # 将y0按升序排列
    y = y0[idx]
    # Test the possiblity of a == b are integers
    if k == np.round(k):
        b = n - k
        if y(b + 1) - y(b) >= 1:
            x[idx[:,b + 1:n],:] = 1
            e = 0.5 * sum((x - y0)*(x - y0))
    # Assume a=0.
    s = np.cumsum(y)
    y = np.vstack(y, np.array([float("inf")]))
    for b in range(n):
        # Hypothesized gamma.
        gamma = (k+b-n-s[b]) / b
        if ((y[0]+gamma) > 0) and ((y(b)+gamma) < 1) and ((y(b+1)+gamma) >= 1):
            xtmp = np.vstack((y[0:b, :]+gamma, np.ones(n-b-1, 1)))
            e = 0.5 * sum((x - y0)*(x - y0))
    # Now a>=1
    for a in range(n):
        for b in range(a+1, n):
            # Hypothesized gamma.
            gamma = (k + b - n + s[a] - s[b]) / (b - a)
            if ((y[a] + gamma) <= 0) and ((y[a + 1] + gamma) > 0) and ((y[b] + gamma) < 1) and ((y[b + 1] + gamma) >= 1):
                xtmp = np.vstack(np.vstack(np.ones((a, 1)), y[a+1:b,:]), np.ones((n-b-1, 1)))
                x[idx] = xtmp
                e = 0.5 * sum((x - y0)*(x - y0))
    return x


# ########################Update Q by solving (11)#############################
def project_fantope(Q, k):
    U, D = np.linalg.eig(Q)
    Dr = cappedsimplexprojection(np.diag(D), k)
    X = np.dot(np.dot(U, np.diag(Dr)), U.T)
    return X


# #######################得到P矩阵############################################
def Pmartrix(L, D, k, bata):
    tol = 1e-4
    max_iter = 500
    rho = 1.05
    mu = 1e-4
    max_mu = 1e10
    DEBUG = 0
    n = len(L)
    P = np.zeros(n, n)
    Q = P
    Y = P
    iter = 0
    for iter in range(1,max_iter+1):
        Pk = P
        Qk = Q
        # update P
        # P = prox_l1(Q - (Y + L) / mu, lambda /mu);
        P = solverHHYP(D, Q, L, Y, mu, bata)

        # update Q
        temp = P + Y / mu
        temp = (temp + temp.T)/2
        Q = project_fantope(temp, k)
        dY = P - Q
        chgP = max(max(abs(Pk - P)))
        chgQ = max(max(abs(Qk - Q)))
        chg = max(chgP, chgQ, max(abs(dY)))
        if DEBUG:
            if iter == 1 or iter % 10 == 0:
                obj = np.trace(np.dot(P.T, L))+ bata*np.linalg.norm(Q, ord=1, axis=0)
                err = np.linalg.norm(dY)  # 求的时F范数
        if chg < tol:
            break
        Y = Y + np.dot(mu, dY)
        mu = min(rho*mu, max_mu)
        DQ = D *Q
        obj = np.trace(np.dot(P.T, L))+ bata*np.linalg.norm(DQ, ord=1, axis=0)
    return P


def cluster(P, cluster_num):
    evv, V = np.linalg.eig(P)
    sorted_indices = np.argsort(evv)  # 对特征值按升序排列
    V = V[:, sorted_indices[:-cluster_num - 1:-1]]  # 取前k个最大的特征向量
    V = V.real
    labels = KMeans(n_clusters=cluster_num).fit(V).labels_
    return labels


if __name__ == '__main__':

    cluster_num = 4
    data = loaddata()
    (semidata1, label, inndex) = suTOsemi(data, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列
    # M,C=MClink(5, 5,labels)
    (noiseimdata, noisearray, noisenum, randi) = uninoisenorl(semidata1, 0.4, -2.5, 2.5, 2)
    normals = getnormal(noiseimdata)
    D = pmd(noiseimdata, cluster_num)
    P = Pmartrix(normals, D, cluster_num, 1)
    labelssize, labelC = nosielabel(data, noisenum, randi, 2)
    labels = cluster(P, cluster_num)
    newssc = maplabels(labelC, labels)
    getMIhat5 = MIhat(labelC, newssc)
    acc5 = clustering_acc(labelC, newssc)
    lsssc = [getMIhat5, acc5]
    print(lsssc)