import math
import random
from turtle import pd
import numpy as np
from sklearn.cluster import KMeans
from numpy.matlib import rand, size, full, mat
from svt import _sv_thresh
from noisyclustering import loaddata, suTOsemi,uninoisenorl,nosielabel
from getNMI import maplabels, MIhat, clustering_acc


# ########首先得到基本分区 basic partitions###############################
# this function is used to generate N base clusterings for ensemble clustering
# where k is range of [k,sqrt(n)]
# cluster_num为最后的聚类数
# N为base clustering number，最初值设为100
def baseCls(noiseimdata, cluster_num, N):
    n = noiseimdata.shape[0]  # 行数
    upperk = max(cluster_num, math.floor(np.sqrt(n)))  # upperK的取cluster_num,和 math.floor(np.sqrt(n))的最大值
    clsnums = np.random.randint(cluster_num, upperk, N).reshape((N, 1))  # 生成[cluster_num, upperK]范围内的N行1列的数组
    clsnums = np.random.randint(50, 100, N).reshape((N, 1)).reshape((N, 1))
    basecls = np.zeros((n, N))  # 定义n行N列全为0的数组
    for i in range(N):
        basecls[:, i] = KMeans(n_clusters=clsnums[i][0]).fit(noiseimdata).labels_
    return basecls


# ##################谱聚类sc#######################################
def sc(S, cluster_num):
    ns = len(S)
    D = np.sum(S, axis=0)  # 对列求和
    D = np.diag(1.0 / (D ** (0.5)))
    L = np.dot(np.dot(D, S), D)  # L是标准化的拉普拉斯
    if len(L) > 500:
        evv, V = np.linalg.eig(L)
        sorted_indices = np.argsort((abs(evv)))  # 对特征值的绝对值按升序排列
        V = V[:, sorted_indices[:-cluster_num - 1:-1]]  # 取前k个最大的特征向量
        V = V.real
    else:
        evv, V = np.linalg.eig(L)
        sorted_indices = np.argsort(evv)  # 对特征值按升序排列
        V = V[:, sorted_indices[:-cluster_num - 1:-1]]  # 取前k个最大的特征向量
        V = V.real
    sq_sum = np.sqrt(np.sum(np.multiply(V, V), axis=1))
    U = V/np.tile(sq_sum.reshape((len(V), 1)), (1, cluster_num))
    labels = KMeans(n_clusters=cluster_num).fit(U).labels_
    return labels


# #############完成主体函数的聚类###########################################
# This function is for Robust Spectral Ensemble Clustering, which is described
def Rsec(basecls, cluster_num, lambda1, lambda2):
    [nb, mb] = basecls.shape  # nb的大小也等于数据集的大小
    #  obtain co-assocition matrix
    S = np.zeros((nb, nb))
    for im in range(mb):
        tmpIDX = basecls[:, im]
        S = S+(((np.tile(tmpIDX.reshape((nb, 1)), (1, nb))-np.tile(tmpIDX.T, (nb, 1))) == 0)+0)
    S = S*1.0/mb

    # initialize
    J = np.zeros((nb, nb))
    Z = np.zeros((nb, nb))
    E = np.zeros((nb, nb))
    Y1 = np.zeros((nb, nb))
    Y2 = np.zeros((nb, nb))
    H = np.zeros((nb, cluster_num))
    mu = 10  # 一个参数
    p = 1.2  # p>1
    t = 1
    Dz = np.eye(nb)
    oldobj = 1e200
    obj = 1e100
    while oldobj>obj:
        # updata J
        tmp = Z + 1/mu*Y2
        if np.linalg.norm(tmp) > 0:
            u, s, v = _sv_thresh(tmp, lambda1/mu,cluster_num)
            s = np.diag(s)
            J = np.dot(np.dot(u, s), v)
        # updata Z
        Dsqrt = np.linalg.inv((Dz ** (0.5)))
        part1 = np.linalg.inv(np.dot(S, S.T)+np.eye(nb))
        part2 = np.dot(S, S.T)+J-np.dot(S.T, E)
        part3 = np.dot(np.dot(np.dot(Dsqrt, H), H.T), Dsqrt)
        part4 = part2+(1/mu)*part3
        Z = np.dot(part1, part4)
        # updata E
        Q = S - S*Z+Y1/mu
        tmp = np.zeros((1, nb))
        for jm in range(nb):
            nq = np.linalg.norm(Q[jm, :])
            if nq > lambda2/mu:
                tmp[:, jm] = (nq - lambda2/mu)/nq
        for ie in range(nb):
            E[ie, ie] = tmp[0, ie]
        # 计算 Dz和Lz
        Lz = (Z + Z.T)/2 + np.dot(H, H.T)
        Dz = np.diag(np.sum(Lz, axis=1))  # 对数组的行求和
        # Set H(t+1) as the smallest K eigenvectors of Lz
        eigval, eigvec = np.linalg.eig(Lz)
        inds = np.argsort(eigval)[:cluster_num]
        H = eigvec[:, inds]  # 取前cluster_num个最小的值对应的特征向量
        # Update the Lagrangian multipliers
        tmp = S - S*Z-E
        Y1 = Y1 + mu * tmp
        Y2 = Y2 + mu*(Z-J)

        oldobj = obj
        obj = np.linalg.norm(tmp)/np.linalg.norm(S)

        # set mu,t
        mu = p*mu
        t = t+1
    label = sc(Z, cluster_num)
    return label


if __name__ == '__main__':

    cluster_num = 4
    data = loaddata()
    (semidata1, label, inndex) = suTOsemi(data, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列
    # M,C=MClink(5, 5,labels)
    (noiseimdata, noisearray, noisenum, randi) = uninoisenorl(semidata1, 0.4, -2.5, 2.5, 2)
    basecls = baseCls(noiseimdata, cluster_num, 100)
    label = Rsec(basecls, cluster_num, 0.1, 0.01)
    labelssize, labelC = nosielabel(data, noisenum, randi, 2)
    newssc = maplabels(labelC, label)
    getMIhat5 = MIhat(labelC, newssc)
    acc5 = clustering_acc(labelC, newssc)
    lsssc = [getMIhat5, acc5]
    print(lsssc)
