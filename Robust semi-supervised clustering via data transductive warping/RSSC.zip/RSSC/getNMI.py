import numpy as np
import math
# from noisyclustering import data, c, noisenum, randi
from scipy.optimize import linear_sum_assignment
from munkres import Munkres, print_matrix
from sklearn import metrics
import warnings
warnings.filterwarnings("ignore")
# #################将预测标签与真实标签对应###########################


def maplabels(labelC, C):
    # ##########labelC为真实标签，C为预测标签，newC为预测标签映射为真实标签
    Label1 = np.unique(labelC)
    Label2 = np.unique(C)
    nClass1 = len(Label1)
    nClass2 = len(Label2)
    nClass = np.maximum(nClass1, nClass2)
    G = np.zeros((nClass, nClass))
    for i in range(nClass1):
        ind_cla1 = labelC == Label1[i]
        ind_cla1 = ind_cla1.astype(float)
        for j in range(nClass2):
            ind_cla2 = C == Label2[j]
            ind_cla2 = ind_cla2.astype(float)
            G[i, j] = np.sum(ind_cla2 * ind_cla1)
    m = Munkres()
    index = m.compute(-G.T)
    index = np.array(index)
    newC = np.zeros(C.shape, dtype=int)
    for i in range(nClass2):
        for j in range(len(C)):
            if C[j] == index[i, 0]:
                newC[j] = index[i, 1]
    return newC


# ####################计算NMI################
def MIhat(labelC, newc):
    getMIhat = metrics.normalized_mutual_info_score(labelC, newc)
    return getMIhat


# ##################计算准确率ACC##################
def clustering_acc(labelC, newc):
    sum = np.sum(labelC[:] == newc[:])
    acc = sum/len(newc)
    return acc
