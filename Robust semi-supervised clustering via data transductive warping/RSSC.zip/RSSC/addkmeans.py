from noisyclustering import loaddata, suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
     NMI, nosioutput_xls,  plot, nosielabel
from getNMI import maplabels, MIhat, clustering_acc
import time
import pandas as pd
from CPSSSCE import *


def kmeans(noiseimdata, cluster_num, labelC):
    # ###########################k-means##################################
    start5 = time.clock()
    estimator = KMeans(n_clusters=cluster_num)  # 构造聚类器
    estimator.fit(noiseimdata)  # 聚类
    label_pred = estimator.labels_
    newlabel = maplabels(labelC, label_pred)
    getMIhat1 = MIhat(labelC, newlabel)
    acc1 = clustering_acc(labelC, newlabel)
    lkmeans = [getMIhat1, acc1]
    end5 = time.clock()
    print('k-means运行时间是: %s Seconds' % (end5 - start5))
    print('kmeans的评估结果', lkmeans)
    return lkmeans
'''
data = loaddata()
from USPS01 import load_USPS01,noisenorl

data12, data2to10, datalabel = load_USPS01()
cluster_num = 3
data12 = pd.DataFrame(data12)
(semidata1, label, inndex) = suTOsemi(data12, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列  # 得到半监督数据
    # noiseimdata = np.vstack((semidata1, data2to10))  # 得到噪声数据
noiseimdata, randi = noisenorl(semidata1, data2to10, 240)
    # 得到噪声标签
labelssize, labelC = nosielabel(data12, 240, randi, 2)  # #1--标签在第一列，2--标签在最后一列
'''
from mnist01add import load_mnist_train,noisenorl

data12, data2to10, datalabel = load_mnist_train("E:/Datasets1/mnist_dataset")
cluster_num = 5

data12 = pd.DataFrame(data12)
(semidata1, label, inndex) = suTOsemi(data12, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列  # 得到半监督数据
    #noiseimdata = np.vstack((semidata1, data2to10))  # 得到噪声数据
noiseimdata, randi = noisenorl(semidata1, data2to10, 300)  # 270
    # 得到噪声标签
labelssize, labelC = nosielabel(data12, 300, randi, 2)

#(semidata1, label, inndex) = suTOsemi(data, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列
#(noiseimdata, noisearray, noisenum, randi) = uninoisenorl(semidata1, 0.4, -30, 100, 2)  # #1--高斯噪声，2--均匀噪声
#labelssize, labelC = nosielabel(data, noisenum, randi, 2)  # #1--标签在第一列，2--标签在最后一列
#cluster_num = 4
lkmeans = kmeans(noiseimdata, cluster_num, labelC)
