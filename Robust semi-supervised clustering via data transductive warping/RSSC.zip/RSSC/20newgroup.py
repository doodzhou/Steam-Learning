from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.datasets import fetch_20newsgroups
from pprint import pprint
from sklearn.cluster import KMeans

import numpy as np
from numpy.matlib import rand
import matplotlib.pyplot as plt
import random
import pandas as pd
from noisyclustering import suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
     NMI, nosioutput_xls, plot, nosielabel
import random
import time
from compareway import kmeansspectral, getsssc, getsssc0, getrsec, duibinnosi_xls, getcpsssce
from PCPSNMF import *


def noisenorl(semidata, data2to10, noisenum):
    noisematrix = data2to10
    randi = random.sample(range(0, len(semidata)), noisenum)  # 从mn个数中随机取noisenum个数,noisenum为其他数字图像个数
    noiseindx = []
    for iio in range(noisenum):
        semidata = np.insert(semidata, randi[iio], noisematrix[iio], 0)
        noiseindx.append(randi[iio])
    noiseimdata = semidata
    return noiseimdata, randi

# , 'rec.autos'
categories1 = ['alt.atheism', 'comp.graphics', 'sci.space', 'talk.religion.misc']
# 'talk.religion.misc'只有377个数，作为噪声，其他四个加起来有2251个数

fetch_20newsgroups(data_home=None, # 文件下载的路径
                   subset='train', # 加载那一部分数据集 train/test
                   categories=None, # 选取哪一类数据集[类别列表]，默认20类
                   shuffle=True,  # 将数据集随机排序
                   random_state=42, # 随机数生成器
                   remove=(), # ('headers','footers','quotes') 去除部分文本
                   download_if_missing=True # 如果没有下载过，重新下载
                   )
# 加载数据集
newsgroups_train1 = fetch_20newsgroups(subset='train', categories=categories1)
# 提取tfidf特征
vectorizer1 = TfidfVectorizer()
vectors1 = vectorizer1.fit_transform(newsgroups_train1.data)
alldata1 = vectors1.toarray()


label = np.zeros(shape=(vectors1.shape[0], 1))
for i in range(len(newsgroups_train1.target)):
    label[i, 0] = int(newsgroups_train1.target[i])

# newsgroups_train1.target = newsgroups_train1.target.shape((vectors1.shape[0], 1))
alldata = np.hstack((alldata1, label))  # 整个数据集（包括噪声）
print(alldata.shape)
np.savetxt("E:/seminosiyclustering/20newgroup.txt", alldata, fmt='%s', delimiter=',')
nosiy = alldata[alldata[:, -1] == 3]
nosiydata = nosiy[:, 0:-1]  # 噪声数据
print(nosiy.shape)

idex1 = range(len(alldata))  # #数据总的对应的行号
index = list(np.where(alldata[:, -1] == 3))
remainder_data = alldata[np.delete(idex1, index)]
cleandata = remainder_data  # 干净数据
print(cleandata.shape)

cluster_num = 4
k = 10
bata = 50
cleandata = pd.DataFrame(cleandata)
(semidata1, label, inndex) = suTOsemi(cleandata, 0.9, 2)
noiseimdata, randi = noisenorl(semidata1, nosiydata, 377)
labelssize, labelC = nosielabel(cleandata, 377, randi, 2)

mu = 0.5
alpha = 1  # % optimal
per = 5
kk = 4
start2 = time.clock()
W = myKNN(noiseimdata, k=4)
# testlabel, Z = trtepr(per, labelsub, k, Trans_datasub, subN)
Z = MClink(per, labelC)
Vn, K = CSNMF(W, mu, kk, Z, alpha)
end2 = time.clock()
print('PSCSNMF运行时间是: %s Seconds' % (end2 - start2))
label = np.argmax(Vn, axis=1)  # 得到Vn每行的最大值
newssc = maplabels(labelC, label)
getMIhat = MIhat(labelC, newssc)
acc = clustering_acc(labelC, newssc)
print(getMIhat, acc)

start1 = time.clock()
normalL = getWbyKNNnol(noiseimdata, k)
Y = getkr(bata, normalL, inndex)
newnormalL = getnewWbyKNNnol(Y, k)
end1 = time.clock()
print('RSSC运行时间是: %s Seconds' % (end1 - start1))
# c, clf = mapspectral(newnormalL, cluster_num, labelC)
c, clf = mapspectral(newnormalL, cluster_num, labelC)
getMIhat, acc = NMI(labelC, c)

lkmeans, lspectlar, lkdd, lhc = kmeansspectral(noiseimdata, cluster_num, labelC)
start2 = time.clock()
lsssc = getsssc(noiseimdata, labelC, label, cluster_num, inndex)
end2 = time.clock()
print('sssc运行时间是: %s Seconds' % (end2 - start2))
start3 = time.clock()
lrsec = getrsec(noiseimdata, cluster_num, labelC)
end3 = time.clock()
print('RSEC运行时间是: %s Seconds' % (end3 - start3))

