from cgitb import text
from gettext import find

import xlrd
from matplotlib import pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.ticker import MultipleLocator, FormatStrFormatter

# #######################读取第一个result1表###################################
def read_excel_xls1(path1):
    workbook = xlrd.open_workbook(path1)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI1 = []
    zACC1 = []
    zNoise1 = []
    for i2 in range(1, worksheet.nrows):
        nmi1 = worksheet.cell_value(i2, 2)
        zNMI1.append(nmi1)
        acc1 = worksheet.cell_value(i2, 3)
        zACC1.append(acc1)
        noiserate1 = worksheet.cell_value(i2, 4)
        zNoise1.append(noiserate1)
    zNMI1 = np.array(zNMI1).reshape(21, 20)  # （18， 19）
    zACC1 = np.array(zACC1).reshape(21, 20)
    zNoise1 = np.array(zNoise1).reshape(21, 20)
    return zNMI1, zACC1, zNoise1


# #######################读取第二个result1表###################################
def read_excel_xls2(path2):
    workbook = xlrd.open_workbook(path2)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI2 = []
    zACC2 = []
    zNoise2 = []
    for i2 in range(1, worksheet.nrows):
        nmi2 = worksheet.cell_value(i2, 2)
        zNMI2.append(nmi2)
        acc2 = worksheet.cell_value(i2, 3)
        zACC2.append(acc2)
        noiserate2 = worksheet.cell_value(i2, 4)
        zNoise2.append(noiserate2)
    zNMI2 = np.array(zNMI2).reshape(21, 20)
    zACC2 = np.array(zACC2).reshape(21, 20)
    zNoise2 = np.array(zNoise2).reshape(21, 20)
    return zNMI2, zACC2, zNoise2


# #######################读取第三个result1表###################################
def read_excel_xls3(path3):
    workbook = xlrd.open_workbook(path3)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI3 = []
    zACC3 = []
    zNoise3 = []
    for i3 in range(1, worksheet.nrows):
        nmi3 = worksheet.cell_value(i3, 2)
        zNMI3.append(nmi3)
        acc3 = worksheet.cell_value(i3, 3)
        zACC3.append(acc3)
        noiserate3 = worksheet.cell_value(i3, 4)
        zNoise3.append(noiserate3)
    zNMI3 = np.array(zNMI3).reshape(21, 20)
    zACC3 = np.array(zACC3).reshape(21, 20)
    zNoise3 = np.array(zNoise3).reshape(21, 20)
    return zNMI3, zACC3, zNoise3


# #######################读取第四个result1表###################################
def read_excel_xls4(path4):
    workbook = xlrd.open_workbook(path4)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI4 = []
    zACC4 = []
    zNoise4 = []
    for i4 in range(1, worksheet.nrows):
        nmi4 = worksheet.cell_value(i4, 2)
        zNMI4.append(nmi4)
        acc4 = worksheet.cell_value(i4, 3)
        zACC4.append(acc4)
        noiserate4 = worksheet.cell_value(i4, 4)
        zNoise4.append(noiserate4)
    zNMI4 = np.array(zNMI4).reshape(21, 20)
    zACC4 = np.array(zACC4).reshape(21, 20)
    zNoise4 = np.array(zNoise4).reshape(21, 20)
    return zNMI4, zACC4, zNoise4


# #######################读取第五个result1表###################################
def read_excel_xls5(path5):
    workbook = xlrd.open_workbook(path5)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI5 = []
    zACC5 = []
    zNoise5 = []
    for i5 in range(1, worksheet.nrows):
        nmi5 = worksheet.cell_value(i5, 2)
        zNMI5.append(nmi5)
        acc5 = worksheet.cell_value(i5, 3)
        zACC5.append(acc5)
        noiserate5 = worksheet.cell_value(i5, 4)
        zNoise5.append(noiserate5)
    zNMI5 = np.array(zNMI5).reshape(21, 20)
    zACC5 = np.array(zACC5).reshape(21, 20)
    zNoise5 = np.array(zNoise5).reshape(21, 20)
    return zNMI5, zACC5, zNoise5


# #######################求5个值的平均值################################
def average(zNMI1, zACC1, zNoise1,zNMI2, zACC2, zNoise2,zNMI3, zACC3, zNoise3,zNMI4, zACC4, zNoise4,zNMI5, zACC5, zNoise5):
    aveNMI=(zNMI1+zNMI2+zNMI3+zNMI4+zNMI5)/5
    aveACC=(zACC1+zACC2+zACC3+zACC4+zACC5)/5
    aveNoise=(zNoise1+zNoise2+zNoise3+zNoise4+zNoise5)/5
    return aveNMI, aveACC, aveNoise


# #######################画出三维图######################################
def plot(aveNMI,aveACC,aveNoise):
    k = np.arange(5, 105, 5)  # 3, 40, 2)
    bata = np.arange(0, 210, 10)  # 1, 70, 4
    k, bata = np.meshgrid(k, bata)
    fig1 = plt.figure()  # figsize=plt.figaspect(0.5)
    fig2 = plt.figure()
    fig3 = plt.figure()

    ax = fig1.add_subplot(1, 1, 1, projection='3d')
    ax.plot_surface(k, bata, aveNMI, cmap='rainbow')
    # 设置三个坐标轴信息
    ax.set_xlabel('p', color='b', fontsize = 15)
    ax.set_ylabel('mu', color='g', fontsize = 15)
    ax.set_zlabel('NMI', color='r', fontsize = 15)

    # ############ACC#######################
    ax = fig2.add_subplot(1, 1, 1, projection='3d')
    ax.plot_surface(k, bata, aveACC, cmap='rainbow')
    # 设置三个坐标轴信息
    ax.set_xlabel('p', color='b', fontsize = 15)
    ax.set_ylabel('mu', color='g', fontsize = 15)
    ax.set_zlabel('ACC', color='r', fontsize = 15)
    # ############nosiyrate#####################
    ax = fig3.add_subplot(1, 1, 1, projection='3d')
    ax.plot_surface(k, bata, aveNoise, cmap='rainbow')
    # 设置三个坐标轴信息
    ax.set_xlabel('p', color='b', fontsize = 15)
    ax.set_ylabel('mu', color='g', fontsize = 15)
    ax.set_zlabel('Noiserate', color='r', fontsize = 15)
    plt.draw()
    plt.show()
    print()


if __name__ == '__main__':
    # ##inoosphere,iris,plrx,seeds2,fertitity,wine
    path1 = 'E:\\seminosiyclustering\\result\\iris\\result1.xlsx'
    path2 = 'E:\\seminosiyclustering\\result\\iris\\result2.xlsx'
    path3 = 'E:\\seminosiyclustering\\result\\iris\\result3.xlsx'
    path4 = 'E:\\seminosiyclustering\\result\\iris\\result4.xlsx'
    path5 = 'E:\\seminosiyclustering\\result\\iris\\result5.xlsx'
    zNMI1, zACC1, zNoise1 = read_excel_xls1(path1)
    zNMI2, zACC2, zNoise2 = read_excel_xls1(path2)
    zNMI3, zACC3, zNoise3 = read_excel_xls1(path3)
    zNMI4, zACC4, zNoise4 = read_excel_xls1(path4)
    zNMI5, zACC5, zNoise5 = read_excel_xls1(path5)
    aveNMI, aveACC, aveNoise = average(zNMI1,zACC1,zNoise1,zNMI2,zACC2,zNoise2,zNMI3,zACC3,zNoise3,
                                     zNMI4,zACC4,zNoise4,zNMI5,zACC5,zNoise5)
    plot(aveNMI, aveACC, aveNoise)


