import numpy as np
from sklearn.cluster import KMeans
from sklearn.neighbors import kneighbors_graph
import sklearn.cluster as skc  # 密度聚类
from getNMI import maplabels, MIhat, clustering_acc
from kdd import __latent_decomposition, fit_predict
import xlsxwriter as xlwt
import openpyxl
import math
from sklearn import metrics
from sklearn.cluster import spectral_clustering
from sklearn.cluster import AgglomerativeClustering
from sssc import indicator, getnormal, eigensystem, getmab, getvac
from sssc0 import indicator0, getnormal0, eigensystem0, getmab0, getvac0
from RSEC import baseCls, Rsec
from ConstrainedKMeans import constrained_kmeans
import time
from CPSSSCE import *


def kmeansspectral(noiseimdata, cluster_num, labelC):
    # ###########################k-means##################################
    start5 = time.clock()
    estimator = KMeans(n_clusters=cluster_num)  # 构造聚类器
    estimator.fit(noiseimdata)  # 聚类
    label_pred = estimator.labels_
    newlabel = maplabels(labelC, label_pred)
    getMIhat1 = MIhat(labelC, newlabel)
    acc1 = clustering_acc(labelC, newlabel)
    lkmeans = [getMIhat1, acc1]
    end5 = time.clock()
    #print('k-means运行时间是: %s Seconds' % (end5 - start5))
    # nokmeans = noiserate(newlabel, labelssize, labelC, noisenum, norate)
    #print("kmeans的评判指标为：", lkmeans)
    # print("kmeans的噪声识别率为：", nokmeans)
    # ##########################spectral clustring################################
    start6 = time.clock()
    metrics_metrix = (-1 * metrics.pairwise.pairwise_distances(noiseimdata)).astype(np.int32)
    metrics_metrix += -1 * metrics_metrix.min()
    # #设置谱聚类函数
    C = spectral_clustering(metrics_metrix, n_clusters=cluster_num)
    # C = s.labels_
    newC = maplabels(labelC, C)
    getMIhat2 = MIhat(labelC, newC)
    acc2 = clustering_acc(labelC, newC)
    lspectlar = [getMIhat2, acc2]
    end6 = time.clock()
    print('spectral运行时间是: %s Seconds' % (end6 - start6))
    # nospectral = noiserate(newC, labelssize, labelC, noisenum, norate)
    print("spectral的评判指标为：", lspectlar)
    # print("spectral的噪声识别率为：", nospectral)

    # ############################kdd算法###########################################
    start4 = time.clock()
    Ag, Ac, H = __latent_decomposition(noiseimdata,cluster_num)
    labels = fit_predict(Ag, Ac, H,cluster_num)
    newlabels = maplabels(labelC, labels)
    getMIhat4 = MIhat(labelC, newlabels)
    acc4 = clustering_acc(labelC, newlabels)
    lkdd = [getMIhat4, acc4]
    end4 = time.clock()
    print('kdd运行时间是: %s Seconds' % (end4 - start4))
    # nokdd = noiserate(newlabels, labelssize, labelC, noisenum, norate)
    print("kdd的评判指标为：", lkdd)
    # print("kdd的噪声识别率为：", nokdd)
    # ############################层次聚类###############################
    start7 = time.clock()
    linkages = ['ward', 'average', 'complete']
    ac = AgglomerativeClustering(linkage=linkages[1], n_clusters=cluster_num)
    # #训练数据
    ac.fit(noiseimdata)
    lables = ac.labels_
    newlabel = maplabels(labelC, lables)
    getMIhat3 = MIhat(labelC, newlabel)
    acc3 = clustering_acc(labelC, newlabel)
    lhc = [getMIhat3, acc3]
    end7 = time.clock()
    #print('hc运行时间是: %s Seconds' % (end7 - start7))
    # nohc = noiserate(newlabel, labelssize, labelC, noisenum, norate)
    #print("层次聚类hc的评判指标为：", lhc)
    # print("hc的噪声识别率为：", nohc)
    return lkmeans, lspectlar, lkdd, lhc


# #########################（SEMI-SUPERVISED SPECTRAL CLUSTERING）sssc聚类#################
# #########噪声比不等于0的情况
def getsssc(noiseimdata, labelC, label, cluster_num, inndex):
    jl, labelnum, unlabelnum = indicator(labelC, label, cluster_num, inndex)
    ws, normals = getnormal(noiseimdata)
    vectors = eigensystem(normals, cluster_num)
    mab = getmab(vectors, jl, labelnum, cluster_num)
    ssc = getvac(vectors, mab, jl, unlabelnum, cluster_num, ws)
    newssc = maplabels(labelC, ssc)
    getMIhat5 = MIhat(labelC, newssc)
    acc5 = clustering_acc(labelC, newssc)
    lsssc = [getMIhat5, acc5]
    # nosssc = noiserate(newssc, labelssize, labelC, noisenum, norate)
    print("sssc的评判指标为：", lsssc)
    # print("sssc的噪声识别率为：", nosssc)
    return lsssc


# ###################噪声比等于0的情况#########################
def getsssc0(noiseimdata, labelC, label, cluster_num, inndex):
    jl, labelnum, unlabelnum = indicator0(labelC, label, cluster_num, inndex)
    ws, normals = getnormal0(noiseimdata)
    vectors = eigensystem0(normals, cluster_num)
    mab = getmab0(vectors, jl, labelnum, cluster_num)
    ssc = getvac0(vectors, mab, jl, unlabelnum, cluster_num, ws)
    newssc = maplabels(labelC, ssc)
    getMIhat6 = MIhat(labelC, newssc)
    acc6 = clustering_acc(labelC, newssc)
    lsssc = [getMIhat6, acc6]
    print("sssc的评判指标为：", lsssc)
    return lsssc


# #########################Robust Spectral Ensemble Clustering2016 CIKM RSEC#######################
def getrsec(noiseimdata, cluster_num, labelC):
    # #N 设为100，lambda1=0.1.lambda2=0.01
    basecls = baseCls(noiseimdata, cluster_num, 100)
    label = Rsec(basecls, cluster_num, 0.1, 0.01)
    newlabel = maplabels(labelC, label)
    getMIhat6 = MIhat(labelC, newlabel)
    acc6 = clustering_acc(labelC, newlabel)
    lrsec = [getMIhat6, acc6]
    # norsec = noiserate(newlabel, labelssize, labelC, noisenum, norate)
    print("RSEC的评判指标为：", lrsec)
    # print("RSEC的噪声识别率为：", norsec)
    return lrsec


def getcpsssce(data,noiseimdata,cluster_num,labelC):
    nM = math.ceil(0.09*len(data))
    nC = math.ceil(0.09*len(data))
    r = cluster_num
    M, C = MClink(nM, nC,labelC)
    Z = Scm(noiseimdata, M, C, nM, nC)
    lamtaq = baseclu(r, cluster_num, Z)
    S = hypergraph(lamtaq, r, M, C)
    C = SC(S, cluster_num, labelC)
    newC = maplabels(labelC, C)
    getMIhat8 = MIhat(labelC, newC)
    acc8 = clustering_acc(labelC, newC)
    lcpsssce = [getMIhat8, acc8]
    print("CPSSSCE的评判指标为：", lcpsssce)
    return lcpsssce


# ########################k_means_constrained####################################
def getkconstrained(noiseimdata, cluster_num, labelC):
    # #N 设为100，lambda1=0.1.lambda2=0.01
    demand = []
    uni = np.unique(labelC)
    for ui in uni:
        demand.append(len(labelC[labelC == ui]))
    (C, label, f) = constrained_kmeans(noiseimdata, demand)
    newconkmeans = maplabels(labelC, label)
    getMIhat7 = MIhat(labelC, newconkmeans)
    acc7 = clustering_acc(labelC, newconkmeans)
    lconkmeans = [getMIhat7, acc7]
    # norsec = noiserate(newlabel, labelssize, labelC, noisenum, norate)
    print("constrained k-means的评判指标为：", lconkmeans)
    # print("RSEC的噪声识别率为：", norsec)
    return lconkmeans


# ####################参数将结果输出到表格中############################
def duibioutput_xls(lkmeans, lspectlar, lkdd, lhc, lsssc, lrsec):
    book = xlwt.Workbook('E:\\seminosiyclustering\\result\\duibisuanfa\\wdbc\\result1.xlsx')  # 创建一个Excel
    sheet1 = book.add_worksheet('result')
    sheet1.write(0, 1, 'NMI')
    sheet1.write(0, 2, 'acc')
    sheet1.write(1, 0, 'kmeans')
    sheet1.write(2, 0, 'spectral')
    sheet1.write(3, 0, 'kdd')
    sheet1.write(4, 0, 'hc')
    sheet1.write(5, 0, 'sssc')
    sheet1.write(6, 0, 'rsec')
    # sheet1.write(4, 0, 'kdd')
    sheet1.write(1, 1, lkmeans[0])  # 如果label是中文一定要解码
    sheet1.write(1, 2, lkmeans[1])
    sheet1.write(2, 1, lspectlar[0])
    sheet1.write(2, 2, lspectlar[1])
    sheet1.write(3, 1, lkdd[0])
    sheet1.write(3, 2, lkdd[1])
    sheet1.write(4, 1, lhc[0])
    sheet1.write(4, 2, lhc[1])
    sheet1.write(5, 1, lsssc[0])
    sheet1.write(5, 2, lsssc[1])
    sheet1.write(6, 1, lrsec[0])
    sheet1.write(6, 2, lrsec[1])
    # book.save(xls_path)
    book.close()  # 创建保存文件


# #############不同噪声比所得的结果######################################
def duibinnosi_xls(lparament, ltkmeans, ltspectlar, ltkdd, lthc, lsssc, lrsec):
    book = xlwt.Workbook('E:\\seminosiyclustering\\result\\duibisuanfa\\plrx\\result5.xlsx')  # 创建一个Excel
    sheet1 = book.add_worksheet('result')
    sheet1.write(0, 0, 'norate')
    sheet1.write(0, 1, 'k-nmi')
    sheet1.write(0, 2, 'k-acc')
    sheet1.write(0, 3, 's-nmi')
    sheet1.write(0, 4, 's-acc')
    sheet1.write(0, 5, 'kdd-nmi')
    sheet1.write(0, 6, 'kdd-acc')
    sheet1.write(0, 7, 'hc-nmi')
    sheet1.write(0, 8, 'hc-acc')
    sheet1.write(0, 9, 'sssc-nmi')
    sheet1.write(0, 10, 'sssc-acc')
    sheet1.write(0, 11, 'reec-nmi')
    sheet1.write(0, 12, 'rsec-acc')
    for iba in range(len(lparament)):
    # iba = 2
        sheet1.write(iba + 1, 0, lparament[0])  # 如果label是中文一定要解码
        sheet1.write(iba + 1, 1, ltkmeans[iba][0])  # ltkmeans[iba][0]
        sheet1.write(iba + 1, 2, ltkmeans[iba][1])  # ltkmeans[iba][1]
        sheet1.write(iba + 1, 3, ltspectlar[iba][0])  # ltspectlar[iba][0]
        sheet1.write(iba + 1, 4, ltspectlar[iba][1])
        sheet1.write(iba + 1, 5, ltkdd[iba][0])  # ltkdd[iba][0]
        sheet1.write(iba + 1, 6, ltkdd[iba][1])
        sheet1.write(iba + 1, 7, lthc[iba][0])  # lthc[iba][0]
        sheet1.write(iba + 1, 8, lthc[iba][1])
        sheet1.write(iba + 1, 9, lsssc[iba][0])  # lsssc[iba][0]
        sheet1.write(iba + 1, 10, lsssc[iba][1])
        sheet1.write(iba + 1, 11, lrsec[iba][0])  # lrsec[iba][0]
        sheet1.write(iba + 1, 12, lrsec[iba][1])


# book.save(xls_path)
    book.close()  #
# #############################将结果打印出来####################################
