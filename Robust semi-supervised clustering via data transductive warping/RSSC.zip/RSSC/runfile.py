from noisyclustering import loaddata, suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
    noiserate, NMI, output_xls, plot, nosielabel
import numpy as np
from compareway import kmeansspectral, duibioutput_xls

########################################################################
# #这是选择参数

cluster_num = 4
data = loaddata()
(semidata1, label, inndex) = suTOsemi(data, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列
# M,C=MClink(5, 5,labels)
(noiseimdata, noisearray, noisenum, randi) = uninoisenorl(semidata1, 0.4, -30, 100, 2)  # #1--高斯噪声，2--均匀噪声
# xls_path = 'F:\\python实验\\result\\seeds-dataset\\result3.xlsx'
labelssize, labelC = nosielabel(data, noisenum, randi, 2)  # #1--标签在第一列，2--标签在最后一列
# count = 0
lparament = []
lgetNMI = []
lacc = []
levaluation = []
lnoisrate = []
# #############################本方法########################################
#bata = 50
# k = 12
for bata in np.arange(0, 210, 10):  # (500,5500,500):(1,70,4)
    for k in np.arange(5, 105, 5):  # (3, 50, 2)
        lpara = [bata, k]
        lparament.append(lpara)  # #########参数组成的总列表
        print(bata, k)
        normalL = getWbyKNNnol(noiseimdata, k)
        Y = getkr(bata, normalL, inndex)
        newnormalL = getnewWbyKNNnol(Y, k)
        c, clf = mapspectral(newnormalL, cluster_num, labelC)
        noisrate = noiserate(c, labelssize, labelC, noisenum)
        getMIhat, acc = NMI(labelC, c)  # #1--标签在第一列，2--标签在最后一列
        lgetNMI.append(getMIhat)  # ############NMI组成的总列表
        lacc.append(acc)  # ####################acca组成的总列表
        leval = [getMIhat, acc]
        levaluation.append(leval)  # ##########评判指标组成的总列表
        lnoisrate.append(noisrate)  # ##########噪声识别率组成的总列表
output_xls(lparament, levaluation, lnoisrate)
# validation_accuracies=[lpara,noisratelist,evaluation]
# print(validation_accuracies)
# centers = getCenters(noiseimdata, c)
# plot(x0, x1, x2, centers)
# ################################kmeans 和 spectral clustring 和 kdd##########################
lkmeans, lspectlar, lkdd, lhc = kmeansspectral(noiseimdata, cluster_num, labelC)
# ##############将对比算法的结果输出到表格中
# duibioutput_xls(lkmeans, lspectlar, lkdd)
