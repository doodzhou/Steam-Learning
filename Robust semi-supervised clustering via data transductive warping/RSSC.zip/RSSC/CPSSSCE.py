# /*代码实现的是Constraint projections for semi-supervised spectral clustering ensemble
import numpy as np
import random
from itertools import product, combinations
from sklearn.cluster import KMeans
from getNMI import maplabels


# ####################输出勿连和必连数据###########################
def MClink(nM, nC, labelC):
    u = np.unique(labelC)
    k = len(u) - 1
    labelC = labelC.tolist()
    # #############输出 must - link
    M = []
    ran_li = []
    # label = labelC.dropna(axis=0, how='all')
    u = np.unique(labelC)
    for i in range(k):  # k为聚类的个数
        idx = [ii for ii, x in enumerate(labelC) if x == u[i]]
        # idx = labelC[labelC.values == u[i]].index
        # res_list = list(combinations(idx, 2))
        res_list = list(product(idx, idx))
        # ran_li = random.sample(res_list, nM)
        ran_li.append(res_list)  # ###################M为必连数据的索引号，如下所示，每nM个为一个list，总共有k个list,构成一个大的list
        # [[(7, 40), (7, 10), (1, 5), (7, 33), (5, 40)],
        # [(75, 97), (73, 115), (97, 115), (73, 97), (75, 115)],
        # [(134, 176), (133, 134), (134, 137), (133, 176), (133, 137)]]
    for ir in range(len(ran_li)):
        for jr in range(len(ran_li[ir])):
            M.append(ran_li[ir][jr])
    M = random.sample(M, nM)

    # #############输出 cannot - link
    A = []
    ran_li2 = []
    for i1 in range(k):
        idx2 = [ii for ii, x in enumerate(labelC) if x == u[i1]]
        A.append(idx2)
        A1 = list(combinations(A, 2))
        C = []
        # idx2=label[label.values == u[j1]].index
        for i2 in range(len(A1)):
            li = list(product(A1[i2][0], A1[i2][1]))
            # ran_li2 = random.sample(li, nC)
            ran_li2.append(li)
            # C.append(ran_li2)  # ##########C为勿连数据，不同的类之间产生nC个数据，nC个为一个list，如下所示
            # [[(30, 115), (30, 97), (5, 73), (10, 97), (1, 115)],
            # [(1, 176), (40, 133), (1, 134), (5, 133), (10, 137)],
            # [(75, 134), (73, 137), (73, 176), (97, 137), (102, 137)]]
    for ic in range(len(ran_li2)):
        for jc in range(len(ran_li2[ic])):
            C.append(ran_li2[ic][jc])
    C = random.sample(C, nC)

    return M, C


def dist(p1, p2):
    a = (p1 - p2).reshape(p1.shape[0], 1)
    b = (p1 - p2).reshape(1, p1.shape[0])
    tance = np.dot(a, b)
    return tance


def dist2(p1, p2):
    a = p1 - p2
    b = (p1 - p2).reshape(a.shape[0], 1)
    tance2 = np.dot(a, b)
    return tance2


# 计算Sc和Sm,最终得到Z
def Scm(noiseimdata, M, C, nM, nC):
    # 先计算Sc
    nmu1 = []
    getnum1 = []
    for ic in range(len(C)):
        tance1 = dist(noiseimdata[C[ic][0], :], noiseimdata[C[ic][1], :])  # 得到的是矩阵dimxdim
        tance3 = dist2(noiseimdata[C[ic][0], :], noiseimdata[C[ic][1], :])  # 得到的是一个数值
        nmu1.append(tance1)
        getnum1.append(tance3)
    Sc = sum(nmu1)
    Sc = 1 / (2 * nC) * Sc  # 得出的Sc

    # 再计算Sm
    nmu2 = []
    getnum2 = []
    for im in range(len(M)):
        tance2 = dist(noiseimdata[M[im][0], :], noiseimdata[M[im][1], :])
        tance4 = dist2(noiseimdata[M[im][0], :], noiseimdata[M[im][1], :])
        nmu2.append(tance2)
        getnum2.append(tance4)
    Sm = sum(nmu2)
    Sm = 1 / (2 * nM) * Sm  # 得出的Sc
    gama = sum(getnum1) / sum(getnum2)

    print(gama)
    # 得到W=eigeve
    A = Sc - gama * Sm
    eigv, eige = np.linalg.eig(A)
    sorted_indices = np.argsort(-eigv)  # 对特征值从大到小排序，得到的是索引号
    a1 = eigv[sorted_indices]  # 对特征值重新整理排序
    for i in range(len(a1)):
        if a1[i] < 0:
            dex = i  # 得到的是特征值第一个小于0的下标
    topk_evecs = eige[sorted_indices]
    eigeve = topk_evecs[0:dex, :]  # 得到的是前dex个特征值不为0的向量
    Z = np.dot(eigeve, noiseimdata.reshape(eigeve.shape[1], len(noiseimdata)))  # W是d行n列的数组
    # Z是d行n列
    Z = Z.T
    # print(Z,Z.shape)
    return Z


def baseclu(r, cluster_num, Z):
    lamtaq = []
    kmin = 1
    kmax = cluster_num
    for q in range(r):
        kq = random.randint(kmin, kmax)
        estimator = KMeans(n_clusters=kq)  # 构造聚类器
        estimator.fit(Z.real)  # 聚类
        label_pred = estimator.labels_.tolist()  # 获取聚类标签
        label_pred = np.array(label_pred)
        # label = maplabels(labelC, label_pred)
        lamtaq.append(label_pred)  # 此时lamtaq是列表里面嵌套数组
    lamtaq = np.array(lamtaq)
    return lamtaq


# combination is to transform the label vectors into a suitable hypergraph H representation.
# 超图产生
def hypergraph(lamtaq, r, M, C):
    m, n = lamtaq.shape  # r行n列
    hu = []
    hyper_ege = []
    for lm in range(m):
        s = np.unique(lamtaq[lm])
        hu.append(s)
        hyper_ege.append(len(s))

    H = np.zeros(shape=(n, sum(hyper_ege)))  # 定义一个n行hyper_ege列的超图
    step = 0
    # loop = 0
    for lamat in range(len(lamtaq)):
        for ihyper in range(step, hyper_ege[lamat]):
            for il in range(len(lamtaq[lamat])):
                if lamtaq[lamat][il] == hu[lamat][ihyper - step]:
                    H[il][ihyper] = 1
        step = step + hyper_ege[lamat]
        if lamat < r - 1:
            hyper_ege[lamat] = hyper_ege[lamat] + hyper_ege[lamat + 1]
        # loop = loop + 1
    # print('H', H, H.shape)
    S = (1 / r) * np.dot(H, H.T)

    # Amend the similarity matrix S with the pairwise constraint information
    for mi in range(len(M)):
        S[M[mi][0], M[mi][1]] = 1
        # S[M[mi][mj][1], M[mi][mj][0]] = 1
    for ci in range(len(C)):
        S[C[ci][0], C[ci][1]] = 0
        # S[C[ci][cj][1], C[ci][cj][0]] = 0
    return S


'''


# Generation of diverse base clustering
def baseclu(r, cluster_num, Z):
    lamtaq = []
    for q in range(r):
        # kq = random.randint(kmin, kmax)
        estimator = KMeans(n_clusters=cluster_num)  # 构造聚类器
        estimator.fit(Z)  # 聚类
        label_pred = estimator.labels_.tolist()  # 获取聚类标签
        label_pred = np.array(label_pred)
        # label = maplabels(labelC, label_pred)
        lamtaq.append(label_pred)  # 此时lamtaq是列表里面嵌套数组
    lamtaq = np.array(lamtaq)
    return lamtaq


# combination is to transform the label vectors into a suitable hypergraph H representation.
# 超图产生
def hypergraph(lamtaq, r, M, C):
    m, n = lamtaq.shape  # r行n列
    H = np.zeros(shape=(n, r * r))  # 定义一个n行r列的超图
    step = 0
    loop = 0
    for lamat in range(len(lamtaq)):
        for ri in range(step, r + step):
            for ilam in range(len(lamtaq[lamat])):
                if lamtaq[lamat][ilam] == ri-loop*r:
                    H[ilam, ri] = 1
        step = step+r
        loop = loop + 1
    S = (1 / r) * np.dot(H, H.T)

    # Amend the similarity matrix S with the pairwise constraint information
    for mi in range(len(M)):
        S[M[mi][0], M[mi][1]] = 1
        # S[M[mi][mj][1], M[mi][mj][0]] = 1
    for ci in range(len(C)):
        S[C[ci][0], C[ci][1]] = 0
        # S[C[ci][cj][1], C[ci][cj][0]] = 0
    return S

'''

# 对S使用标准的谱聚类算法
def SC(S, cluster_num, labelC):
    D = np.sum(S, axis=1)
    laplacianMatrix = np.diag(D) - S
    sqrtDegreeMatrix = np.diag(1.0 / (D ** (0.5)))
    normalL = np.dot(np.dot(sqrtDegreeMatrix, laplacianMatrix), sqrtDegreeMatrix)  # normals=D**(−1/2)WD**(−1/2)
    # print(normalL)
    eigval, eigvec = np.linalg.eig(normalL)
    inds = np.argsort(-eigval)[:cluster_num]  # [1:cluster_num+1:1]
    vectors = eigvec[:, inds]
    # eigvec = Vectors / np.linalg.norm(Vectors, axis=1, keepdims=True)
    eigvec = vectors / np.linalg.norm(vectors, axis=1)[:, None]
    clf = KMeans(n_clusters=cluster_num)
    # if(isinstance(eigvec, complex)):  # 判断是否虚数
    #   eigvec = abs(eigvec)
    s = clf.fit(eigvec.real)  # .real
    C = s.labels_
    C = maplabels(labelC, C)  # #将噪声标签都对应在最后一个类
    return C
