import random as rand
import numpy as np
import os
import WECK.utils.io_func as io_func
import WECK.utils.exp_datasets as exd
import WECK.utils.informative_constraints_selection as ics
import WECK.utils.settings as settings

_default_constraints_postfix = ['constraints_2n']
_default_constraints_folder =settings.default_constraints_folder
#_default_diff_portion = 5
_default_diff_portion =1
_default_diff_portion_name = 'diff_n'
#_default_noise_portion_name = 'noise_5n'
_default_noise_portion_name = 'noise_n'
_default_informative_postfix = '_informative'
_define_times=[1]


def _build_default_amount_array(n_samples):
    array = [ 2 * n_samples ]
#    array.insert(0, int(0.25 * n_samples))
#    array=[int(0.5 * n_samples),int(1 * n_samples),int(3 * n_samples),int(5 * n_samples),int(10 * n_samples)]
    return array


def generate_closure_constraints_with_portion(dataset_name, data, targets,must_count=0, cannot_count=0,
                                              informative=False):
    """
    generate transitive-closure constraints
    the number of must-link constraints generated in
    different classes is decided by their portion to all samples

    Parameters
    ----------
    :param targets: real labels of given data set
    :param dataset_name:
    :param must_count: number of must-link constraints to generate
    :param cannot_count: number of cannot-link constraints to generate
    :param informative:

    Returns
    -------
    :return: must-link constraints and cannot-link constraints in 2 lists.
    """
    #data, targets = exd.dataset[dataset_name]['data']()
    #targets = np.int(targets)
    target = []
    for i in targets:
        target.append(int(i))
    targets = target
    print("target:",targets,type(targets))
    print("data.shape",data.shape[1])
    data_len = len(targets)
    print("data_len",data_len)
    clusters = np.unique(np.array(targets))
    print("clusters",clusters)
    n_must_link = [0] * len(clusters)
    print("n_must_link", n_must_link)
    must_link = []
    cannot_link = []
    ml_graph = dict()
    cl_graph = dict()

    if informative:
        if os.path.isfile(_default_constraints_folder + dataset_name + '_informative_constraints.txt'):
            print ('informative constraints already existed.')
            _, informative_cl = io_func.read_constraints(
                _default_constraints_folder + dataset_name + '_informative_constraints.txt')
        else:
            print ('informative constraints not exist, generating...')
            ics.generate_informative_cl_set(dataset_name)
            _, informative_cl = io_func.read_constraints(
                _default_constraints_folder + dataset_name + '_informative_constraints.txt')
        informative_len = len(informative_cl)

    for x in range(data_len):
        ml_graph[x] = set()
        cl_graph[x] = set()

    for cluster in clusters:
        print(cluster)
#        print(targets[targets == cluster])
        n_must_link[int(cluster)-1] = int(len([ i for i in range(len(targets)) if (targets[i]==cluster)]) / float(data_len) * must_count)

    def add_both(d, i, j, ls):
        d[i].add(j)
        d[j].add(i)
        if i > j:
            tmp = i
            i = j
            j = tmp
        # make the first sample to be the smaller one in order to filter the duplicates
        ls.append((i, j))

    for cluster in clusters:
        all_samples = np.where(targets == cluster)
        all_samples = np.squeeze(all_samples)
        # print all_samples
        cur_count = 0
        while cur_count < n_must_link[cluster]:
            selected_sample = np.random.choice(all_samples, 2)
            if selected_sample[0] > selected_sample[1]:
                temp = selected_sample[0]
                selected_sample[0] = selected_sample[1]
                selected_sample[1] = temp
            if (selected_sample[0], selected_sample[1]) in must_link:
                continue
            else:
                add_both(ml_graph, selected_sample[0], selected_sample[1], must_link)
                cur_count += 1
                for x in ml_graph[selected_sample[0]]:
                    if x not in ml_graph[selected_sample[1]] and x != selected_sample[1]:
                        add_both(ml_graph, x, selected_sample[1], must_link)
                        cur_count += 1
                for y in ml_graph[selected_sample[1]]:
                    if y not in ml_graph[selected_sample[0]] and y != selected_sample[0]:
                        add_both(ml_graph, y, selected_sample[0], must_link)
                        cur_count += 1

    cur_count = 0
    while cur_count < cannot_count:
        # choose sample randomly
        if informative:
            cl_tuple = informative_cl[rand.randint(0, informative_len-1)]
            samp1 = cl_tuple[0]
            samp2 = cl_tuple[1]
        else:
            samp1 = rand.randint(0, data_len-1)
            samp2 = rand.randint(0, data_len-1)

        # we don't accept same sample to be the constraint
        if samp1 == samp2 or targets[samp1] == targets[samp2]:
            continue

        if samp1 > samp2:
            temp = samp1
            samp1 = samp2
            samp2 = temp

        # filter the duplicates
        # if they are in the same class, append to the must-link set, or otherwise, the cannot-link set
        if (samp1, samp2) in must_link or (samp1, samp2) in cannot_link:
            continue
        else:
            add_both(cl_graph, samp1, samp2, cannot_link)
            cur_count += 1
            for x in ml_graph[samp1]:
                if x not in cl_graph[samp2]:
                    add_both(cl_graph, x, samp2, cannot_link)
                    cur_count += 1
            for y in ml_graph[samp2]:
                if y not in cl_graph[samp1]:
                    add_both(cl_graph, y, samp1, cannot_link)
                    cur_count += 1

    return must_link, cannot_link, ml_graph, cl_graph


def generate_constraints_with_noise(dataset_name, must_count=0, cannot_count=0, noise_portion=0.0, informative=False):
    real_must_count = (1 - noise_portion) * must_count
    real_cannot_count = (1 - noise_portion) * cannot_count
    fake_count = noise_portion * (must_count + cannot_count)
    cur_fake = 0
    remove_count = 0
    must_link, cannot_link, ml_graph, cl_graph = generate_closure_constraints_with_portion(dataset_name,
                                                                                           must_count=real_must_count,
                                                                                           cannot_count=real_cannot_count,
                                                                                           informative=informative)

    def add_both(d, i, j, ls):
        d[i].add(j)
        d[j].add(i)
        if i > j:
            tmp = i
            i = j
            j = tmp
        # make the first sample to be the smaller one in order to filter the duplicates
        ls.append((i, j))

    def remove_both(d, i, j, ls):
        d[i].remove(j)
        d[j].remove(i)
        if i > j:
            tmp = i
            i = j
            j = tmp
        # make the first sample to be the smaller one in order to filter the duplicates
        ls.remove((i, j))

    if noise_portion == 0.0:
        return must_link, cannot_link, ml_graph, cl_graph
    else:
        data, targets = exd.dataset[dataset_name]['data']()
        data_len = len(targets)
        while cur_fake < fake_count:
            samp1 = rand.randint(0, data_len - 1)
            samp2 = rand.randint(0, data_len - 1)
            samp1, samp2 = (samp1, samp2) if samp1 < samp2 else (samp2, samp1)
            if (samp1, samp2) in must_link or (samp1, samp2) in cannot_link or samp1 == samp2:
                continue
            else:
                if targets[samp1] == targets[samp2]:
                    add_both(cl_graph, samp1, samp2, cannot_link)
                    cur_fake += 1
                    for x in ml_graph[samp1]:
                        if x in ml_graph[samp2]:
                            remove_both(ml_graph, x, samp2, must_link)
                            remove_count += 1
                        if x not in cl_graph[samp2]:
                            add_both(cl_graph, x, samp2, cannot_link)
                            cur_fake += 1
                    for y in ml_graph[samp2]:
                        if y in ml_graph[samp1]:
                            remove_both(ml_graph, y, samp1, must_link)
                            remove_count += 1
                        if y not in cl_graph[samp1]:
                            add_both(cl_graph, y, samp1, cannot_link)
                            cur_fake += 1
                else:
                    add_both(ml_graph, samp1, samp2, must_link)
                    cur_fake += 1
                    for x in ml_graph[samp1]:
                        if x in cl_graph[samp2]:
                            remove_both(cl_graph, x, samp2, cannot_link)
                            remove_count += 1
                        if x not in ml_graph[samp2]:
                            add_both(ml_graph, x, samp2, must_link)
                            cur_fake += 1
                    for y in ml_graph[samp2]:
                        if y in cl_graph[samp1]:
                            remove_both(cl_graph, y, samp1, cannot_link)
                            remove_count += 1
                        if y not in ml_graph[samp1]:
                            add_both(ml_graph, y, samp1, must_link)
                            cur_fake += 1

    print (dataset_name + '__' + str(cur_fake) + '__' + str(remove_count))

    while remove_count > 0:
        samp1 = rand.randint(0, data_len - 1)
        samp2 = rand.randint(0, data_len - 1)
        samp1, samp2 = (samp1, samp2) if samp1 < samp2 else (samp2, samp1)
        if (samp1, samp2) in must_link or (samp1, samp2) in cannot_link or samp1 == samp2:
            continue
        else:
            if targets[samp1] == targets[samp2]:
                add_both(ml_graph, samp1, samp2, must_link)
                remove_count -= 1
                for x in ml_graph[samp1]:
                    if x in cl_graph[samp2]:
                        remove_both(cl_graph, x, samp2, cannot_link)
                        remove_count += 1
                    if x not in ml_graph[samp2]:
                        add_both(ml_graph, x, samp2, must_link)
                        remove_count -= 1
                for y in ml_graph[samp2]:
                    if y in cl_graph[samp1]:
                        remove_both(cl_graph, y, samp1, cannot_link)
                        remove_count += 1
                    if y not in ml_graph[samp1]:
                        add_both(ml_graph, y, samp1, must_link)
                        remove_count -= 1
            else:
                add_both(cl_graph, samp1, samp2, cannot_link)
                remove_count -= 1
                for x in ml_graph[samp1]:
                    if x in ml_graph[samp2]:
                        remove_both(ml_graph, x, samp2, must_link)
                        remove_count += 1
                    if x not in cl_graph[samp2]:
                        add_both(cl_graph, x, samp2, cannot_link)
                        remove_count -= 1
                for y in ml_graph[samp2]:
                    if y in ml_graph[samp1]:
                        remove_both(ml_graph, y, samp1, must_link)
                        remove_count += 1
                    if y not in cl_graph[samp1]:
                        add_both(cl_graph, y, samp1, cannot_link)
                        remove_count -= 1
    return must_link, cannot_link, ml_graph, cl_graph


def generate_diff_amount_constraints_wrapper(dataset_name, data, targets,amount_intervals=None, postfixes=None, informative=False):
    """
    generate constraints of given dataset in different amount
    intervals of amount default to [0.25n, 0.5n, n, 1.5n, 2n],
    and default postfixes are also predefined in a human readable format.
    Notice that the length of amount_intervals and postfixes should be the same.

    :param dataset_name: name of the dataset, should be defined in exp_datasets
    :param amount_intervals: intervals of the amount of contraints as a list, default to [0.25n, 0.5n, n, 1.5n, 2n]
    :param postfixes: postfixes of the file storing the constraints, should be in the same length with intervals
    :param informative: informative cannot-link are adopted or not, default to False
    :return:
    """
    #data, targets = exd.dataset[dataset_name]['data']()
    amount_array = amount_intervals if amount_intervals is not None else _build_default_amount_array(len(targets))
    postfix_array = postfixes if postfixes is not None else _default_constraints_postfix
    additional_postfix = _default_informative_postfix if informative else ''
    if len(amount_array) != len(postfix_array):
        raise ValueError('Length of amount and postfix should be the same.')
    for amount_value, postfix_value in zip(amount_array, postfix_array):
        for i in _define_times:
            ml, cl, _1, _2 = generate_closure_constraints_with_portion(dataset_name,data, targets,
                                                    must_count=int(amount_value/2),cannot_count=int(amount_value/2), informative=informative)
    
            io_func.store_constraints( _default_constraints_folder + dataset_name + '_' + postfix_value + additional_postfix + '.txt', ml, cl)
        
    return


def generate_noise_constraints_wrapper(dataset_name, amount=0, n_groups=0, postfix=None, informative=False,
                                       noise_range_start=0.0, noise_step_size=0.08):
    """
    generate different set of constraints in same amount

    :param dataset_name: name of the dataset, should be defined in exp_datasets
    :param amount: amount of constraints in one set, default to n
    :param n_groups: number of constraints set, default to 5
    :param postfix: postfix of constraints file, default to 'diff_n'
    :param informative: informative cannot-link are adopted or not, default to False
    :return:
    """
    data, targets = exd.dataset[dataset_name]['data']()
    if amount != 0 and postfix is None:
        raise ValueError('Postfix should be given while the amount of constraints is specified.')
    amount_value = amount if amount != 0 else int(len(targets) * _default_diff_portion)
    postfix_value = postfix if postfix is not None else _default_noise_portion_name
    groups = n_groups if n_groups != 0 else 5
    additional_postfix = _default_informative_postfix if informative else ''
    print (informative)
    cur_noise = noise_range_start
    for j in _define_times:
        for i in range(1, groups + 1):
            print (i)
            print (cur_noise)
            ml, cl, _1, _2 = generate_constraints_with_noise(dataset_name,
                                                             must_count=int(amount_value / 2),
                                                             cannot_count=int(amount_value / 2),
                                                             noise_portion=cur_noise,
                                                             informative=informative)
            cur_noise += noise_step_size
            io_func.store_constraints(_default_constraints_folder +'/'+ dataset_name + '_' + postfix_value + '_' + str(i) + additional_postfix + '.txt', ml, cl)
    return


def generate_diff_constraints_wrapper(dataset_name, amount=0, n_groups=0, postfix=None, informative=False):
    """
    generate different set of constraints in same amount

    :param dataset_name: name of the dataset, should be defined in exp_datasets
    :param amount: amount of constraints in one set, default to n
    :param n_groups: number of constraints set, default to 5
    :param postfix: postfix of constraints file, default to 'diff_n'
    :param informative: informative cannot-link are adopted or not, default to False
    :return:
    """
    data, targets = exd.dataset[dataset_name]['data']()
    if amount != 0 and postfix is None:
        raise ValueError('Postfix should be given while the amount of constraints is specified.')
    amount_value = amount if amount != 0 else int(len(targets) * _default_diff_portion)
    postfix_value = postfix if postfix is not None else _default_diff_portion_name
    groups = n_groups if n_groups != 0 else 5
    additional_postfix = _default_informative_postfix if informative else ''
    for i in range(1, groups + 1):
        ml, cl, _1, _2 = generate_closure_constraints_with_portion(dataset_name,
                                                                   must_count=int(amount_value / 2),
                                                                   cannot_count=int(amount_value / 2),
                                                                   informative=informative)
        io_func.store_constraints(
            _default_constraints_folder + dataset_name + '_' + postfix_value + '_' + str(
                i) + additional_postfix + '.txt', ml, cl)
    return


def test_wrapper(dataset_name):
    data, targets = exd.dataset[dataset_name]['data']()
    amount_value = int(len(targets))
    generate_constraints_with_noise(dataset_name,
                                    must_count=int(amount_value / 2),
                                    cannot_count=int(amount_value / 2),
                                    noise_portion=0.25,
                                    informative=False)

# def add_noise_to_constraints(ml, cl, target, portion=0):
#     n_samples = len(target)
#     if portion >= 1:
#         must_noise_num = int(portion / 2)
#         cannot_noise_num = int(portion / 2)
#     else:
#         must_noise_num = int(len(ml) * portion)
#         cannot_noise_num = int(len(cl) * portion)
#     while not stop:
#         # choose sample randomly
#         samp1 = rand.randint(0, n_samples-1)
#         samp2 = rand.randint(0, n_samples-1)
#         if target[]