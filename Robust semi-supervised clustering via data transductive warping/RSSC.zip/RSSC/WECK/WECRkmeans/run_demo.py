import WECK.member_generation.library_generation as lg
import WECK.utils.io_func as io_func
import WECK.utils.exp_datasets as exd
import WECK.evaluation.Metrics as Metrics
import WECK.constrained_methods.generate_constraints_link as gcl
import WECK.ensemble.ensemble_wrapper as ew
import WECK.evaluation.comparision_methods as ed
import time
import numpy as np
from WECK.utils.deal_constrains import deal_constrains
_noise_postfix = ['noise_n_0']


"""
This example set constrain_num=n  dtaset=COIL20
"""
"""
========================================================================================================================
Generate Basic Library
========================================================================================================================
"""
"""
generate basic library
(double-random kmeans)

"""
start = time.clock()
baseclustering_NUM=100
lg.generate_libs_by_sampling_rate('experidata', baseclustering_NUM)
"""
========================================================================================================================
Generate Constraints
========================================================================================================================
"""
"""
generate constraints [part1: different amount of constraints]
"""

gcl.generate_diff_amount_constraints_wrapper('experidata')
deal_constrains(['experidata'])

"""
generate constraints [part2: constraints with different level of noise constraints]
"""
#  gcl.generate_noise_constraints_wrapper('experidata')

"""
===========================================================================================================
new experiments, 12th Oct, 2019.
updates: new formula for calculating weights (g_gamma introduced)
12.27 modified: internals included
===========================================================================================================
"""
"""
experiment
[part1: different amount of constraints]
"""
real_performances, acc_performances, constrain_performances,ensemble_labels_sets=ew.do_ensemble_different_constraints_new_exp('experidata_55-110_0.7_0.7_100_FSRSNC_pure',True)
end = time.clock()
index = constrain_performances.index(np.max(constrain_performances))
labels_sets = ensemble_labels_sets[index]

print("============Result============")
print("the best gama=",index*0.1+0.1)
print("the constrain_performances=",np.max(constrain_performances))
print("the NMI score=",real_performances[index])
print("the acc score=",acc_performances[index])
print('WECK运行时间是: %s Seconds' % (end - start))

"""
experiment
[part2: constraints with different level of noise constraints]
"""
'''
real_performances,constrain_performances=ew.do_ensemble_different_constraints_new_exp('experidata_15-30_0.7_0.7_100_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)
index=constrain_performances.index(np.max(constrain_performances))
print("============Result============")
print("the best gama=",index*0.1+0.1)
print("the NMI score=",real_performances[index])
'''