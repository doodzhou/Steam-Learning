"""
Some Global Settings.
"""
default_eval_path = 'E:/seminosiyclustering/WECK/data/libs/Eval/'
default_constraints_folder = 'E:/seminosiyclustering/WECK/data/Constraints/'
default_library_path = 'E:/seminosiyclustering/WECK/data/libs/'
default_constraints_postfix = [
#        'constraints_quarter_n',
#                               'constraints_half_n',
                               'constraints_n'
#                               'constraints_onehalf_n',
#                               'constraints_2n'
                               ]

