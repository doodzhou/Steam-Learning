import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import eigsh
from sklearn.neighbors import kneighbors_graph
from sklearn.cluster import k_means

"""
    Implementation of the method proposed in the paper:
    'Robust Spectral Clustering for Noisy Data: Modeling Sparse Corruptions Improves Latent Embeddings'
    If you publish material based on algorithms or evaluation measures obtained from this code,
    then please note this in your acknowledgments and please cite the following paper:
        Aleksandar Bojchevski, Yves Matkovic, and Stephan Günnemann.
        2017. Robust Spectral Clustering for Noisy Data.
        In Proceedings of KDD’17, August 13–17, 2017, Halifax, NS, Canada.
    Copyright (C) 2017
    Aleksandar Bojchevski
    Yves Matkovic
    Stephan Günnemann
    Technical University of Munich, Germany
    """

#k = 4
nn = 15
theta = 20
m = 0.5
laplacian = 1
n_iter = 50
normalize = False
verbose = False


def __latent_decomposition( X,k):
    # compute the KNN graph
    A = kneighbors_graph(X=X, n_neighbors=nn, metric='euclidean', include_self=False, mode='connectivity')
    A = A.maximum(A.T)  # make the graph undirected

    N = A.shape[0]  # number of nodes
    deg = A.sum(0).A1  # node degrees

    prev_trace = np.inf  # keep track of the trace for convergence
    Ag = A.copy()

    for it in range(n_iter):

        # form the unnormalized Laplacian
        D = sp.diags(Ag.sum(0).A1).tocsc()
        L = D - Ag

        # solve the normal eigenvalue problem
        if laplacian == 0:
            h, H = eigsh(L, k, which='SM')
        # solve the generalized eigenvalue problem
        elif laplacian == 1:
            h, H = eigsh(L, k, D, which='SM')

        trace = h.sum()

        if verbose:
            print('Iter: {} Trace: {:.4f}'.format(it, trace))

        if theta == 0:
            # no edges are removed
            Ac = sp.coo_matrix((N, N), [np.int])
            break

        if prev_trace - trace < 1e-10:
            # we have converged
            break

        allowed_to_remove_per_node = (deg * m).astype(np.int)
        prev_trace = trace

        # consider only the edges on the lower triangular part since we are symmetric
        edges = sp.tril(A).nonzero()
        removed_edges = []

        if laplacian == 1:
            # fix for potential numerical instability of the eigenvalues computation
            h[np.isclose(h, 0)] = 0

            # equation (5) in the paper
            p = np.linalg.norm(H[edges[0]] - H[edges[1]], axis=1) ** 2 \
                - np.linalg.norm(H[edges[0]] * np.sqrt(h), axis=1) ** 2 \
                - np.linalg.norm(H[edges[1]] * np.sqrt(h), axis=1) ** 2
        else:
            # equation (4) in the paper
            p = np.linalg.norm(H[edges[0]] - H[edges[1]], axis=1) ** 2

        # greedly remove the worst edges
        for ind in p.argsort()[::-1]:
            e_i, e_j, p_e = edges[0][ind], edges[1][ind], p[ind]

            # remove the edge if it satisfies the constraints
            if allowed_to_remove_per_node[e_i] > 0 and allowed_to_remove_per_node[e_j] > 0 and p_e > 0:
                allowed_to_remove_per_node[e_i] -= 1
                allowed_to_remove_per_node[e_j] -= 1
                removed_edges.append((e_i, e_j))
                if len(removed_edges) == theta:
                    break

        removed_edges = np.array(removed_edges)
        Ac = sp.coo_matrix((np.ones(len(removed_edges)), (removed_edges[:, 0], removed_edges[:, 1])), shape=(N, N))
        Ac = Ac.maximum(Ac.T)
        Ag = A - Ac

    return Ag, Ac, H


def fit_predict( Ag, Ac, H ,k):
    """
    :param X: array-like or sparse matrix, shape (n_samples, n_features)
    :return: cluster labels ndarray, shape (n_samples,)
    """

    #Ag, Ac, H = __latent_decomposition(X)
    Ag = Ag
    Ac = Ac

    if normalize:
        H = H / np.linalg.norm(H, axis=1)[:, None]
    else:
        H = H

    centroids, labels, *_ = k_means(X=H, n_clusters=k)

    centroids = centroids
    labels = labels

    return labels
