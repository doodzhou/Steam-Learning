import numpy as np
import math
# Robust Semi-supervised Nonnegative Matrix Factorization


def getA(labelC, label, cluster_num, noiseimdata):
    '''
    :param labelC: 含有噪声的标签
    :param label: 有标签的行号和类别 ,维series类型
    :param cluster_num: 包括噪声一块有几个类
    :return: abeconstraint matrix A
    '''
    N = len(labelC)
    ix = label.index.values  # 获取label的索引号，转为数组
    iy = label.values  # 获取label的值
    ic = np.vstack((ix, iy))  # 将ix和iy按列合并
    label = ic.T  # 此时的label是一个数组
    l = len(label)  # 有多少个数是有标签的
    c = cluster_num-1
    A = np.zeros(shape=(N, N-l+c))
    # 把label放在前面，noiseimdata,labelC按label的顺序变化，例如，x1,x2,x3,...xl是有标签的
    d = []
    for iix in range(0, len(ix)):
        d.append(ix[len(ix) - 1 - iix])
    ix = np.array(d)  # 把ix倒序输出
    sort_noiseimdata = noiseimdata
    sort_labelC = labelC
    for isort in ix:
        c = noiseimdata[isort]
        cl = labelC[isort]
        sort_noiseimdata = np.row_stack((c, sort_noiseimdata))
        sort_noiseimdata = np.delete(sort_noiseimdata, isort + 1, axis=0)  # 得到排序后的噪声数据集
        sort_labelC = np.row_stack((cl, sort_labelC))
        sort_labelC = np.delete(sort_labelC, isort + 1, axis=0)  # 得到排序后的真实噪声标签
    for iiy in range(len(iy)):
        A[iiy, iy[iiy]] = 1
    for jj in range(N-l, N):
        A[jj, jj] = 1
    return sort_noiseimdata, sort_labelC, A

