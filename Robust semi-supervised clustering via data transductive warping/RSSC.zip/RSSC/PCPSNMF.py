import time

import numpy as np
import random
import matplotlib.pyplot as plt
from itertools import product
from noisyclustering import suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
     NMI, nosioutput_xls, plot, nosielabel


def loadsub(fulldata, gnd, k):
    Dim2, datanum = fulldata.shape
    Class = max(gnd)
    turelabel = gnd
    t = np.where(turelabel == 1)[0]
    p = np.arange(Class)
    np.random.shuffle(p)
    clist = p[0:k]
    sublist = []
    for i in range(0, k):
        temp = np.where(turelabel == clist[i])[0].tolist()
        sublist.append(temp)  # sublist是列表
    sublist = sum(sublist, [])
    temp = np.ones(shape=(len(t), 1))
    labelsub = []
    for i in range(0, k):
        labeltemp = (i * temp).tolist()
        labelsub.append(labeltemp)
    labelsub = sum(labelsub, [])  # labelsub是列表
    datasub = fulldata[:, sublist]
    Trans_datasub = datasub.T
    subN = k * len(t)
    return datasub, subN, labelsub, Trans_datasub, clist


def euclidDistance(x1, x2, sqrt_flag=False):
    res = np.sum((x1-x2)**2)
    if sqrt_flag:
        res = np.sqrt(res)
    return res


# X = datasub
def myKNN(X, k=4):
    # X = np.array(X)
    S = np.zeros((len(X), len(X)))
    for i in range(len(X)):
        for j in range(i+1, len(X)):
            S[i][j] = 1.0 * euclidDistance(X[i], X[j])
            S[j][i] = S[i][j]

    N = len(S)
    W = np.zeros((N, N))

    for i in range(N):
        dist_with_index = zip(S[i], range(N))
        dist_with_index = sorted(dist_with_index, key=lambda x: x[0])
        neighbours_id = [dist_with_index[m][1] for m in range(k + 1)]  # xi's k nearest neighbours

        for j in neighbours_id:  # xj is xi's neighbour
            W[i][j] = np.exp(-S[i][j]*0.25)
            W[j][i] = W[i][j]  # mutually

    return W


def findlabels(per, labels, Class):
    '''
    :param per: the number of every class
    :param labels: the label of the data
    :param Class: the number of the Class
    :return:the index of the data we select
    '''
    indices = []
    for i in range(Class):
        ind = np.where(labels==i)[0].tolist()
        L = len(ind)
        p = np.arange(L)
        np.random.shuffle(p)
        indices.append(ind[p[0:per]])
    indices = sum(indices, [])
    return indices


def trtepr(per, labelsub, k, Trans_datasub, subN):
    indices = findlabels(per, labelsub, k)
    traindata = Trans_datasub[indices,:]
    trainlabel = labelsub[indices]
    ind = np.arange(subN)
    ind = np.delete(ind, indices)
    testdata = Trans_datasub[ind,:]
    testlabel = labelsub[ind]
    testnum = testdata.shape[0]
    # prior constraint
    Z = np.eye(subN)
    for i in range(k):
        temp = indices[i * per + 0: i * per, 1]
        for j in range(per):
            Z[temp[j], temp] = 1
    return testlabel, Z


def NormalizeK(K):
    n = K.shape[1]
    norms = []
    sqrtarray = np.sqrt(sum(K * K))
    for i in sqrtarray:
        norms.append(max(1e-15, i))
    norms = np.array(norms)
    norms = norms.transpose()
    K = np.dot(K, np.diag(1.0 / (norms ** (1))))
    return K


def CSNMF(W, mu, k, Z, alpha):
    global V_final, K, V
    maxIter = 500
    n = W.shape[1]
    Os = np.ones((n, 1))
    nIter = 0
    num = 1
    tryNo = 0
    obj = 1e+7
    # KNN graph
    graphD = np.sum(W, axis=1)
    graphL = graphD - W
    # -Norm GraphL
    D_mhalf = np.diag(1.0 / (graphD ** (0.5)))
    graphL = np.dot(np.dot(D_mhalf, graphL), D_mhalf)

    while tryNo < 5:
        tryNo = tryNo + 1
        # ------initialize U V K
        Vb = np.random.rand(n, k)
        Kb = np.random.rand(n, n)
        Vb = NormalizeK(Vb)
        Kb = NormalizeK(Kb)
        for i in range(n):
            ind = np.where(Z[i, :] == 1)[0].tolist()
            Kb[i, ind] = 1
        # ------kernel graph
        kerD = np.zeros((Kb.shape[0], Kb.shape[0]))
        W2 = (Kb + Kb.T)/2
        FRb = np.linalg.norm(W2-np.dot(Vb, Vb.transpose())) + mu*np.trace(np.dot(graphL, Kb))+alpha*np.linalg.norm(Kb-Z)
    while nIter < maxIter:
        # -----update K
        VV = np.dot(Vb, Vb.transpose())
        T2 = (2 * alpha + 1) * Kb + Kb.transpose() + mu*graphD
        T1 = 2 * VV + 2 * alpha * Z + mu*W  # Z.transpose()
        K = Kb * (T1 / T2)
        Kb = K
        W2 = (Kb + Kb.transpose())/2
        # -----update V
        C = np.dot(W2, Vb)
        D = np.dot(np.dot(Vb, Vb.transpose()), Vb)
        E = C / D
        V = Vb * (E ** (1 / 4))
        Vb = V
        nIter = nIter + 1
        FR = np.linalg.norm(W2-np.dot(Vb, Vb.transpose())) + mu * np.trace(np.dot(graphL, Kb))+alpha * np.linalg.norm(Kb - Z)
        if FR < obj:
            V_final = NormalizeK(V)
            obj = FR
            nIter = 0

    return V_final, K


def MClink(nM, labels):
    # #############输出 must - link
    M = []
    label = labels#.dropna(axis=0, how='all')
    u = np.unique(label)
    k = len(u)
    for i in range(k-1):  # k为聚类的个数，噪声标签没有先验信息
        idx = np.where(label == u[i])[0].tolist()
        #res_list = list(combinations(idx, 2))
        res_list = list(product(idx, idx))
        ran_li = random.sample(res_list, nM)
        M.append(ran_li)  # ###################M为必连数据的索引号，如下所示，每nM个为一个list，总共有k-1个list,构成一个大的list
    Z = np.eye(len(labels))
    for iw in range(k-1):
        for jw in range(nM):
            a = M[iw][jw]
            Z[a[0], a[1]] = Z[a[1], a[0]] = 1
    return Z




import pandas as pd
from getNMI import maplabels, MIhat, clustering_acc
from USPS01 import *
# from mnist0 import *
# from mnist012 import *
from mnist01add import *
if __name__ == '__main__':
    # data = pd.read_csv("E:\\seminosiyclustering\\UCIdata/wine.data", header=None)  ##3类,0~12
    # data = pd.read_csv("E:\\seminosiyclustering\\UCIdata/iris.data", header=None) # #3类2~8
    # data = pd.read_csv('E:\\seminosiyclustering\\UCIdata\\seeds_dataset.txt', header=None, delim_whitespace=True)  # 3个类，10~20
    # data = pd.read_csv('E:/seminosiyclustering/UCIdata/column_3C.dat', header=None, delim_whitespace=True)  # 3个类，-30~100
    # data = pd.read_csv("E:\\seminosiyclustering\\UCIdata\\data_banknote_authentication.data", header=None)  # 2个类，-10~15
    # data = pd.read_csv('E:\\seminosiyclustering\\UCIdata\\wdbc.data', header=None).drop([0], axis=1).reset_index(drop=True)  # 2类，标签在第一列 0~40
    # data = pd.read_csv('E:\\seminosiyclustering\\UCIdata\\glass.data', header=None).iloc[:,1:11]##效果还可以，有7类,0~17
    # data = pd.read_csv('E:/seminosiyclustering/UCIdata/column_3C.dat', header=None, delim_whitespace=True)#3个类，-30~100
    # data = pd.read_csv('E:\\seminosiyclustering\\UCIdata\\plrx.txt',header=None, delim_whitespace=True)#效果很好-2~2，2类
    # data = pd.read_csv('E:\\seminosiyclustering\\UCIdata\\yeast.data', header=None, delim_whitespace=True).iloc[:,1:10]  # 10类 -0.5~1.5
    # data = pd.read_csv('E:\\seminosiyclustering\\UCIdata\\pendigits.txt', header=None)[pd.read_csv('E:\\seminosiyclustering\\UCIdata\\pendigits.txt', header=None).iloc[:, 16].isin([1, 6])].reset_index(drop=True)
    # data = pd.read_csv('E:\\seminosiyclustering\\UCIdata\\parkinson.txt', header=None, delim_whitespace=True)  # 两个类,0~1
    # data = pd.read_csv('E:\\seminosiyclustering\\UCIdata\\pendigits(test).txt', header=None)  ##标签在最后一列，10个类，噪声：-10~110

    mu = 0.5
    alpha = 1  # % optimal
    per = 5
    k = 5
    '''
    unlabeldata = data.iloc[:, 0:-1]  # 无标签数据
    noiseimdata, noisearray, noisenum, randi = uninoisenorl(unlabeldata, 0.4, -30, 100, 2)
    labelssize, labelC = nosielabel(data, noisenum, randi, 2)
    '''
    # (semidata1, label, inndex) = suTOsemi(data, 0.9, 2)
    # gnd = label  # gnd是真实标签
    # datasub, subN, labelsub, Trans_datasub, clist = loadsub(fulldata, gnd, k)
    # data12, data2to10, datalabel = load_USPS01()
    data12, data2to10, datalabel = load_mnist_train("E:/Datasets1/mnist_dataset")
    data12 = pd.DataFrame(data12)
    (semidata1, label, inndex) = suTOsemi(data12, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列  # 得到半监督数据
    # noiseimdata = np.vstack((semidata1, data2to10))  # 得到噪声数据
    noiseimdata, randi = noisenorl(semidata1, data2to10, 300)
    # 得到噪声标签
    labelssize, labelC = nosielabel(data12, 300, randi, 2)  # #1--标签在第一列，2--标签在最后一列
    start2 = time.clock()
    W = myKNN(noiseimdata, k=4)
    # testlabel, Z = trtepr(per, labelsub, k, Trans_datasub, subN)
    Z = MClink(per, labelC)
    Vn, K = CSNMF(W, mu, k, Z, alpha)
    end2 = time.clock()
    print('PSCSNMF运行时间是: %s Seconds' % (end2 - start2))
    label = np.argmax(Vn, axis=1)  # 得到Vn每行的最大值
    newssc = maplabels(labelC, label)
    getMIhat = MIhat(labelC, newssc)
    acc = clustering_acc(labelC, newssc)
    print(getMIhat, acc)







