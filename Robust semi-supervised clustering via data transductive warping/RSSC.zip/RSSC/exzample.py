# 2021.07.15 / author: kw-a
import numpy as np
import scipy.io as sio

path = 'E://Datasets1//'  # .arff文件目录
save_path = 'E://Datasets1//'  # .mat文件保存目录

# 主函数
def main():
    arff_to_mat_one('oh0.wc', 'oh0')  # filename, mat_name
    # arff_to_mat_two('Forest Covertype', 'FCT')

    # 查看.mat数据
    data = sio.loadmat(save_path + 'oh0' + '.mat')
    print('oh0: ', data)


def arff_to_mat_one(filename, mat_name):
    dataSet = []
    with open(path + filename + '.arff') as fr:  # 打开读取文件
        Iter = iter(fr.readlines())  # 创建迭代器
        curline = ['0']  # 初始化
        # 迭代到@data结束
        while curline[0] != '@data':
            line = next(Iter)  # 迭代
            curline = line.strip().split(',')
            print(curline)
        print('开始转换{}数据'.format(filename))
        while curline[0]:
            try:
                line = next(Iter)
                curline = line.strip().split(',')  # 去掉首尾空格或换行符
                attrNum = len(curline) - 1  # 属性个数
                fltLine = list(map(float, curline[0:attrNum]))  # 属性值，从下标0读到下标2，不包括下标3，即3个元素，将其转换为浮点数
                label = int((curline[attrNum]))  # 标签 添加最后一个元素
                fltLine.append(label)
                dataSet.append(fltLine)
            except StopIteration:  # next(Iter)迭代结束
                break
    data_array = np.array(dataSet)
    sio.savemat(save_path + mat_name + '.mat', mdict={mat_name: data_array})  # 转换为.mat文件
if __name__ == '__main__':
    main()