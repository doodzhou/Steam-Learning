import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np

mpl.rcParams["font.sans-serif"] = ["SimHei"]
mpl.rcParams["axes.unicode_minus"] = False

x = np.arange(10)
RSC = [0.7752, 0.6079, 0.0040, 0.8005, 0.5281, 0.6827, 0.3273, 0.2999, 0.4027, 0.4275]
SSSC = [0.6306, 0.5991, 0.0073, 0.5695, 0.0180, 0.0121, 0.0064, 0.0031, 0.2800, 0.0100]
RSEC = [0.3961, 0.2398, 0.0672, 0.4242, 0.4561, 0.4653, 0.2619, 0.2632, 0.4198, 0.7244]
Kmeans = [0.6647, 0.6784, 0.0397, 0.7047, 0.5075, 0.6535, 0.3130, 0.0362, 0.3421, 0.6229]
SC = [0.6901, 0.6338, 0.0151, 0.6981, 0.4291, 0.7132, 0.0149, 0.1381, 0.3775, 0.5925]
HC = [0.3872, 0.6952, 0.031, 0.5665, 0.3184, 0.0573, 0.0330, 0.1648, 0.0970, 0.2635]
RSSC = [0.7846, 0.6822, 0.4074, 0.8228, 0.6038, 0.7396, 0.6751, 0.3713, 0.4431, 0.7328]

bar_width = 0.1
tick_label = ["1", "2", "3", "4", "5","6","7","8","9","10"]

plt.bar(x,RSC, bar_width, align="center", color="#75bbfd", label="RSC")
plt.bar(x+bar_width, SSSC, bar_width, color='black', align="center", label="SSSC")
plt.bar(x+2*bar_width, RSEC, bar_width, color='#a0febf', align="center", label="RSEC")
plt.bar(x+3*bar_width, Kmeans, bar_width, color='green', align="center", label="Kmeans")
plt.bar(x+4*bar_width, SC, bar_width, color='blue', align="center", label="SC")
plt.bar(x+5*bar_width, HC, bar_width, color='#c7ac7d', align="center", label="HC")
plt.bar(x+6*bar_width, RSSC, bar_width, color='red', align="center", label="RSSC")


plt.xlabel("Datasets",fontsize = 14)
plt.ylabel("NMI",fontsize = 14)
plt.tick_params(labelsize=12)
plt.xticks(x+3*bar_width, tick_label)

plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=4, borderaxespad=0, fancybox=True, shadow=True)

plt.show()