from noisyclustering import loaddata, suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
     NMI, nosioutput_xls,  plot, nosielabel
import numpy as np
from compareway import kmeansspectral, getsssc,  getrsec,getcpsssce
import time
# ##########################不同算法添加不同的噪声比所得出的结果###############################

lparament = []
lgetNMI = []
lacc = []
levaluation = []
lnoisrate1 = []
lnoisrate = []
ltkmeans = []
ltspectlar = []
ltkdd = []
ltconkmeans = []
data = loaddata()
for i in range(21):
    (semidata1, label, inndex) = suTOsemi(data, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列
    (noiseimdata, noisearray, noisenum, randi) = uninoisenorl(semidata1, 0.4, 0, 1, 2)  # #1--高斯噪声，2--均匀噪声
# xls_path = 'F:\\python实验\\result\\seeds-dataset\\result3.xlsx'
    labelssize, labelC = nosielabel(data, noisenum, randi, 2)  # #1--标签在第一列，2--标签在最后一列
# for k in np.arange(30, 40, 1):
#  for bata in np.arange(30, 55, 5):
    cluster_num = 3
    '''
    k = 33
    bata = 50
    start1 = time.clock()
    normalL = getWbyKNNnol(noiseimdata, k)
    Y = getkr(bata, normalL, inndex)
    newnormalL = getnewWbyKNNnol(Y, k)

    c, clf = mapspectral(newnormalL, cluster_num, labelC)
    #noisrate = noiserate(c, labelssize, labelC, noisenum)
    getMIhat, acc = NMI(labelC, c)
    end1 = time.clock()
    
    #print('RSSC运行时间是: %s Seconds'%(end1-start1))
    lgetNMI.append(getMIhat)  # ############NMI组成的总列表
    lacc.append(acc)  # ####################acca组成的总列表
    leval = [getMIhat, acc]
    levaluation.append(leval)
    '''
    #lnoisrate.append(noisrate)  # ##########噪声识别率组成的总列表
    #lconkmeans = getkconstrained(noiseimdata,cluster_num,labelC)
    lkmeans, lspectlar, lkdd, lthc = kmeansspectral(noiseimdata, cluster_num, labelC)
    '''
    start2 = time.clock()
    lsssc = getsssc(noiseimdata, labelC, label, cluster_num, inndex)
    end2 = time.clock()
    print('sssc运行时间是: %s Seconds' % (end2 - start2))
     
    start3 = time.clock()
    lrsec = getrsec(noiseimdata, cluster_num, labelC)
    end3 = time.clock()
    print('RSEC运行时间是: %s Seconds' % (end3 - start3))
    
    start4 = time.clock()
    lcpsssce = getcpsssce(data, noiseimdata, cluster_num, labelC)
    end4 = time.clock()
    print('CPSSSCE运行时间是: %s Seconds' % (end4 - start4))
    
#ltkmeans.append(lkmeans)  # ##对比算法kmeans的NMI,ACC组成的总列标
#ltspectlar.append(lspectlar)  # #对比算法spectral的NMI,ACC组成的总列标
#ltkdd.append(lkdd)  # #比算法kdd的NMI,ACC组成的总列标
#ltconkmeans.append(lconkmeans)  # #对比算法constrainedkmeans组成的NMI,ACC总列表
# nosioutput_xls(lparament, levaluation, lnoisrate)
# duibinnosi_xls(lparament, ltkmeans, ltspectlar, ltkdd)
   '''