from noisyclustering import load_mnist_train, suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
    noiserate, NMI, nosioutput_xls, plot, nosielabel
import numpy as np
from compareway import kmeansspectral, getsssc, getsssc0, getrsec, duibinnosi_xls

# ##########################不同算法添加不同的噪声比所得出的结果###############################
cluster_num = 11
lparament = []
lgetNMI = []
lacc = []
levaluation = []
lnoisrate = []
ltkmeans = []
ltspectlar = []
ltkdd = []
lthc = []
ltsssc = []
ltrsec = []

data = load_mnist_train("E:/Datasets/mnist_dataset")
(semidata1, label, inndex) = suTOsemi(data, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列
# M,C=MClink(5, 5,labels)
norate = 0.4
#for norate in np.arange(0, 1.1, 0.1):
norate = float(format(norate, '.1f'))
(noiseimdata, noisearray, noisenum, randi) = uninoisenorl(semidata1, norate, 0, 255, 2)  # #1--高斯噪声，2--均匀噪声
# xls_path = 'F:\\python实验\\result\\seeds-dataset\\result3.xlsx'
labelssize, labelC = nosielabel(data, noisenum, randi, 2)  # #1--标签在第一列，2--标签在最后一列
# lacc = []
print(norate)
# #############################本方法########################################
lparament.append(norate)  # #########参数组成的总列表
# for k in np.arange(30,40,1):
#  for bata in np.arange(30,55,5):
k = 11
bata = 50
normalL = getWbyKNNnol(noiseimdata, k)
Y = getkr(bata, normalL, inndex)
newnormalL = getnewWbyKNNnol(Y, k)
# c, clf = mapspectral(newnormalL, cluster_num, labelC)
c, clf = mapspectral(newnormalL, cluster_num, labelC)
getMIhat, acc = NMI(labelC, c)
noisrate = noiserate(c, labelssize, labelC, noisenum)
lkmeans, lspectlar, lkdd, lhc = kmeansspectral(noiseimdata, cluster_num, labelC)
lsssc = getsssc(noiseimdata, labelC, label, cluster_num, inndex)
lrsec = getrsec(noiseimdata, cluster_num, labelC)

lgetNMI.append(getMIhat)  # ############NMI组成的总列表
lacc.append(acc)  # ####################acca组成的总列表
leval = [getMIhat, acc]
levaluation.append(leval)
lnoisrate.append(noisrate)  # 噪声识别率
ltkmeans.append(lkmeans)  # ##对比算法kmeans的NMI,ACC组成的总列标
ltspectlar.append(lspectlar)  # #对比算法spectral的NMI,ACC组成的总列标
ltkdd.append(lkdd)  # #比算法kdd的NMI,ACC组成的总列标
lthc.append(lhc)  # 算法层次聚类的NMI，ACC组成的总列表
ltsssc.append(lsssc)  # 算法sssc的NMI，ACC组成的总列表
ltrsec.append(lrsec)  # 算法RSEC的NMI,ACC组成的总列表
print(lnoisrate)
#nosioutput_xls(lparament, levaluation, lnoisrate)
#duibinnosi_xls(lparament, ltkmeans, ltspectlar, ltkdd, lthc, ltsssc, ltrsec)
