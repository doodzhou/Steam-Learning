import gzip
import os
import struct
import numpy as np
from numpy.matlib import rand
import matplotlib.pyplot as plt
import random
import pandas as pd
from noisyclustering import suTOsemi, uninoisenorl, getWbyKNNnol, getkr, getnewWbyKNNnol, mapspectral, \
     NMI, nosioutput_xls, plot, nosielabel,imagedata
import random
from compareway import kmeansspectral, getsssc, getsssc0, getrsec, duibinnosi_xls,getkconstrained,getcpsssce
import time


def load_mnist_train(path, kind='t10k'):
    # path:数据集的路径
    # kind:值为train，代表读取训练集

    labels_path = os.path.join(path, '%s-labels-idx1-ubyte.gz' % kind)
    images_path = os.path.join(path, '%s-images-idx3-ubyte.gz' % kind)
    # 使用gzip打开文件
    with gzip.open(labels_path, 'rb') as lbpath:
        # 使用struct.unpack方法读取前两个数据，>代表高位在前，I代表32位整型。lbpath.read(8)表示一次从文件中读取8个字节
        # 这样读到的前两个数据分别是magic number和样本个数
        magic, n = struct.unpack('>II', lbpath.read(8))
        # 使用np.fromstring读取剩下的数据，lbpath.read()表示读取所有的数据
        labels = np.fromstring(lbpath.read(), dtype=np.uint8)
    with gzip.open(images_path, 'rb') as imgpath:
        magic, num, rows, cols = struct.unpack('>IIII', imgpath.read(16))
        images = np.fromstring(imgpath.read(), dtype=np.uint8).reshape(len(labels), 784)
    data1 = np.insert(images, images.shape[1], values=labels, axis=1)  # 有10000个数据，标签在最后一列
    data = pd.DataFrame(data1)
    unique = np.unique(data.iloc[:, data.shape[1] - 1])
    df1 = pd.DataFrame()
    df2 = pd.DataFrame()
    for imi in range(0, 1):
        data1 = data[data.iloc[:, data.shape[1] - 1] == imi].sample(n=900, axis=0)  # 从1，2标签的数据集里抽取500个
        df1 = df1.append(data1)
    for imi2 in range(1, 10):
        data2 = data[data.iloc[:, data.shape[1] - 1] == imi2].sample(n=30, axis=0)  # 从3-10标签里抽取20个
        df2 = df2.append(data2)
    data12 = df1.values  # 带标签的1，2
    data2to10 = df2.values  # 带标签的
    datalabel = np.vstack((data12, data2to10))
    # labelC = (np.vstack((data12[:, data12.shape[1]-1].reshape(len(data12),1), data2to10[:, data2to10.shape[1]-1].reshape(len(data2to10),1))))
    data2to10 = data2to10[:, 0:data2to10.shape[1] - 1]
    return data12, data2to10, datalabel


def noisenorl(semidata, data2to10, noisenum):
    noisematrix = data2to10
    randi = random.sample(range(0, len(semidata)), noisenum)  # 从mn个数中随机取noisenum个数,noisenum为其他数字图像个数
    noiseindx = []
    for iio in range(noisenum):
        semidata = np.insert(semidata, randi[iio], noisematrix[iio], 0)
        noiseindx.append(randi[iio])
    noiseimdata = semidata
    return noiseimdata, randi


if __name__ == '__main__':
    lparament = []
    lgetNMI = []
    lacc = []
    levaluation = []
    lnoisrate = []
    ltkmeans = []
    ltspectlar = []
    ltkdd = []
    lthc = []
    ltsssc = []
    ltrsec = []
    data12, data2to10, datalabel = load_mnist_train("E:/Datasets1/mnist_dataset")
    cluster_num = 2
    k = 14
    bata = 50
    # labelC = np.array(list(reduce(operator.add, labelC))).reshape((1180,1))
    #labelC =np.array(list(np.array(labelC).flatten()))
    #print(labelC)
    for i in range(11):
        data12 = pd.DataFrame(data12)
        (semidata1, label, inndex) = suTOsemi(data12, 0.9, 2)  # #1--标签在第一列，2--标签在最后一列  # 得到半监督数据
    #noiseimdata = np.vstack((semidata1, data2to10))  # 得到噪声数据
        noiseimdata, randi = noisenorl(semidata1, data2to10, 270)  # 270
    # 得到噪声标签
        labelssize, labelC = nosielabel(data12, 270, randi, 2)  # #1--标签在第一列，2--标签在最后一列
        list(labelC)

        normalL = getWbyKNNnol(noiseimdata, k)
        Y = getkr(bata, normalL, inndex)
        newnormalL = getnewWbyKNNnol(Y, k)
    # c, clf = mapspectral(newnormalL, cluster_num, labelC)
        c, clf = mapspectral(newnormalL, cluster_num, labelC)
        list(c)
    # print(labelC)
        getMIhat, acc = NMI(labelC, c)
        end1 = time.clock()
        list(c)
    #print(labelC)
        #getMIhat, acc = NMI(labelC, c)
    #noisrate = noiserate(c, labelssize, labelC, 270)

        lkmeans, lspectlar, lkdd, lhc = kmeansspectral(noiseimdata, cluster_num, labelC)
    '''
    start2 = time.clock()
    lsssc = getsssc(noiseimdata, labelC, label, cluster_num, inndex)
    end2 = time.clock()
    print('sssc运行时间是: %s Seconds' % (end2 - start2))
    start3 = time.clock()
    lrsec = getrsec(noiseimdata, cluster_num, labelC)
    end3 = time.clock()
    print('RSEC运行时间是: %s Seconds' % (end3 - start3))

    lgetNMI.append(getMIhat)  # ############NMI组成的总列表
    lacc.append(acc)  # ####################acca组成的总列表
    leval = [getMIhat, acc]
    levaluation.append(leval)
    #lnoisrate.append(noisrate)  # 噪声识别率
    ltkmeans.append(lkmeans)  # ##对比算法kmeans的NMI,ACC组成的总列标
    ltspectlar.append(lspectlar)  # #对比算法spectral的NMI,ACC组成的总列标
    ltkdd.append(lkdd)  # #比算法kdd的NMI,ACC组成的总列标
    lthc.append(lhc)  # 算法层次聚类的NMI，ACC组成的总列表
    ltsssc.append(lsssc)  # 算法sssc的NMI，ACC组成的总列表
    ltrsec.append(lrsec)  # 算法RSEC的NMI,ACC组成的总列表
    print(lnoisrate)
    '''