from cgitb import text
from gettext import find

import xlrd
from matplotlib import pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D



########################读取第一个result1表###################################
def read_excel_xls1(path1):
    workbook = xlrd.open_workbook(path1)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI1 = []
    zACC1 = []
    zNoise1 = []
    for i2 in range(1, worksheet.nrows):
        nmi1 = worksheet.cell_value(i2, 1)
        zNMI1.append(nmi1)
        acc1 = worksheet.cell_value(i2, 2)
        zACC1.append(acc1)
        noiserate1 = worksheet.cell_value(i2, 3)
        zNoise1.append(noiserate1)
    zNMI1 = np.array(zNMI1)
    zACC1 = np.array(zACC1)
    zNoise1 = np.array(zNoise1)
    return zNMI1, zACC1, zNoise1

########################读取第二个result1表###################################
def read_excel_xls2(path2):
    workbook = xlrd.open_workbook(path2)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI2 = []
    zACC2 = []
    zNoise2 = []
    for i2 in range(1, worksheet.nrows):
        nmi2 = worksheet.cell_value(i2, 1)
        zNMI2.append(nmi2)
        acc2 = worksheet.cell_value(i2, 2)
        zACC2.append(acc2)
        noiserate2 = worksheet.cell_value(i2, 3)
        zNoise2.append(noiserate2)
    zNMI2 = np.array(zNMI2)
    zACC2 = np.array(zACC2)
    zNoise2 = np.array(zNoise2)
    return zNMI2, zACC2, zNoise2

########################读取第三个result1表###################################
def read_excel_xls3(path3):
    workbook = xlrd.open_workbook(path3)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI3 = []
    zACC3 = []
    zNoise3 = []
    for i3 in range(1, worksheet.nrows):
        nmi3 = worksheet.cell_value(i3, 1)
        zNMI3.append(nmi3)
        acc3 = worksheet.cell_value(i3, 2)
        zACC3.append(acc3)
        noiserate3 = worksheet.cell_value(i3, 3)
        zNoise3.append(noiserate3)
    zNMI3 = np.array(zNMI3)
    zACC3 = np.array(zACC3)
    zNoise3 = np.array(zNoise3)
    return zNMI3, zACC3, zNoise3

########################读取第四个result1表###################################
def read_excel_xls4(path4):
    workbook = xlrd.open_workbook(path4)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI4 = []
    zACC4 = []
    zNoise4 = []
    for i4 in range(1, worksheet.nrows):
        nmi4 = worksheet.cell_value(i4, 1)
        zNMI4.append(nmi4)
        acc4 = worksheet.cell_value(i4, 2)
        zACC4.append(acc4)
        noiserate4 = worksheet.cell_value(i4, 3)
        zNoise4.append(noiserate4)
    zNMI4 = np.array(zNMI4)
    zACC4 = np.array(zACC4)
    zNoise4 = np.array(zNoise4)
    return zNMI4, zACC4, zNoise4

########################读取第五个result1表###################################
def read_excel_xls5(path5):
    workbook = xlrd.open_workbook(path5)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    zNMI5 = []
    zACC5 = []
    zNoise5 = []
    for i5 in range(1, worksheet.nrows):
        nmi5 = worksheet.cell_value(i5, 1)
        zNMI5.append(nmi5)
        acc5 = worksheet.cell_value(i5, 2)
        zACC5.append(acc5)
        noiserate5 = worksheet.cell_value(i5, 3)
        zNoise5.append(noiserate5)
    zNMI5 = np.array(zNMI5)
    zACC5 = np.array(zACC5)
    zNoise5 = np.array(zNoise5)
    return zNMI5, zACC5, zNoise5

########################求5个值的平均值################################
def average(zNMI1, zACC1, zNoise1,zNMI2, zACC2, zNoise2,zNMI3, zACC3, zNoise3,zNMI4, zACC4, zNoise4,zNMI5, zACC5, zNoise5):
    aveNMI=(zNMI1+zNMI2+zNMI3+zNMI4+zNMI5)/5
    aveACC=(zACC1+zACC2+zACC3+zACC4+zACC5)/5
    aveNoise=(zNoise1+zNoise2+zNoise3+zNoise4+zNoise5)/5
    return aveNMI,aveACC,aveNoise
########################画出三维图######################################
def plot(aveNMI,aveACC,aveNoise):

    plt.figure(1)
    norate=np.arange(0, 1.1, 0.1)#3, 40, 2)
    '''
    plt.subplot(2,2,1)
    plt.plot(norate, aveNMI, 'bo-', linewidth=1)
    plt.legend()
    plt.xlabel('norate')
    plt.ylabel('NMI')
    # 设置三个坐标轴信息
    #############ACC#######################
    plt.subplot(2, 2, 2)
    plt.plot(norate, aveACC, 'bo-', linewidth=1)
    plt.legend()
    plt.xlabel('norate')
    plt.ylabel('ACC')
    #############nosiyrate#####################
    plt.subplot(2, 2, 3)
    plt.plot(norate, aveNoise, 'bo-', linewidth=1)
    plt.legend()
    plt.xlabel('norate')
    plt.ylabel('Noiserate')
    '''
    #######################在同一个图中####################
   # plt.subplot(2, 2, 4)
    plt.plot(norate, aveNMI, color='red', label='NMI', ls='solid', marker='*', markersize=7)  # ls或linestyle
    plt.plot(norate, aveACC, color='green', label='ACC', ls='solid', marker='*', markersize=7)
    plt.plot(norate, aveNoise, color='blue', label='Noiserate', ls='solid', marker='*', markersize=7)
    plt.legend(loc='lower right')
    plt.grid(color="k", linestyle=":", axis='y')
    plt.xlabel('Noise percentage', fontsize = 15)
    plt.ylabel('result', fontsize = 15)
    plt.draw()
    plt.show()
    print()


if __name__ == '__main__':
    # ##inoosphere,iris,plrx,seeds-dataset,fertitity,wine,ecoli,glass,breast,colum3d
    path1 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result1.xlsx'
    path2 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result2.xlsx'
    path3 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result3.xlsx'
    path4 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result4.xlsx'
    path5 = 'E:\\seminosiyclustering\\result\\nosirate\\colum3d\\result5.xlsx'
    zNMI1, zACC1, zNoise1 = read_excel_xls1(path1)
    zNMI2, zACC2, zNoise2 = read_excel_xls1(path2)
    zNMI3, zACC3, zNoise3 = read_excel_xls1(path3)
    zNMI4, zACC4, zNoise4 = read_excel_xls1(path4)
    zNMI5, zACC5, zNoise5 = read_excel_xls1(path5)
    aveNMI, aveACC, aveNoise = average(zNMI1,zACC1,zNoise1,zNMI2,zACC2,zNoise2,zNMI3,zACC3,zNoise3,
                                     zNMI4,zACC4,zNoise4,zNMI5,zACC5,zNoise5)
    plot(aveNMI, aveACC, aveNoise)
    #togplot(aveNMI, aveACC, aveNoise)

