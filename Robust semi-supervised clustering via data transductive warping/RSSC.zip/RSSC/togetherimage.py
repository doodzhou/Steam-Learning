import xlrd
from matplotlib import pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
'''
fig1 = plt.figure()
ax1 = Axes3D(fig1)
fig2 = plt.figure()
ax2 = Axes3D(fig2)
fig3 = plt.figure()
ax3 = Axes3D(fig3)
'''
def read_excel_xlsNMI(path):
    workbook = xlrd.open_workbook(path)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    k =np.arange(3, 40, 2)
    bata=np.arange(1,70,4)
    k,bata=np.meshgrid(k, bata)
    zNMI=[]
    zACC=[]
    zNoiserate=[]
    for i in range(1, worksheet.nrows):
        z1 = worksheet.cell_value(i, 2)
        zNMI.append(z1)
        z2 = worksheet.cell_value(i, 3)
        # z3 = worksheet.cell_value(i, 4)
        zACC.append(z2)
        z3 = worksheet.cell_value(i, 4)
        zNoiserate.append(z3)
    zNMI=np.array(zNMI)
    zNMI=zNMI.reshape(18,19)
    zACC = np.array(zACC)
    zACC = zACC.reshape(18, 19)
    zNoiserate = np.array(zNoiserate)
    zNoiserate = zNoiserate.reshape(18, 19)
    ############绘制NMI####################
    fig = plt.figure()#figsize=plt.figaspect(0.5)
    ax = fig.add_subplot(3, 1, 1, projection='3d')
    ax.plot_surface(k,bata, zNMI, cmap='rainbow')
          # 设置三个坐标轴信息
    ax.set_xlabel('', color='b')
    ax.set_ylabel('bata', color='g')
    ax.set_zlabel('NMI', color='r')
    #############ACC#######################
    ax = fig.add_subplot(3,1,2, projection='3d')
    ax.plot_surface(k, bata, zACC, cmap='rainbow')
    # 设置三个坐标轴信息
    ax.set_xlabel('p', color='b')
    ax.set_ylabel('bata', color='g')
    ax.set_zlabel('ACC', color='r')
    #############nosiyrate#####################
    ax = fig.add_subplot(3,1,3, projection='3d')
    ax.plot_surface(k, bata, zNoiserate, cmap='rainbow')
    # 设置三个坐标轴信息
    ax.set_xlabel('p', color='b')
    ax.set_ylabel('bata', color='g')
    ax.set_zlabel('Noiserate', color='r')
    plt.draw()
    plt.show()

    print()

if __name__ == '__main__':
    path='F:\\python实验\\result\\ecoli\\result1.xlsx'
    read_excel_xlsNMI(path)
