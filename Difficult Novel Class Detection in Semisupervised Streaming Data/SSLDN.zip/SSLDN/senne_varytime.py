# -*- coding: utf-8 -*-

from usfSeen.Update import *
from usfSeen2.SENNE.model import *
import time
import numpy as np
from sklearn.metrics import precision_score, recall_score, accuracy_score

import warnings

warnings.filterwarnings('ignore')
np.random.seed(0)  # for demo reproducibility


def evaluate_acc_f1(truth, preds):
    acc = accuracy_score(truth, preds)
    precision = precision_score(truth, preds, average='macro')
    recall = recall_score(truth, preds, average='macro')
    f1 = 2 * precision * recall / (precision + recall)

    print(f"acc={acc:.4f} f1={f1:.4f}")


def load_data1(period_num, ratio):
    file_name = 'E://tow-paper//datasets//MNIST/' + 'varyalpha_' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    Y = data[:, data.shape[1] - 1]
    label_state = np.zeros((len(Y), 1))
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui) - 1):
        if period_num == 1:
            bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
            label_state[0:2] = 1
        else:
            bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


def load_data(period_num, ratio):
    file_name = 'E://tow-paper//datasets//MNIST//' + 'varyalpha_' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    Y = data[:, data.shape[1] - 1]
    label_state = np.zeros((len(Y), 1))
    # fore_index = 3
    # now_index = fore_index + period_num - (period_num-1)
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)):
        bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


if __name__ == '__main__':
    X0, Y0, label_state0 = load_data(0, 0.01)  # 初始训练集
    num_samples = 100  # number of set
    sample_size = 20  # subsample size for each set
    CurtNumDim = X0.shape[1]
    newclass_num = 1
    all_truth = []
    all_preds = []
    train_num =2
    time_begin = time.time()

    X, Y, label_state = load_data1(1, 0.01)  # 当前时期的文件
    # 初始化模型，senne的初始化模型是根据上一个判断过的数据建立的
    traindata = np.concatenate((X0, Y0.reshape((len(Y0), 1))), axis=1)
    # ################到此初始模型建立完成###################
    streamdata = X
    streamdatalabel = Y
    max_num = max(np.unique(streamdatalabel))
    for i in range(len(streamdatalabel)):
        if streamdatalabel[i] == max_num:
            streamdatalabel[i] = 999
    for j in streamdatalabel:
        all_truth.append(j)
    # #############准备工作完成########################
    original_begin = time.time()
    model3 = model_SENNE(traindata, num_samples, sample_size, CurtNumDim)
    print(f"seen的c初始化模型时间 time={time.time() - original_begin:.4f}s")
    buffsize = 300
    score_threshold = 0.88
    detector_time = time.time()
    result_label, after_model, axis_point = Predict(train_num, streamdata, streamdatalabel, buffsize, model3,
                                                    score_threshold, num_samples, sample_size)
    print(f"senne的本次运行时间 time={time.time() - detector_time:.4f}s")
    for jj in result_label:
        all_preds.append(jj)
    label_com = np.zeros((len(result_label), 2))
    label_com[:, 0] = result_label[:, 0]
    label_com[:, 1] = streamdatalabel
    evaluate_acc_f1(label_com[:, 1], label_com[:, 0])


