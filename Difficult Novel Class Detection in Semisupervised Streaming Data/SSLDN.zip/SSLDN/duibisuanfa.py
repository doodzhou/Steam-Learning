from usfSeen2.SdndcForest2 import *
from usfSeen2.SdndcLP4 import *
import pandas as pd
from sklearn.metrics import precision_score, recall_score, accuracy_score


# ######################各个算法进行比较##########################
# ######################前提条件准备，数据集和实验参数设置########################


def evaluate_acc_f1(truth, preds):
    acc = accuracy_score(truth, preds)
    precision = precision_score(truth, preds, average='macro')
    recall = recall_score(truth, preds, average='macro')
    f1 = 2 * precision * recall / (precision + recall)

    print(f"acc={acc:.4f} f1={f1:.4f}")


def load_data1(period_num, ratio):
    file_name = 'E://tow-paper//datasets//pendigits//' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    Y = data[:, data.shape[1] - 1]
    label_state = np.zeros((len(Y), 1))
    label_state[0:3] = 1
    ui = np.unique(Y)
    for i in range(len(ui) - 1):
        if period_num == 1:
            bb = [k for k in range(3, len(Y)) if Y[k] == ui[i]]
            label_state[0:3] = 1
        else:
            bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


def load_data(period_num, ratio):
    file_name = 'E://tow-paper//datasets//pendigits//' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    Y = data[:, data.shape[1] - 1]
    label_state = np.zeros((len(Y), 1))
    # fore_index = 3
    # now_index = fore_index + period_num - (period_num-1)
    label_state[0:3] = 1
    ui = np.unique(Y)
    for i in range(len(ui)):
        bb = [k for k in range(3, len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


import time


# ######################自己的算法################################
def usfSeen(X, Y, label_state, model, detector, all_sample_instance):
    # period_begin1 = time.time()
    outlier_buffer = []
    outlier_buffer_size = 80
    newclass = []
    period_pred = []
    period_truth = []
    outlier_num = 0
    update_outlier = False
    period_truth.append(Y.tolist())  # 每一个时期的真实标签
    ui = np.unique(Y)  # 每个时期的标签有哪些[1,2,3]
    for iu in range(X.shape[0]):
        ret = False
        if label_state[iu] == 1:
            model.add_label_sample(X[iu], Y[iu])
            period_pred.append(Y[iu])
            # all_preds.append(Y[iu])
        else:
            if update_outlier:
                y_label = model.run(X[iu])
                cur_pred = y_label.tolist()[0]
                if ui[0] == 1:
                    cur_pred = cur_pred + 1
            else:
                ret = detector.xpredict(X[iu])
                if ret:  # 如果ret为True,则为新类
                    outlier_buffer.append(X[iu])
                    # all_sample_instance.append(unlabel_data[iu])
                    newclass.append(max(ui))
                    cur_pred = max(ui)  # 新类的标签为在原来最大值的类的标签上加1
                    outlier_num += 1
                else:  # 如果ret为False，则为已知类
                    y_label = model.run(X[iu])
                    cur_pred = y_label.tolist()[0]
                    if ui[0] == 1:
                        cur_pred = cur_pred + 1

            # all_preds.append(cur_pred)  # 存放所有预测的标签
            period_pred.append(cur_pred)  # 存放每个时期预测的标签
            all_sample_instance.append(X[iu])  # 添加这个时期的判断过的无标签的样本
        if update_outlier == False and outlier_num == outlier_buffer_size:
            outlier_num = 0
            # ui = np.insert(ui, len(ui), max(ui) + 1, axis=0)  # 已知标签更新[1,2,3,4]
            # outlier_buffer = np.array(outlier_buffer)
            # new_label_data = np.insert(outlier_buffer, outlier_buffer.shape[1], len(ui), axis=1)
            # selected_outlier_num = int(len(outlier_buffer) * 0.04)
            selected_outlier_num = 5
            model.update_outlier(outlier_buffer, ui[-1], selected_outlier_num)
            detector.update(all_sample_instance)
            # outlier_buffer = []
            update_outlier = True
            # print(f"usfseen的更新时间 time={time.time() - updata_time1:.4f}s")
    model.reserve_sample()
    # print(f"usfSeen的本次时期的运行时间 time={time.time() - period_begin1:.4f}s")
    # print(f"usfSeen的本次时期的运行时间 time={time.time() - period_begin1:.4f}s")
    # print("period_truth", period_truth)
    # print("period_pred", period_pred)

    evaluate_acc_f1(period_truth[0], period_pred)
    if update_outlier == False:
        outlier_num = 0
        print("开始更新啦2")
        detector.update(all_sample_instance)
        # model = SeenLP(options, label_data, know_label)
        selected_outlier_num = 5
        model.update_outlier(outlier_buffer, ui[-1], selected_outlier_num)
        detector.update(all_sample_instance)
        # outlier_buffer = []
        update_outlier = True


def seen(X, Y, label_state, model, detector, all_preds, all_truth, all_sample_instance, all_sample_weight):
    # period_begin = time.time()
    all_labels = list(set(Y))
    # print("Y, label_state:",Y, label_state)
    # print("Y:", Y)
    proid_lab = []
    proid_tru = []
    proid_tru.append(Y.tolist())
    reserve_num = 1000
    outlier_buffer_size = 50
    selected_outlier_num = 10
    new_weight = 3.0
    reduce_weight = 0.5
    ui = np.unique(Y)
    n = X.shape[0]
    outlier_buffer = []
    outlier_num = 0
    update_outlier = False
    period_known_right, period_known_num = 0, 0
    period_new_right, period_new_num = 0, 0
    for i in range(n):
        ret = False
        if label_state[i] == 1:
            model.add_labeled_sample(X[i], Y[i])
            proid_lab.append(Y[i])
        else:
            if update_outlier:
                cur_preds = np.argmax(model.predict(X[i]))
            else:
                ret = detector.predict(X[i])
                if ret:
                    outlier_buffer.append(X[i])
                    cur_preds = ui[-1]
                    outlier_num += 1
                else:
                    cur_preds = np.argmax(model.predict(X[i]))
            proid_lab.append(cur_preds)
            all_preds.append(cur_preds)
            all_truth.append(Y[i])

        if label_state[i] == 1 or update_outlier or ret == False:
            all_sample_instance.append(X[i])
            all_sample_weight.append(1.0)
        else:
            all_sample_instance.append(X[i])
            all_sample_weight.append(new_weight)

        if update_outlier == False and outlier_num == outlier_buffer_size:
            # update_detector_begin = time.time()
            model.update_outlier(outlier_buffer, ui[-1], selected_outlier_num)
            detector.update(all_sample_instance, all_sample_weight)
            all_sample_num = len(all_sample_instance)
            reserve_num = min(all_sample_num, reserve_num)
            normalized_weight = np.array(all_sample_weight) / sum(all_sample_weight)
            reserve_id = np.random.choice(all_sample_num, reserve_num, replace=False, p=normalized_weight)
            array_instance = np.array(all_sample_instance)
            array_weight = np.array(all_sample_weight)
            all_sample_instance = list(array_instance[reserve_id, :])
            all_sample_weight = list(array_weight[reserve_id,] * reduce_weight)
            update_outlier = True
            # print(f"usfseen的更新时间 time={time.time() - update_detector_begin:.4f}s")
            # model.reserve_sample()
            # print(f"usfSeen的本次时期的运行时间 time={time.time() - period_begin:.4f}s")
    evaluate_acc_f1(proid_tru[0], proid_lab)

    if update_outlier == False:
        # update_detector_begin = time.time()
        model.update_outlier(outlier_buffer, ui[-1], selected_outlier_num)
        detector.update(all_sample_instance, all_sample_weight)
        all_sample_num = len(all_sample_instance)
        reserve_num = min(all_sample_num, reserve_num)
        normalized_weight = np.array(all_sample_weight) / sum(all_sample_weight)
        reserve_id = np.random.choice(all_sample_num, reserve_num, replace=False, p=normalized_weight)
        array_instance = np.array(all_sample_instance)
        array_weight = np.array(all_sample_weight)
        all_sample_instance = list(array_instance[reserve_id, :])
        all_sample_weight = list(array_weight[reserve_id,] * reduce_weight)
        update_outlier = True

    # print(f"time={time.time() - period_begin:.4f}s")


from usfSeen2.SENNE.model import Predict


def senne(train_num, streamdata, streamdatalabel, Model):
    # period_begin = time.time()
    buffsize = 300
    score_threshold = 0.88
    result_label, after_model, axis_point = Predict(train_num, streamdata, streamdatalabel, buffsize, Model,
                                                    score_threshold)
    print('SENNE predict complete!')
    label_com = np.zeros((len(result_label), 2))
    label_com[:, 0] = result_label[:, 0]
    label_com[:, 1] = streamdatalabel
    evaluate_acc_f1(label_com[:, 1], label_com[:, 0])
    # print(f"time={time.time() - period_begin:.4f}s")


from usfSeen2.SNECMas.detector import *


def snecmas(X, Y, label_state, X0, global_mat, local_mat, threshold, Q):
    global cur_label
    # global_mat, local_mat = getMatrixSketch(X0)  # 用的是初始训练集
    # period_begin = time.time()
    update_outlier = False
    proid_lab = []
    proid_tru = [Y.tolist()]
    outlier_buffer_size = 100
    ui = np.unique(Y)
    knowlabel = ui[0:len(ui) - 1]
    n = X.shape[0]
    outlier_buffer = []
    outlier_num = 0
    # threshold, Q = thres(X0, global_mat)
    for i in range(n):
        if update_outlier:
            y_label = classifiy(X[i], knowlabel, local_mat)
            proid_lab.append(y_label)
        else:
            puxi = detector(X[i], global_mat)
            if puxi < threshold:
                cur_label = ui[-1]  # 如果puxi<threshold,说明X[i]是新类
                outlier_buffer.append(X[i])
                outlier_num = outlier_num + 1
            else:
                y_label = classifiy(X[i], knowlabel, local_mat)
                cur_label = y_label
            proid_lab.append(cur_label)

        if outlier_num == outlier_buffer_size and update_outlier == False:
            newclass, knowclass = SDdiff(outlier_buffer, global_mat)
            new_threshold, newglobal_mat, local_mat = updata(global_mat, local_mat, Q, X0, newclass, outlier_buffer)
            threshold = new_threshold
            global_mat = newglobal_mat
            local_mat = local_mat
            knowlabel = ui  # 已知标签更新[1,2,3,4]
            update_outlier = True
    evaluate_acc_f1(proid_tru[0], proid_lab)
    # print(f"time={time.time() - period_begin:.4f}s")


from usfSeen2.ORSSL.updata import *
from sklearn.neighbors import NearestNeighbors
from usfSeen2.ORSSL.createMC import createMC
from usfSeen2.ORSSL.classify import classify


def orssl(X, Y, label_state, Model):
    # train_cls_lb = unique(train_data_labels)
    # Model = initial_model_construction(train_data, train_cls_lb)
    # period_begin = time.time()
    maxMC = 1000  # % maximum number of micro - clusters
    num_cluster = 50  # % number of clusters per class
    lamda = 0.000002  # % 000002[2 K 0.06] decay rate
    wT = 0.06
    weight = np.ones((3, 1))  # classifier weight
    acc_win_max_size = 100  # accuracy window size
    num_of_knn = 4  # number of kNN classifiers
    acc_win = np.zeros((num_of_knn, 1))  # accuracy window
    n = X.shape[0]
    correct = 0
    proid_lab = []
    proid_tru = [Y.tolist()]
    # test_data_labels = np.concatenate((Y, label_state), axis=1)
    for i in range(n):
        ex = [[] for _ in range(3)]
        ex[0] = X[i]
        ex[1] = Y[i]
        ex[2] = label_state[i]
        CurrentTime = i
        p_label, idx = classify(ex, Model, weight, num_of_knn)
        idx = idx[0][0]
        proid_lab.append(p_label)
        if p_label == ex[1]:
            correct = correct + 1
        if ex[2] == 1:
            nrb_labels = np.array(Model)[idx, 3]
            con_label = idx[nrb_labels == ex[1]]
            incon_label = idx[nrb_labels != ex[1]]
            np.array(Model)[con_label[0], 8] = np.array(Model)[int(con_label[0]), 8] + 1
            np.array(Model)[con_label[0], 7] = CurrentTime
            np.array(Model)[incon_label, 8] = np.array(Model)[incon_label, 8] - 1
        newModel = update_Model(Model, CurrentTime, lamda, wT)
        clu_cen = np.array(Model)[:, 5]
        clu_cent = []
        for ii in clu_cen:
            clu_cent.append(ii)
        clu_cent = np.array(clu_cent)
        neigh = NearestNeighbors(n_neighbors=1)
        neigh.fit(clu_cent)
        D, idx = neigh.kneighbors(ex[0].reshape(1, -1))  # D是最近邻矩阵的值，idx:最近邻的索引号
        idx = idx[0][0]
        D = D[0][0]
        r = np.array(newModel)[idx, 6]
        if D <= r and ex[2] == 1 and ex[1] == np.array(Model)[idx, 3] or D <= r and ex[2] != 1:
            newModel = update_micro(newModel, ex, idx, CurrentTime)
        else:
            newModel = createMC(newModel, ex, r, CurrentTime, maxMC)
        Model = newModel
    evaluate_acc_f1(proid_tru[0], proid_lab)
    # print(f"time={time.time() - period_begin:.4f}s")


from usfSeen2.IForestKNN.iforest import *
from sklearn import neighbors
from sklearn import svm


def iforestknn(X, Y, label_state, clf, ssvm, Average_score):
    # period_begin = time.time()
    proid_lab = []
    proid_tru = [Y.tolist()]
    # clf = IsolationForest()
    # clf.fit(X, n_samples=256)
    # Average_score = sum(clf.predict(X)) / len(X)
    # xi_score = clf._predict(b)
    ui = np.unique(Y)
    n = X.shape[0]
    for i in range(n):
        if label_state[i] == 1:
            proid_lab.append(Y[i])
        else:
            xi_score = clf._predict(X[i])
            if xi_score < Average_score:  # 说明xi是正常值
                # 调用KNN的分类器
                # knn = neighbors.KNeighborsClassifier()
                # knn.fit(X, Y)
                predictedLabel = ssvm.predict([X[i]])
                proid_lab.append(predictedLabel[0])
            else:
                proid_lab.append(ui[-1])
    evaluate_acc_f1(proid_tru[0], proid_lab)
    # print(f"time={time.time() - period_begin:.4f}s")


from usfSeen2.LOFsvm.lofsvm import *
from sklearn.metrics import pairwise_distances


def lofsvm(X, Y, label_state, ssvm):  # , D, KNN, KNN_indices
    # period_begin = time.time()
    proid_lab = []
    proid_tru = [Y.tolist()]
    # clf = IsolationForest()
    # clf.fit(X, n_samples=256)
    # Average_score = sum(clf.predict(X)) / len(X)
    # xi_score = clf._predict(b)
    ui = np.unique(Y)
    n = X.shape[0]
    # pairwise distances between all points
    D = pairwise_distances(X)
    # K-nearest neighbors distances for each point (by row)
    KNN = np.sort(D, axis=1)
    # K-nearest neighbor indices for each points (by row)
    KNN_indices = np.argsort(D, axis=1)
    for i in range(n):
        if label_state[i] == 1:
            proid_lab.append(Y[i])
        else:
            xi_score = LOF_k(i, 50, KNN, D, KNN_indices)
            if xi_score < 1:  # 说明xi是正常值
                # 调用KNN的分类器
                # knn = neighbors.KNeighborsClassifier()
                # knn.fit(X, Y)
                predictedLabel = ssvm.predict([X[i]])
                proid_lab.append(predictedLabel[0])
            else:
                proid_lab.append(ui[-1])
    evaluate_acc_f1(proid_tru[0], proid_lab)