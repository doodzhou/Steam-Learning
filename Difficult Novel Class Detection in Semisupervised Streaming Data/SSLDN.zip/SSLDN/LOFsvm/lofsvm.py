import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import pairwise_distances

print(__doc__)

np.random.seed(42)

# Generate train data
# pairwise distances between all points
# D = pairwise_distances(X)
# K-nearest neighbors distances for each point (by row)
# KNN = np.sort(D,axis=1)
# K-nearest neighbor indices for each points (by row)
# KNN_indices = np.argsort(D,axis=1)


# Get the k-nearest neighbor for object p
def k_distance(p, k, KNN):
    return KNN[p][1:][k]


# Get all objects o within k_distance of object p
def N_k_distance(p,k_distance, KNN, KNN_indices):
    idx = np.where(KNN[p]<=k_distance)[0][1:]
    return KNN_indices[p][idx]


# get the reach_dist of object p wrt object o (the maximum gives a smooth factor to the distances, reduce statistical fluctation)
def reach_dist_k(p,o,k,D, KNN):
    return np.max([k_distance(o,k, KNN),D[p,o]])


# local reachability density of object p (smaller is more spread out points, larger is tight cluster of points)
def lrd_k(p, k, KNN,D, KNN_indices):
    N_MinPts = N_k_distance(p, k_distance(p, k, KNN), KNN, KNN_indices)

    return 1 / (np.sum([reach_dist_k(p, o, k,D, KNN) for o in N_MinPts]) / len(N_MinPts))


# local outlier factor (determine degree of outliernish) of object p
# value < 1 means similar density as neighbors (probably inlier, maybe not)
# value ~= 1 means similar density as outliers (inliers)
# value > 1 means lower density than neighbors (outliers)
def LOF_k(p, k, KNN,D, KNN_indices):
    N_MinPts = N_k_distance(p, k_distance(p, k, KNN), KNN, KNN_indices)
    lrd_p = lrd_k(p, k, KNN,D, KNN_indices)
    score = (np.sum([lrd_k(o, k, KNN,D, KNN_indices) / lrd_p for o in N_MinPts])) / len(N_MinPts)

    return score

'''
X_scores = []
outlier = []
for i in range(len(X)):
    X_scores.append(LOF_k(i,20))
    if LOF_k(i,20) >1:
        outlier.append(X_scores)
X_scores = np.array(X_scores)
'''
