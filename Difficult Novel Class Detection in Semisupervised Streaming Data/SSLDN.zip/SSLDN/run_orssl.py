# -*- coding: utf-8 -*-

import pandas as pd
from usfSeen2.ORSSL.initialmodel import *
from usfSeen2.ORSSL.classify import *
from usfSeen2.ORSSL.createMC import *
from usfSeen2.ORSSL.updata import *
import time
import numpy as np
from sklearn.metrics import precision_score, recall_score, accuracy_score

import warnings
warnings.filterwarnings('ignore')
np.random.seed(0)  # for demo reproducibility


def evaluate_acc_f1(truth, preds):
    acc = accuracy_score(truth, preds)
    precision = precision_score(truth, preds, average='macro')
    recall = recall_score(truth, preds, average='macro')
    f1 = 2 * precision * recall / (precision + recall)

    print(f"acc={acc:.4f} f1={f1:.4f}")


def load_data1(period_num, ratio):
    file_name = 'E://tow-paper//datasets//pendigits/' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)-1):
        if period_num == 1:
            bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
            label_state[0:2] = 1
        else:
            bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


def load_data(period_num, ratio):
    file_name = 'E://tow-paper//datasets//pendigits//' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    # fore_index = 3
    # now_index = fore_index + period_num - (period_num-1)
    ui = np.unique(Y)
    for i in range(len(ui)):
        bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


if __name__ == '__main__':
    all_truth = []
    all_preds = []
    time_begin = time.time()
    for period in range(3, 4):
        print(f"------ period: {period} ", end=" ")
        X0, Y0, label_state0 = load_data(period-1, 0.01)  # 初始训练集
        traindata = np.concatenate((X0, Y0.reshape((len(Y0), 1))), axis=1)
        train_cls_lb = np.unique(Y0)
        num_cluster = 50
        Model = initial_model_construction(traindata, train_cls_lb, num_cluster)
        print("Model",Model)
        X, Y, label_state = load_data1(period, 0.01)  # 当前时期的文件
        maxMC = 1000  # % maximum number of micro - clusters
        num_cluster = 50  # % number of clusters per class
        lamda = 0.000002  # % 000002[2 K 0.06] decay rate
        wT = 0.06
        weight = np.ones((3, 1))  # classifier weight
        acc_win_max_size = 100  # accuracy window size
        num_of_knn = 4  # number of kNN classifiers
        acc_win = np.zeros((num_of_knn, 1))  # accuracy window
        n = X.shape[0]
        correct = 0
        for j in Y:
            all_truth.append(j)
        proid_lab = []
        proid_tru = [Y.tolist()]
        period_begin = time.time()
        for i in range(n):
            ex = [[] for _ in range(3)]
            ex[0] = X[i]
            ex[1] = Y[i]
            ex[2] = label_state[i]
            CurrentTime = i
            p_label, idx = classify(ex, Model, weight, num_of_knn)
            idx = idx[0][0]
            proid_lab.append(p_label)
            all_preds.append(p_label)
            if p_label == ex[1]:
                correct = correct + 1
            if ex[2] == 1:
                nrb_labels = np.array(Model)[idx, 3]
                print("nrb_labels",nrb_labels)
                con_label = idx[nrb_labels == ex[1]]
                print("con_label", con_label)
                incon_label = idx[nrb_labels != ex[1]]
                print("incon_label", incon_label)
                np.array(Model)[con_label[0], 8] = np.array(Model)[int(con_label[0]), 8] + 1
                np.array(Model)[con_label[0], 7] = CurrentTime
                np.array(Model)[incon_label, 8] = np.array(Model)[incon_label, 8] - 1
            # updata_time1 = time.time()
            newModel = update_Model(Model, CurrentTime, lamda, wT)
            # print(f"orssl的模型更新时间 time={time.time() - updata_time1:.4f}s")
            clu_cen = np.array(Model)[:, 5]
            clu_cent = []
            for ii in clu_cen:
                clu_cent.append(ii)
            clu_cent = np.array(clu_cent)
            neigh = NearestNeighbors(n_neighbors=1)
            neigh.fit(clu_cent)
            D, idx = neigh.kneighbors(ex[0].reshape(1, -1))  # D是最近邻矩阵的值，idx:最近邻的索引号
            idx = idx[0][0]
            D = D[0][0]
            r = np.array(newModel)[idx, 6]
            if D <= r and ex[2] == 1 and ex[1] == np.array(Model)[idx, 3] or D <= r and ex[2] != 1:
                # updata_time2 = time.time()
                newModel = update_micro(newModel, ex, idx, CurrentTime)
                # print(f"orssl的微簇更新时间 time={time.time() - updata_time2:.4f}s")
            else:
                newModel = createMC(newModel, ex, r, CurrentTime, maxMC)
            Model = newModel
        evaluate_acc_f1(proid_tru[0], proid_lab)
        print(f"orssl本次的运行时间 time={time.time() - period_begin:.4f}s")
    evaluate_acc_f1(all_truth, all_preds)
    time_end = time.time() - time_begin
    print(f"time = {time_end:.3f}s")












