import numpy as np
from scipy.linalg import svd


def frequent_directions(A, ell, verbose=False):
    """
    Return the sketch of matrix A.
    Parameters
    ----------
    A : array-like, shape = [n_samples, n_features]
        Input matrix.
    ell : int
        Number of rows in the matrix sketch.
    Returns
    -------
    B : array-like, shape = [ell, n_features]
    Reference
    ---------
    Edo Liberty, "Simple and Deterministic Matrix Sketching", ACM SIGKDD, 2013.
    """
    n_samples, n_features = A.shape[0], A.shape[1]
    if ell > n_samples:
        raise ValueError("ell must be less than n_samples.")

    B = np.zeros((ell, n_features), dtype=np.float64)
    ind = np.arange(ell)
    # zero_rows = ind[np.sum(np.abs(B) <= 1e-12, axis=1) == n_features].tolist()
    for i in range(n_samples):
        zero_rows = ind[np.sum(np.abs(B) <= 1e-12, axis=1) == n_features]
        if len(zero_rows) >= 1:
            B[zero_rows[0]] = A[i]
            # zero_rows.remove(zero_rows[0])
        else:
            U, sigma, V = np.linalg.svd(B, full_matrices=False)
            delta = sigma[len(sigma) // 2] ** 2
            sigma = np.sqrt(np.maximum(sigma ** 2 - delta, 0))
            B = np.dot(np.diag(sigma), V)
            break

    return B


if __name__ == '__main__':
    np.random.seed(0)
    A = np.random.random((10, 20))

    B = frequent_directions(A, 8, verbose=True)
    print (B.shape)