import numpy as np
from usfSeen2.SNECMas.MatrixSketching import *
"""
Streaming Classification with Emerging New Class by Class Matrix Sketching
AAAI-17
"""


# # 得到全局数据和局部数据的矩阵草图
def getMatrixSketch(data):
    m, n = data.shape
    alldata = data[:, 0:n - 1]
    alllabel = data[:, -1]
    uique_label = np.unique(alllabel)
    global_mat = frequent_directions(alldata, int(len(data) * 0.8), verbose=True)  # 得到的是无标签的全局矩阵草图
    local_mat = [[] for _ in range(len(uique_label))]
    for ilabel in range(len(uique_label)):
        fea_ilabel = alldata[alllabel == uique_label[ilabel]]
        local_mat[ilabel] = frequent_directions(fea_ilabel, int(len(fea_ilabel) * 0.8), verbose=True)
        # local_mat:有len(uique_label)个列表的无标签的局部矩阵草图
    return global_mat, local_mat


# ########x与A之间的内积，最后得到一个最大值
def neiji(x, A):
    pu = np.dot(x, A[0])
    for i in range(1, A.shape[0]):
        every = np.dot(x, A[i])
        if every > pu:
            pu = every
    return pu


def thres(data, global_mat):
    num1, num2 = data.shape
    Q = []
    alldata = data[:, 0:num2 - 1]
    alllabel = data[:, num2 - 1]
    for iall in range(num1):
        eve_pu = neiji(alldata[iall], global_mat)
        Q.append(eve_pu)
    threshold = sum(Q) / len(Q)
    return threshold, Q


def detector(x, global_mat):
    buffer = []
    # x与global_mat的每行做内积，得到一个最大值
    puxi = neiji(x, global_mat)
    return puxi


def classifiy(x, ui_label, local_mat):
    phi = []
    for i in range(len(local_mat)):
        eve_phi = neiji(x, local_mat[i])
        phi.append(eve_phi)
    # print("phi,ui_label",phi,ui_label)
    y_label = ui_label[phi.index(max(phi))]
    return y_label


def updata(global_mat, local_mat, Q, X0, newclass, buffer):
    #
    #  B'is a sub set of B including k new class instances
    # subindex = np.random.choice(len(buffer), int(len(buffer) * ratio), replace=False)
    # subindex = sorted(subindex)
    buffer = np.array(buffer)
    # subbuffer = buffer[subindex, :]

    newX0 = np.concatenate((X0, buffer), axis=0)
    # Q'is a list like in Eqn.(5) with respect to B'
    newQ = []
    for i in range(len(newclass)):
        eve_ph = neiji(newclass[i], global_mat)
        newQ .append(eve_ph)
    # 计算新的阈值
    new_threshold = (sum(Q) + sum(newQ))/(len(Q) + len(newQ))
    # 计算新的全局草图
    newglobal_mat = frequent_directions(newX0, int(len(newX0) * 0.8), verbose=True)  # 得到的是无标签的全局矩阵草图
    # 计算新的局部草图
    newlocal_mat = frequent_directions(newclass, int(len(newclass) * 0.8), verbose=True)
    # 新的矩阵草图与原先的草图合并
    local_mat.append(newlocal_mat)

    return new_threshold, newglobal_mat, local_mat


def SDdiff(buffer, global_mat):
    V = []
    buffer = np.array(buffer)
    for i in range(len(buffer)):
        eve_ph = neiji(buffer[i], global_mat)
        V.append(eve_ph)
    V = sorted(V)
    savestd = []
    for iv in range(1, len(V)):
        liststd = abs(np.std(V[:iv]) - np.std(V[-(len(V) - iv):]))
        savestd.append(liststd)
    splitpoint = savestd.index(min(savestd))  # 得到分裂点
    V = np.array(V)
    inds = V.argsort()
    buffer = buffer[inds]
    newclass = buffer[:splitpoint, :]
    knowclass = buffer[splitpoint:, :]
    return newclass, knowclass





















