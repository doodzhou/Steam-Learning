# -*- coding: utf-8 -*-

import numpy as np
import random
import sys, os
import pickle
import time
from SEEN import config


class Node:
    def __init__(self, fea=None, center=None, radius=0, selected_fea=None,
                 lcenter=None, rcenter=None, lson=None, rson=None, root_dist=0, size=0):
        self.fea            = fea               # feature vector
        self.center         = center            # the center of current node
        self.radius         = radius            # the range that current node covers
        self.selected_fea   = selected_fea      # selected feature id to divide instances

        self.size           = size              # number of instances in the node 节点中的实例数
        self.lcenter        = lcenter           # center of k-means for left son tree
        self.rcenter        = rcenter           # center of k-means for right son tree
        self.lson           = lson              # left son id
        self.rson           = rson              # right son id

        self.root_dist      = root_dist         # distance between current node and root node, namely the depth of current node


class Tree:
    def __init__(self, fea=None):
        self.fea            = fea               # all feature vector of current tree
        self.tree_size      = config.tree_size  # number of nodes of current tree, which is fixed in advance

        self.k_fea          = (fea.shape[1] + 1) // 2               # number of randomly selected features to divide instances
        self.max_height     = int(np.ceil(np.log2(self.tree_size))) # maximum tree height, which is fixed in advance

        self.min_leaf_size  = config.min_leaf_size                  # minimum instances in leaf node, which is fixed in advance

        self.nodes          = []                # store each nodes
        self.leaf_type      = [0, 0, 0, 0]

        self.root = self.build_tree(fea, 0)  # build tree

        self.leaf_dist = []
        self.node_dist = []
        for node in self.nodes:
            self.node_dist.append(node.root_dist)
        self.node_dist_mean = np.mean(self.node_dist)

    def same_fea_preds(self, fea):
        n, dim1 = fea.shape[0], fea.shape[1]
        for i in range(1, n):
            if sum(fea[i] == fea[0]) != dim1:  # 当fea[i]的每一项都与fea[0]相同时，sum(fea[i] == fea[0])就等于数据的维度
                return False
        return True

    def get_distance(self, x1, x2):
        # assert 用来声明哪个条件为真
        assert x1.shape == x2.shape, "x1.shape = {} x2.shape = {}".format(x1.shape, x2.shape)
        return np.linalg.norm(x1 - x2) ** 2

    def create_leaf(self, fea, height, n):
        leaf = Node(fea = fea, root_dist=height, size=n)
        x = fea

        leaf.center = np.mean(x, axis = 0)
        leaf.radius = 0
        for i in range(x.shape[0]):
            d = self.get_distance(x[i], leaf.center)
            if d > leaf.radius:
                leaf.radius = d
        return leaf

    def random_select(self, n, m):
        assert(n >= m)
        selected = np.random.choice(n, m, replace = False)
        selected = sorted(selected)
        return selected

    def build_tree(self, fea, height, center_parent=None, radius_parent=None):
        # nodes:存储每一个节点
        cur = len(self.nodes)  # 总共被分了几个结点
        n, dim1 = fea.shape[0], fea.shape[1]

        if height >= self.max_height or n <= self.min_leaf_size or self.same_fea_preds(fea):
            if height >= self.max_height:
                self.leaf_type[0] += 1
            elif n <= self.min_leaf_size:
                self.leaf_type[1] += 1
            elif n == 0:
                self.leaf_type[2] += 1
            else:
                self.leaf_type[3] += 1

            if n == 0:
                return None
            elif n == 1:
                assert(center_parent is not None and radius_parent is not None)
                self.nodes.append(Node(fea=fea, center=center_parent, radius=radius_parent,
                                       root_dist=height, size=n))
            else:
                self.nodes.append(self.create_leaf(fea, height, n))
            return cur

        inter_node = Node(fea=fea, root_dist=height, size=n)
        inter_node.center = np.mean(fea, axis = 0)
        inter_node.radius = 0
        inter_node.selected_fea = self.random_select(dim1, self.k_fea)

        x = fea[:, inter_node.selected_fea]

        from sklearn.cluster import KMeans
        kmeans = KMeans(n_clusters=2).fit(x)
        inter_node.lcenter = kmeans.cluster_centers_[0]
        inter_node.rcenter = kmeans.cluster_centers_[1]

        left_son, right_son = [], []
        for i in range(n):
            x_i = fea[i, inter_node.selected_fea]
            dis1 = self.get_distance(x_i, inter_node.lcenter)
            dis2 = self.get_distance(x_i, inter_node.rcenter)
            if dis1 <= dis2:
                left_son.append(i)
            else:
                right_son.append(i)

            x_i = fea[i, :]
            dis = self.get_distance(x_i, inter_node.center)
            if inter_node.radius < dis:
                inter_node.radius = dis

        self.nodes.append(inter_node)
        #print("inter_node",inter_node)
        self.nodes[cur].lson = self.build_tree(fea[left_son, :], height+1, inter_node.center, inter_node.radius)
        self.nodes[cur].rson = self.build_tree(fea[right_son, :], height+1, inter_node.center, inter_node.radius)
        return cur

    def predict(self, x_fea):
        cur_index = self.root
        height = 0
        while self.nodes[cur_index].lson != None or self.nodes[cur_index].rson != None:
            cur_node = self.nodes[cur_index]
            x = x_fea
            dis = self.get_distance(x, cur_node.center)
            if dis >= cur_node.radius:
                break

            if cur_node.lson != None and cur_node.rson != None:
                tx = x_fea[cur_node.selected_fea]
                dis1 = self.get_distance(tx, cur_node.lcenter)
                dis2 = self.get_distance(tx, cur_node.rcenter)
                if dis1 <= dis2:
                    cur_index = cur_node.lson
                else:
                    cur_index = cur_node.rson
            elif cur_node.lson != None:
                cur_index = cur_node.lson
            else:
                cur_index = cur_node.rson
            height += 1

        return height < int(self.node_dist_mean+1)

class SeenForest:
    def __init__(self, fea=None, weight=None):

        fea = np.array(fea)
        weight = [1 for i in range(fea.shape[0])] if weight is None else weight

        assert fea.shape[0]==len(weight)

        self.fea = fea                                      # type: np.ndarray
        total_weight = sum(weight)
        self.weight = [i/total_weight for i in weight]      # type: list

        self.tree_size = min(fea.shape[0], config.tree_size)

        self.k_fea = (fea.shape[1] + 1) // 2
        self.max_height = int(np.ceil(np.log2(self.tree_size)))
        self.min_leaf_size = config.min_leaf_size
        self.max_trees = config.max_tree

        self.build_forest()

    def update(self, samples, weight):
        samples = np.array(samples)
        self.fea = samples.copy()
        total_weight = sum(weight)
        self.weight = [i/total_weight for i in weight]
        self.build_forest()

    def select_samples(self):
        n = self.fea.shape[0]
        assert n >= self.tree_size
        selected = np.random.choice(n, self.tree_size, replace=False, p=self.weight)
        selected = sorted(selected)
        return selected

    def build_forest(self):
        self.forest = []
        for tree_id in range(self.max_trees):
            selected_id = self.select_samples()
            selected_fea = self.fea[selected_id, :]
            cur_tree = Tree(selected_fea)
            self.forest.append(cur_tree)

    def predict(self, x_fea):
        ret = np.zeros((self.max_trees, 1), dtype = bool)
        for i in range(self.max_trees):
            cur_ret = self.forest[i].predict(x_fea)
            ret[i] = cur_ret
        return sum(ret) > self.max_trees//2

