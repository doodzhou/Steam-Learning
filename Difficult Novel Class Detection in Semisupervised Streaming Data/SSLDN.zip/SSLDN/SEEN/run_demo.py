# -*- coding: utf-8 -*-

from usfSeen2.SEEN import config
from usfSeen2.SEEN.SeenForest import *
from usfSeen2.SEEN.SeenLP import *
import time, sys
import pickle
import numpy as np
from sklearn.metrics import precision_score, recall_score, accuracy_score

import warnings
warnings.filterwarnings('ignore')
np.random.seed(0) # for demo reproducibility


def evaluate_acc_f1(truth, preds):
    acc = accuracy_score(truth, preds)
    precision = precision_score(truth, preds, average='macro')
    recall = recall_score(truth, preds, average='macro')
    f1 = 2 * precision * recall / (precision + recall)

    print(f"acc={acc:.4f} f1={f1:.4f}")


def load_data(period_num):
    file_name = 'E:/otherpaperCode/Semi-Supervised Streaming Learning with Emerging New Labels(SEEN)/pendigits/' + str(period_num) + '.data'
    with open(file_name, 'rb') as f:
        data = pickle.load(f)
        X, Y, label_state = data['X'], data['Y'], data['label_state']
        new_class = data['new_class']
        del data
    return X, Y, label_state, new_class


if __name__ == '__main__':
    dataset_name = 'pendigits'
    # hyper-parameters for pendigits dataset
    gamma = 0.1
    config.unlabeled_size = 10
    reserve_num = 1000
    outlier_buffer_size = 50
    selected_outlier_num = 10

    all_truth = []
    all_preds = []

    time_begin = time.time()

    new_weight = 3.0
    reduce_weight = 0.5
    X, Y, label_state, new_class = load_data(0)
    n = X.shape[0]
    label_num = sum(label_state)
    unlabel_num = n - label_num
    all_labels = list(set(Y))

    model = SeenLP(gamma=gamma)
    for i in range(n):
        if label_state[i] == 1:
            model.add_labeled_sample(X[i], Y[i])
        else:
            cur_preds = np.argmax(model.predict(X[i]))
            all_preds.append(cur_preds)
            all_truth.append(Y[i])

    all_sample_instance = []
    all_sample_weight = []
    for i in range(X.shape[0]):
        all_sample_instance.append(X[i])
        all_sample_weight.append(1.0)

    build_begin = time.time()
    detector = SeenForest(fea=X)

    model = SeenLP(gamma=gamma)
    for period in range(1, 8):
        print(f"------ period: {period} ", end=" ")
        period_begin = time.time()

        X, Y, label_state, new_class = load_data(period)
        all_labels = list(set(Y))
        # print("Y, label_state:",Y, label_state)
        #print("Y:", Y)
        ui = np.unique(Y)
        a=[]
        for i in ui:
            a.append(np.sum(Y==i))
        # print("ui:",ui)
        # print("label_state:", label_state,type(label_state))
        #print("new_class:", new_class)
        n = X.shape[0]
        outlier_buffer = []
        outlier_num = 0
        update_outlier = False

        period_known_right, period_known_num = 0, 0
        period_new_right, period_new_num = 0, 0

        for i in range(n):
            ret = False
            if label_state[i] == 1:
                model.add_labeled_sample(X[i], Y[i])
            else:
                if update_outlier:
                    cur_preds = np.argmax(model.predict(X[i]))
                else:
                    ret = detector.predict(X[i])
                    if ret:
                        outlier_buffer.append(X[i])
                        cur_preds = new_class[0]
                        outlier_num += 1
                    else:
                        cur_preds = np.argmax(model.predict(X[i]))
                all_preds.append(cur_preds)
                all_truth.append(Y[i])

            if label_state[i] == 1 or update_outlier or ret == False:
                all_sample_instance.append(X[i])
                all_sample_weight.append(1.0)
            else:
                all_sample_instance.append(X[i])
                all_sample_weight.append(new_weight)

            if update_outlier == False and outlier_num == outlier_buffer_size:
                update_detector_begin = time.time()
                model.update_outlier(outlier_buffer, new_class[0], selected_outlier_num)
                detector.update(all_sample_instance, all_sample_weight)
                all_sample_num = len(all_sample_instance)
                reserve_num = min(all_sample_num, reserve_num)
                normalized_weight = np.array(all_sample_weight) / sum(all_sample_weight)
                reserve_id = np.random.choice(all_sample_num, reserve_num, replace=False, p=normalized_weight)
                array_instance = np.array(all_sample_instance)
                array_weight = np.array(all_sample_weight)
                all_sample_instance = list(array_instance[reserve_id, :])
                all_sample_weight = list(array_weight[reserve_id,] * reduce_weight)
                update_outlier = True

        if update_outlier == False:
            update_detector_begin = time.time()
            model.update_outlier(outlier_buffer, new_class[0], selected_outlier_num)
            detector.update(all_sample_instance, all_sample_weight)
            all_sample_num = len(all_sample_instance)
            reserve_num = min(all_sample_num, reserve_num)
            normalized_weight = np.array(all_sample_weight) / sum(all_sample_weight)
            reserve_id = np.random.choice(all_sample_num, reserve_num, replace=False, p=normalized_weight)
            array_instance = np.array(all_sample_instance)
            array_weight = np.array(all_sample_weight)
            all_sample_instance = list(array_instance[reserve_id, :])
            all_sample_weight = list(array_weight[reserve_id,] * reduce_weight)
            update_outlier = True

        print(f"time={time.time()-time_begin:.3f}s")

    evaluate_acc_f1(all_truth, all_preds)
    time_end = time.time() - time_begin
    print(f"time = {time_end:.3f}s")
'''
It takes about 3 minutes to run the code. The final performance should be:
acc=0.8488 f1=0.8575
'''