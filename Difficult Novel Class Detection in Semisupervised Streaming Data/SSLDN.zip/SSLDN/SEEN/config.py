# -×- coding: utf-8 -*-

# configuration on SeenForest
max_height = 7
min_leaf_size = 4
tree_size = 128
max_tree = 50


# configuration on SeenLP
labeled_size = 20
unlabeled_size = 10
