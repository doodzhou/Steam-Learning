# -*- coding: utf-8 -*-

import numpy as np
from collections import deque
import random

class SeenLP:

    def __init__(self, gamma=1, buffer_size=100, max_iter=1000, tol=1e-4):
        self.buffer_size = buffer_size
        self.gamma = gamma
        self.max_iter = max_iter
        self.tol = tol

        self.class_samples = []
        self.class_dict = dict()
        self.class_num = 0
        self.sample_buffer = deque()

        self.W = np.zeros(shape=(0, 0))
        self.labels = np.zeros(shape=(0,))
        self.unlabel_num = 0

    def get_distance(self, x1, x2):
        K = -(np.linalg.norm(x1 - x2) ** 2) * self.gamma
        return np.exp(K)

    def resize_new_unlabel(self):
        m1, m2 = self.W.shape
        assert (m1 == m2 and m1 > 0)
        self.W = np.concatenate((self.W, np.zeros(shape=(1, m2))), axis=0)
        self.W = np.concatenate((self.W, np.zeros(shape=(m1 + 1, 1))), axis=1)
        self.labels = np.concatenate((self.labels, np.array([-1])))

    def fit(self):
        '''
        Parameters
        ----------
        W: shape = (n_samples, n_samples), distance matrix
        Y: shape = (n_samples, 1), labels(unlabeled points are marked as -1

        Returns
        -------
        label_distributions: shape = (n_samples, C)
        '''

        # normalizer = W.sum(axis = 1)
        # W /= normalizer[:, np.newaxis]

        assert (self.W.shape[0] == self.W.shape[1] and self.W.shape[0] == self.labels.shape[0])
        classes = np.unique(self.labels)
        classes = (classes[classes != -1])
        # print("classes", classes)
        n, C = self.labels.shape[0], len(classes)
        # print("n, C",n, C)
        unlabel = self.labels == -1
        # print("unlabel:", unlabel)
        label_distributions = np.zeros(shape=(n, C))
        for label in classes:
            # print("self.labels == label, classes == label",self.labels, classes)
            label_distributions[self.labels == label, classes == label] = 1
        # print("label_distributions1", label_distributions)

        # store the labels of labeled data
        Y_static = np.copy(label_distributions)
        Y_static[unlabel] = 0
        # print("Y_static: ",Y_static)
        unlabel = unlabel[:, np.newaxis]
        # print("unlabel: ", unlabel)
        label_previous = np.zeros(shape=(n, C))
        for iteration in range(self.max_iter):
            if np.abs(label_distributions - label_previous).sum() < self.tol:
                break

            label_previous = label_distributions
            label_distributions = np.dot(self.W, label_distributions)
            normalizer = np.sum(label_distributions, axis=1)
            # print("normalizer:", normalizer)
            zero_index = normalizer == 0
            normalizer[zero_index] = 1
            label_distributions /= normalizer[:, np.newaxis]
            # print("label_distributions2",label_distributions)
            label_distributions = np.where(unlabel, label_distributions, Y_static)
            # print("label_distributions3", label_distributions,np.argmax(label_distributions))
        return label_distributions

    def predict(self, x, update=True): # add unlabeled sample x
        '''
        :param x: add an unlabeled sample x
        :return: return label distributions for the sample
        '''
        W_old = self.W
        # print("W_old",W_old)
        labels_old = self.labels
        # print("labels_old", labels_old, len(labels_old))
        unlabel_num_old = self.unlabel_num
        # print("unlabel_num_old", unlabel_num_old)
        sample_buffer_old = self.sample_buffer
        # print("sample_buffer_old", sample_buffer_old, len(sample_buffer_old))

        self.resize_new_unlabel()
        # update weight with labeled data
        index1 = self.W.shape[0] - 1
        # print("index1", index1)
        sum_d1 = 0
        # print("self.class_samples, self.class_num:",self.class_samples, self.class_num)
        for class_index in range(self.class_num):
            index2 = self.class_num - 1 - class_index
            # print("index2", index2)
            d = 0
            for x2 in self.class_samples[class_index]:
                d += self.get_distance(x, x2)
            self.W[index1, index2] += d
            self.W[index2, index1] += d
            sum_d1 += d
        # print("self.W,sum_d1", self.W,sum_d1)


        # update weight with unlabeled data
        index2 = self.class_num
        sum_d2 = 0
        for unlabel_x in self.sample_buffer:
            d = self.get_distance(x, unlabel_x)
            self.W[index1, index2] += d
            self.W[index2, index1] += d
            index2 += 1
            sum_d2 += d

        self.unlabel_num += 1
        self.sample_buffer.append(x)
        # print("无标签数据权重",self.W)
        if self.unlabel_num == self.buffer_size + 1:
            # remove oldest sample
            self.sample_buffer.popleft()  # 当无标签的数量到达设定的阈值，去掉最前面的无标签数据
            self.unlabel_num -= 1

            # update weight matrix
            total_weight = np.sum(self.W[self.class_num, :])
            # print("total_weight", total_weight)
            assert total_weight > 0, "total_weight = {} ".format(total_weight)
            assert(len(self.sample_buffer) == self.buffer_size)
            for index1 in range(self.class_num + 1, self.class_num + self.unlabel_num):
                for index2 in range(self.class_num + 1, self.class_num + self.unlabel_num):
                    if index1 != index2:
                        self.W[index1, index2] += self.W[self.class_num, index1] * self.W[self.class_num, index2] / \
                                                  total_weight
            # print("更新之后的权重：", self.W)
            self.W = np.delete(self.W, self.class_num, axis=0)
            # ("self.W = np.delete(self.W, self.class_num, axis=0):",self.W)
            self.W = np.delete(self.W, self.class_num, axis=1)
            # print("self.W = np.delete(self.W, self.class_num, axis=1):", self.W)
            self.labels = np.delete(self.labels, self.class_num, axis=0)
            # ("self.W = np.delete(self.labels, self.class_num, axis=0):", self.labels)

        preds = self.fit()

        if update == False:
            self.W = W_old
            self.labels = labels_old
            self.unlabel_num = unlabel_num_old
            self.sample_buffer = sample_buffer_old

        return preds[-1, :]

    def resize_new_class(self, x, y):
        m1, m2 = self.W.shape
        assert (m1 == m2)
        if m1 != 0:
            self.W = np.concatenate((np.zeros(shape=(1, m2)), self.W), axis=0)
            self.W = np.concatenate((np.zeros(shape=(m1 + 1, 1)), self.W), axis=1)
            self.labels = np.concatenate((np.array([y]), self.labels))
        else:
            self.W = np.zeros(shape=(1, 1))
            self.labels = np.array([y])

    def update_weight_old_unlabel(self, new_x):
        unlabel_index = self.class_num
        for unlabel_x in self.sample_buffer:
            d = self.get_distance(new_x, unlabel_x)
            self.W[0, unlabel_index] += d
            self.W[unlabel_index, 0] += d
            unlabel_index += 1

    def add_labeled_sample(self, x, y):
        # print("y",y)
        # print("self.class_dict.keys(),self.class_num：",self.class_dict.keys(),self.class_num)
        if y not in self.class_dict.keys():  # receive new class
            self.class_dict[y] = self.class_num
            self.class_num += 1
            self.class_samples.append([x])

            self.resize_new_class(x, y)
            self.update_weight_old_unlabel(x)
        else:  # receive old class
            class_index = self.class_dict[y]
            self.class_samples[class_index].append(x)
            index1 = self.class_num - 1 - class_index
            index2 = self.class_num
            for unlabel_x in self.sample_buffer:
                d = self.get_distance(x, unlabel_x)
                self.W[index1, index2] += d
                self.W[index2, index1] += d
                index2 += 1

    def update_outlier(self, outlier_buffer, outlier_label, selected_outlier_num=10):
        # select samples that are most likely to be novel labels as new class instances
        # 选择最有可能成为新标签的样本作为新的类实例
        outlier_buffer = np.array(outlier_buffer)
        outlier_num = outlier_buffer.shape[0]
        outlier_mean = np.mean(outlier_buffer, axis=0)
        distance = []
        for i in range(outlier_num):
            d = np.linalg.norm(outlier_buffer[i] - outlier_mean) ** 2
            distance.append([d, i])
        distance = sorted(distance, key=lambda s: s[0])
        for i in range(min(outlier_num, selected_outlier_num)):
            self.add_labeled_sample(outlier_buffer[distance[i][1]], outlier_label)