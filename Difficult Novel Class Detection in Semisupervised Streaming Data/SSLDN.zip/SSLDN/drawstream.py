import matplotlib.pyplot as plt
import xlrd
import numpy as np


def pen_diff_xls(nopath):
    workbook = xlrd.open_workbook(nopath)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[17])  # 获取工作簿中所有表格中的的第11个表格
    usfacc = []
    usff1 = []
    seenacc = []
    seenf1 = []
    senneacc = []
    sennef1 = []
    orsslacc = []
    orsslf1 = []
    iforestacc = []
    iforestf1 = []
    lofacc = []
    loff1 = []
    datasize = []
    for ino in range(2, worksheet.nrows):
        dasize = worksheet.cell_value(ino, 1)
        datasize.append(dasize)
        uacc = worksheet.cell_value(ino, 3)
        usfacc.append(uacc)
        uf1 = worksheet.cell_value(ino, 4)
        usff1.append(uf1)
        sacc = worksheet.cell_value(ino, 5)
        seenacc.append(sacc)
        sf1 = worksheet.cell_value(ino, 6)
        seenf1.append(sf1)
        snacc = worksheet.cell_value(ino, 7)
        senneacc.append(snacc)
        snf1 = worksheet.cell_value(ino, 8)
        sennef1.append(snf1)
        oracc = worksheet.cell_value(ino, 9)
        orsslacc.append(oracc)
        orf1 = worksheet.cell_value(ino, 10)
        orsslf1.append(orf1)
        iacc = worksheet.cell_value(ino, 11)
        iforestacc.append(iacc)
        if1 = worksheet.cell_value(ino, 12)
        iforestf1.append(if1)
        lacc = worksheet.cell_value(ino, 13)
        lofacc.append(lacc)
        lf1 = worksheet.cell_value(ino, 14)
        loff1.append(lf1)
    DSIZE = np.array(datasize)
    UACC = np.array(usfacc)
    UF1 = np.array(usff1)
    SACC = np.array(seenacc)
    SF1 = np.array(seenf1)
    SEACC = np.array(senneacc)
    SEF1 = np.array(sennef1)
    OACC = np.array(orsslacc)
    OF1 = np.array(orsslf1)
    IACC = np.array(iforestacc)
    IF1 = np.array(iforestf1)
    LACC = np.array(lofacc)
    LF1 = np.array(loff1)
    return DSIZE, UACC, UF1, SACC, SF1, SEACC, SEF1, OACC, OF1, IACC, IF1, LACC, LF1


# #######################画出三维图######################################
def plot(DSIZE, UACC, UF1, SACC, SF1, SEACC, SEF1, OACC, OF1, IACC, IF1, LACC, LF1):
    # ######################在同一个图中####################

    fig = plt.figure()
    ax = fig.add_subplot()
    ax.plot(DSIZE, UACC, color='#FA8072', label='SLDN accuracy', marker='s', markersize=4.5, linewidth=1.7)  # ls或linestyl
    ax.plot(DSIZE, SACC, color='#3c73a8', label='SEEN', marker='*', markersize=4.5, linewidth=1.7)
    ax.plot(DSIZE, SEACC, color='#75b841', label='SENNE', ls='solid', marker='o', markersize=4.5, linewidth=1.7)
    ax.plot(DSIZE, OACC, color='#fcc006', label='ORSSL', ls='solid', marker='^', markersize=4.5, linewidth=1.7)
    ax.plot(DSIZE, IACC, color='#a66fd5', label='iForest+SVM', ls='solid', marker='x', markersize=4.5, linewidth=1.7)
    ax.plot(DSIZE, LACC, color='#7bc8f8', label='LOF+SVM', ls='solid', marker='d', markersize=4.5, linewidth=1.7)
    ax.legend(loc='lower left')
    ax2 = ax.twinx()
    ax2.plot(DSIZE, UF1, color='#FA8072', label='SLDN F1', ls='-.', marker='s', markersize=4.5, linewidth=1.7)  # ls或linestyle
    ax2.plot(DSIZE, SF1, color='#3c73a8', label='SEEN', ls='-.', marker='*', markersize=4.5, linewidth=1.7)
    ax2.plot(DSIZE, SEF1, color='#75b841', label='SENNE', ls='-.', marker='o', markersize=4.5, linewidth=1.7)
    ax2.plot(DSIZE, OF1, color='#fcc006', label='ORSSL', ls='-.', marker='^', markersize=4.5, linewidth=1.7)
    ax2.plot(DSIZE, IF1, color='#a66fd5', label='iForest+SVM', ls='-.', marker='x', markersize=4.5, linewidth=1.7)
    ax2.plot(DSIZE, LF1, color='#7bc8f8', label='LOF+SVM', ls='-.', marker='d', markersize=4.5, linewidth=1.7)
    ax.grid(color="grey", linestyle=":", axis='y')
    ax.set_xlabel("Data Stream", fontsize=14)
    ax.set_ylabel(r"accuracy", fontsize=14)
    ax2.set_ylabel(r"F1", fontsize=14)
    ax2.legend(loc='lower right')
    plt.title('MNIST', fontsize=14)
    plt.draw()
    plt.show()


if __name__ == '__main__':
    path1 = 'E:\\tow-paper\\result.xlsx'
    DSIZE, UACC, UF1, SACC, SF1, SEACC, SEF1, OACC, OF1, IACC, IF1, LACC, LF1 = pen_diff_xls(path1)
    plot(DSIZE, UACC, UF1, SACC, SF1, SEACC, SEF1, OACC, OF1, IACC, IF1, LACC, LF1)
