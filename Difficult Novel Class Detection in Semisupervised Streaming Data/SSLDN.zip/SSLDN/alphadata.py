import numpy as np
from itertools import combinations
import pandas as pd
from scipy.io import loadmat
import itertools
from usfSeen2.read_data import *


# calculate distance between nodes' pair.
def calcDist(X):
    n = X.shape[0]
    dist = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            dist[i, j] = dist[j, i] = np.linalg.norm(X[i] - X[j])
    return dist


def get_distance(x1, x2):
    K = np.linalg.norm(x1 - x2)
    return K


# 计算两个数据集之间的最小距离
def min_dist(x1, x2):
    global k
    temp = float('inf')
    for i in x1:
        for j in x2:
            k = get_distance(i, j)
            if k < temp:
                temp = k
    return k


# 计算已知类数据的紧凑性
def C_Know(knowdata):
    m, n = knowdata.shape
    # 得到一个距离矩阵
    distance_node = np.zeros(shape=(m, m))
    for ileaf in range(m):
        for jleaf in range(ileaf + 1, m):
            distance_node[ileaf, jleaf] = get_distance(knowdata[ileaf], knowdata[jleaf])
            distance_node[jleaf, ileaf] = distance_node[ileaf, jleaf]
    # 得到每个点最近的点以及与此点的距离
    # 每个结点构成超球的最小半径
    min_distance = np.sort(distance_node, axis=1)[:, 1]  # 得到一行数组，里面是distance_node每行的最小值
    c_konw = sum(min_distance)/m
    return c_konw


def alpha_index(alldata):
    m, n = alldata.shape
    label = alldata[:, n - 1]  # data的标签数据
    # label[label == 10] = 0
    data = alldata[:, 0:n - 1]
    ui_label = np.unique(label)
    print("ui_label",ui_label)
    allabel_num = []  # 每个标签的总数 [1143, 1143, 1144, 1055, 1144, 1055, 1056, 1142, 1055, 1055]
    for i in ui_label:
        allabel_num.append(np.sum(label == i))
    print("allabel_num", allabel_num)
    # all_combi = list(combinations(ui_label, 2))
    combi1 = [2, 4]
    combi2 = [6]
    alpha_data1 = []
    alpha_label1 = []
    alpha_data2 = []
    alpha_label2 = []
    for u in combi1:
        for i in range(len(label)):
            if label[i] == u:
                alpha_data1.append(data[i])
                alpha_label1.append(label[i])
    for j in range(len(label)):
        if label[j] == combi2[0]:
            alpha_data2.append(data[j])
            alpha_label2.append(label[j])
    alpha_data1 = np.array(alpha_data1)
    alpha_label1 = np.array(alpha_label1)
    alpha_data2 = np.array(alpha_data2)
    alpha_label2 = np.array(alpha_label2)
    print("alpha_label2", len(alpha_label2))
    choice_index = []
    for isp in range(2):
        sub_num = 200  # 初始训练集取2倍的每个文件的数据量
        index = list(np.where(alpha_label1 == combi1[isp]))
        choice = np.random.choice(index[0], size=sub_num, replace=False).tolist()  # 得到的是数据的下标
        choice_index.append(choice)
    choice_index = sum(choice_index, [])
    choice_index = sorted(choice_index)
    alphadata1 = alpha_data1[choice_index]
    sunindex2 = np.random.choice(len(alpha_label2), 200, replace=False).tolist()
    sunindex2 = sorted(sunindex2)
    alphadata2 = alpha_data2[sunindex2, :]
    k = min_dist(alphadata1, alphadata2)
    c_konw = C_Know(alphadata1)
    alpha = k/c_konw
    print("alpha", alpha)
    return alpha


if __name__ == "__main__":
    # data = pd.read_csv('E://tow-paper//datasets//pendigits//pendigits.txt', header=None)
    # data = np.array(data)
    # alpha = alpha_index(data)
    '''
    # usps//USPS.mat
    m = loadmat("E://tow-paper//datasets//Forest_Cover//Forest_Cover.mat")
    images = m["art4"]
    data1 = np.insert(images[0][0], images[0][0].shape[1], int(images[0][1][0][0]), axis=1)
    for i in range(1, images.shape[0]):
        labeli = int(images[i][1][0][0])
        datai = np.insert(images[i][0], images[i][0].shape[1], labeli, axis=1)
        data = np.vstack((data1, datai))
        data1 = data

    data = np.array(data)
    alpha = alpha_index(data)
    '''
    '''
    m = loadmat("E://tow-paper//datasets//Fasion_MNIST//Fasion_MNIST.mat")
    images = m["art4"]
    data1 = np.insert(images[0][0], images[0][0].shape[1], int(images[0][1][0][0]), axis=1)
    for i in range(1, images.shape[0]):
        labeli = int(images[i][1][0][0])
        datai = np.insert(images[i][0], images[i][0].shape[1], labeli, axis=1)
        data = np.vstack((data1, datai))
        data1 = data
    m, n = data.shape
    onlydata = data[:, 0:n - 1]
    onlylabel = data[:, n - 1]
    onlylabel[onlylabel == 10] = 0
    alldata = np.concatenate((onlydata, onlylabel.reshape((len(onlylabel), 1))), axis=1)
    alpha = alpha_index(alldata)
    '''
    '''
    alldata = loadmat("E://tow-paper//datasets//usps//USPS.mat")
    images = alldata["fea"]
    labels = alldata["gnd"]
    all_data = np.hstack((images, labels))
    alpha = alpha_index(all_data)
    
    data = load_mnist_train("E://tow-paper//datasets//MNIST-10K//")
    alpha = alpha_index(data)
    '''
    path = "E:/tow-paper/datasets/Fasion_MNIST"
    alldata = load_mnist_train(path, kind='train')
    alpha = alpha_index(alldata)