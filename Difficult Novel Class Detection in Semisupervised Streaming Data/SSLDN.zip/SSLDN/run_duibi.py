import numpy as np
from usfSeen2.SEEN.SeenLP import *
from usfSeen2.SEEN.SeenForest import *
from usfSeen2.SENNE.model import *
from usfSeen2.SNECMas.detector import *
from usfSeen2.ORSSL.initialmodel import *
from usfSeen2.duibisuanfa import *
from sklearn import neighbors
import time
import warnings
warnings.filterwarnings('ignore')


options = {"lambda_": 12, "k": 2, "max_loop_times": 10}

# update_outlier = False
time_begin = time.time()
# ############ 初始训练数据集 ###################################
X0, Y0, label_state0 = load_data(0, 0.01)  # 初始训练集
# X0 = X0/10

# #####################usfSeen的开始时间，初始模型detector和model################
all_sample_instance = []
all_sample_weight = []
for i in range(X0.shape[0]):
    all_sample_instance.append(X0[i])
n = X0.shape[0]

build_begin1 = time.time()
detector = SdndcForest(fea=X0)
model = usfSeenLP(options)

# ####################seen的开始时间，初始模型detector和model###################
all_truth = []
all_preds = []
gamma = 0.1
model2 = SeenLP(gamma=gamma)
label_num = sum(label_state0)
unlabel_num = n - label_num
Xs = X0/10
for i in range(n):
    if label_state0[i] == 1:
        model2.add_labeled_sample(Xs[i], Y0[i])
    else:
        cur_preds = np.argmax(model2.predict(Xs[i]))
        all_preds.append(cur_preds)
        all_truth.append(Y0[i])

all_sample_instance2 = []
all_sample_weight = []
for i in range(X0.shape[0]):
    all_sample_instance2.append(Xs[i])
    all_sample_weight.append(1.0)

build_begin2 = time.time()
detector2 = SeenForest(fea=Xs)
model2 = SeenLP(gamma=gamma)

# ##################senne的开始时间，初始模型model########################

num_samples = 100  # number of set
sample_size = 20  # subsample size for each set
CurtNumDim = X0.shape[1]
newclass_num = 1

# ################# snecmas的开始时间，初始模型############################
build_begin4 = time.time()
traindata = np.concatenate((X0, Y0.reshape((len(Y0), 1))), axis=1)
global_mat, local_mat = getMatrixSketch(traindata)
threshold, Q = thres(traindata, global_mat)

# ################orssl的开始时间，初始模型##################################
traindata = np.concatenate((X0, Y0.reshape((len(Y0), 1))), axis=1)
train_cls_lb = np.unique(Y0)
num_cluster = 50
model4 = initial_model_construction(traindata, train_cls_lb, num_cluster)

print("所有方法的初始化结束啦！")
for period in range(1, 8):
    print(f"------ period: {period} ", end=" ")
    X, Y, label_state = load_data1(period, 0.01)  # 当前时期的文件

    print("~~~~~~~运行到usfSeen了~~~~~~~~~~")
    usfSeen(X, Y, label_state, model, detector, all_sample_instance)
    print("~~~~~~~运行到seen了~~~~~~~~~~~~~")
    XS = X/10
    seen(XS, Y, label_state, model2, detector2, all_preds, all_truth, all_sample_instance2, all_sample_weight)
    
    # ##############senne##############
    # 初始化模型，senne的初始化模型是根据上一个判断过的数据建立的
    Xchus, Ychus, label_statechus = load_data1(period-1, 0.01)   # 上一个时期的文件
    ui = np.unique(Ychus)
    train_num = len(ui)
    allabel_num = []  # 每个标签的总数 [1143, 1143, 1144, 1055, 1144, 1055, 1056, 1142, 1055, 1055]
    for i in np.unique(Ychus):
        allabel_num.append(np.sum(Y == i))
    num_per_class = min(allabel_num)  # 每个类选取的样本是已知类中数量的最小值
    choice_index = []
    for isp in range(train_num):
        sub_num = num_per_class  # int(np.ceil(allabel_num[isp] / split_num))  # 初始训练集取2倍的每个文件的数据量
        index = list(np.where(Ychus == ui[isp]))
        choice = np.random.choice(index[0], size=sub_num, replace=False).tolist()  # 得到的是数据的下标
        choice_index.append(choice)
    choice_index = sum(choice_index, [])
    choice_index = sorted(choice_index)
    Xdata = Xchus[choice_index]
    Xlabel = Ychus[choice_index]
    traindata = np.concatenate((Xdata, Xlabel.reshape((len(Xlabel), 1))), axis=1)
    model3 = model_SENNE(traindata, num_samples, sample_size, CurtNumDim)
    # ################到此初始模型建立完成###################3333
    streamdata = X
    streamdatalabel = Y
    max_num = max(np.unique(streamdatalabel))
    for i in range(len(streamdatalabel)):
        if streamdatalabel[i] == max_num:
            streamdatalabel[i] = 999
    print("~~~~~~~运行到senne了~~~~~~~~~~~~~")
    senne(train_num, streamdata, streamdatalabel, model3)
    # #################################

    print("~~~~~~~运行到snecmas了~~~~~~~~~~~~~")
    snecmas(X, Y, label_state, X0, global_mat, local_mat, threshold, Q)

    print("~~~~~~~运行到orssl了~~~~~~~~~~~~~")
    orssl(X, Y, label_state, model4)
    print("~~~~~~~运行到IForestKNN了~~~~~~~~~~~~~")
    # ###############IForestKNN整体得分预测##################
    clf = IsolationForest()
    clf.fit(Xchus, n_samples=256)
    Average_score = sum(clf.predict(Xchus)) / len(Xchus)
    # 调用KNN的分类器
    knn = neighbors.KNeighborsClassifier()
    knn.fit(Xchus, Ychus)
    iforestknn(X, Y, label_state, clf, knn, Average_score)
