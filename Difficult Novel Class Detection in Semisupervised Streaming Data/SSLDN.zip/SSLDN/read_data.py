import gzip
import os
import struct
import pandas as pd
import numpy as np


def load_mnist_train(path, kind='t10k'):
    # path:数据集的路径
    # kind:值为train，代表读取训练集

    labels_path = os.path.join(path, '%s-labels-idx1-ubyte.gz' % kind)
    images_path = os.path.join(path, '%s-images-idx3-ubyte.gz' % kind)
    # 使用gzip打开文件
    with gzip.open(labels_path, 'rb') as lbpath:
        # 使用struct.unpack方法读取前两个数据，>代表高位在前，I代表32位整型。lbpath.read(8)表示一次从文件中读取8个字节
        # 这样读到的前两个数据分别是magic number和样本个数
        magic, n = struct.unpack('>II', lbpath.read(8))
        # 使用np.fromstring读取剩下的数据，lbpath.read()表示读取所有的数据
        labels = np.fromstring(lbpath.read(), dtype=np.uint8)
    with gzip.open(images_path, 'rb') as imgpath:
        magic, num, rows, cols = struct.unpack('>IIII', imgpath.read(16))
        images = np.fromstring(imgpath.read(), dtype=np.uint8).reshape(len(labels), 784)
    data = np.insert(images, images.shape[1], values=labels, axis=1)  # 有10000个数据，标签在最后一列
    data = pd.DataFrame(data).values
    # data = data.sample(frac=0.1, axis=0)

    return data


# data = load_mnist_train('E:/Datasets1/mnist_dataset')
