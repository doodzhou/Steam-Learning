# -*- coding: utf-8 -*-

import pandas as pd
from usfSeen2.SdndcForest2 import *
from usfSeen2.SdndcLP4 import *
from usfSeen2.SEEN.SeenLP import *
from usfSeen2.SEEN.SeenForest import *
import time
import numpy as np
from sklearn.metrics import precision_score, recall_score, accuracy_score

import warnings
warnings.filterwarnings('ignore')
np.random.seed(0)  # for demo reproducibility


def evaluate_acc_f1(truth, preds):
    acc = accuracy_score(truth, preds)
    precision = precision_score(truth, preds, average='macro')
    recall = recall_score(truth, preds, average='macro')
    f1 = 2 * precision * recall / (precision + recall)

    print(f"acc={acc:.4f} f1={f1:.4f}")


def load_data1(period_num, ratio):
    file_name = 'E://tow-paper//datasets//MNIST/' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)-1):
        if period_num == 1:
            bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
            label_state[0:2] = 1
        else:
            bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


def load_data(period_num, ratio):
    file_name = 'E://tow-paper//datasets//MNIST//' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    # fore_index = 3
    # now_index = fore_index + period_num - (period_num-1)
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)):
        bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


if __name__ == '__main__':
    # dataset_name = 'pendigits'
    # hyper-parameters for pendigits dataset
    gamma = 0.1
    config.unlabeled_size = 10
    reserve_num = 1000
    outlier_buffer_size = 50
    selected_outlier_num = 10

    all_truth = []
    all_preds = []

    time_begin = time.time()

    new_weight = 3.0
    reduce_weight = 0.5
    X0, Y0, label_state0 = load_data(0, 0.1)  # 初始训练集
    model = SeenLP(gamma=gamma)
    Xs = X0 / 10
    n = Xs.shape[0]
    for i in range(n):
        if label_state0[i] == 1:
            model.add_labeled_sample(Xs[i], Y0[i])
        else:
            cur_preds = np.argmax(model.predict(Xs[i]))
            # all_preds.append(cur_preds)
            # all_truth.append(Y0[i])

    all_sample_instance = []
    all_sample_weight = []
    for i in range(X0.shape[0]):
        all_sample_instance.append(Xs[i])
        all_sample_weight.append(1.0)

    build_begin2 = time.time()
    detector = SeenForest(fea=Xs)
    model = SeenLP(gamma=gamma)

    for period in range(1, 9):
        print(f"------ period: {period} ", end=" ")
        # model = SeenLP(options)
        period_begin = time.time()
        outlier_buffer = []
        newclass = []
        proid_lab = []
        period_truth = []
        outlier_num = 0
        update_outlier = False
        X, Y, label_state = load_data1(period, 0.1)
        X = X/10
        n = X.shape[0]
        # model = SeenLP(options)
        # all_label_data = label_dat
        for j in Y:
            all_truth.append(j)
        period_truth.append(Y.tolist())  # 每一个时期的真实标签
        ui = np.unique(Y)  # 每个时期的标签有哪些[1,2,3]
        for i in range(n):
            ret = False
            if label_state[i] == 1:
                model.add_labeled_sample(X[i], Y[i])
                proid_lab.append(Y[i])
                all_preds.append(Y[i])
            else:
                if update_outlier:
                    cur_preds = np.argmax(model.predict(X[i]))
                    all_preds.append(cur_preds)
                else:
                    ret = detector.predict(X[i])
                    if ret:
                        outlier_buffer.append(X[i])
                        cur_preds = ui[-1]
                        outlier_num += 1
                        all_preds.append(cur_preds)
                    else:
                        cur_preds = np.argmax(model.predict(X[i]))
                        all_preds.append(cur_preds)
                proid_lab.append(cur_preds)


            if label_state[i] == 1 or update_outlier or ret == False:
                all_sample_instance.append(X[i])
                all_sample_weight.append(1.0)
            else:
                all_sample_instance.append(X[i])
                all_sample_weight.append(new_weight)

            if update_outlier == False and outlier_num == outlier_buffer_size:
                update_detector_begin = time.time()
                model.update_outlier(outlier_buffer, ui[-1], selected_outlier_num)
                detector.update(all_sample_instance, all_sample_weight)
                all_sample_num = len(all_sample_instance)
                reserve_num = min(all_sample_num, reserve_num)
                normalized_weight = np.array(all_sample_weight) / sum(all_sample_weight)
                reserve_id = np.random.choice(all_sample_num, reserve_num, replace=False, p=normalized_weight)
                array_instance = np.array(all_sample_instance)
                array_weight = np.array(all_sample_weight)
                all_sample_instance = list(array_instance[reserve_id, :])
                all_sample_weight = list(array_weight[reserve_id,] * reduce_weight)
                update_outlier = True
                print(f"seen的更新时间 time={time.time() - update_detector_begin:.4f}s")
                # model.reserve_sample()
        print(f"Seen的本次时期的运行时间 time={time.time() - period_begin:.4f}s")
        evaluate_acc_f1(period_truth[0], proid_lab)

        if update_outlier == False:
            # update_detector_begin = time.time()
            model.update_outlier(outlier_buffer, ui[-1], selected_outlier_num)
            detector.update(all_sample_instance, all_sample_weight)
            all_sample_num = len(all_sample_instance)
            reserve_num = min(all_sample_num, reserve_num)
            normalized_weight = np.array(all_sample_weight) / sum(all_sample_weight)
            reserve_id = np.random.choice(all_sample_num, reserve_num, replace=False, p=normalized_weight)
            array_instance = np.array(all_sample_instance)
            array_weight = np.array(all_sample_weight)
            all_sample_instance = list(array_instance[reserve_id, :])
            all_sample_weight = list(array_weight[reserve_id,] * reduce_weight)
            update_outlier = True

    evaluate_acc_f1(all_truth, all_preds)
    time_end = time.time() - time_begin
    print(f"time = {time_end:.3f}s")
















