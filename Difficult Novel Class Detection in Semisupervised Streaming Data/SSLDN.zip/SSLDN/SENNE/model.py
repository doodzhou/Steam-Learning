import numpy as np
import time
"""
Nearest neighbor ensembles: An effective method for difficult problems in streaming classification with emerging new classes
2019    icdm
"""


def Dist(p1, p2):
    r = 0
    for i in range(len(p1)):
        r = r + (p1[i] - p2[i]) * (p1[i] - p2[i])
    r = np.sqrt(r)
    return r


def hyperSphere(data, curIndex):
    curpoint = data[curIndex,:]
    r = float('inf')
    NNpoint = []
    iid = 0
    for i in range(len(data)):
        if i == curIndex:
            continue
        else:
            dis = Dist(curpoint, data[i, :])
            if dis < r:
                NNpoint = data[i, :]  # 与curpoint的最近邻
                iid = i  # 与curpoint的最近邻的下标
                r = dis
    return curpoint, r, NNpoint, iid


def model_SENNE(traindata, t, phi, dim):
    """
    traindata:训练的数据集,有标签
    t: 抽样次数
    phi:每次抽样抽取的数据集个数
    dim: 数据的维度
    """
    global label, data
    m, n = traindata.shape
    alldata = traindata[:, 0:n - 1]
    alllabel = traindata[:, -1]
    ui_label = np.unique(alllabel)  # 标签个数
    model = [[] for _ in range(t * len(ui_label))]  # 建立t个空列表
    for k in range(len(ui_label)):
        data, label = [], []
        for iu in range(len(alllabel)):
            if alllabel[iu] == ui_label[k]:
                data.append(alldata[iu, :])
                label.append(alllabel[iu])
        data = np.array(data)
        label = np.array(label)
        for i in range(t):
            subIndex = np.random.choice(len(label), phi, replace=False)
            subIndex = sorted(subIndex)
            subData = data[subIndex, :]
            sublabel = label[subIndex]
            B = [[] for _ in range(5)]  # 建立5个空列表
            for j in range(phi):
                curpoint, r, NNpoint, idd = hyperSphere(subData, j)
                B[0].append(curpoint)  # 存储的当前节点
                B[1].append(r)  # 存储的是当前节点与最近邻的半径
                B[2].append(sublabel[j])  # 存储的是第j个数据的标签
                B[4].append(idd)  # 当前节点的最近邻的下标
            for j in range(phi):
                B[3].append(B[1][B[4][j]])  # 存储当前节点的最近邻B，B的最近邻C，存储的是B与C之间的距离
            model[i + t * k] = B
    # 最后得到的model应该是类似这样的形式[[当前节点],[当前节点与最近邻的半径],[第j个数据的标签],[B与C之间的距离],[当前节点的最近邻的下标]]
    #                              ,[],[],[]
    return model


def calc_score(B, testpoint, threshold):
    score = 1
    r = float('inf')
    label = 0
    iscore = 1
    for i in range(len(B[0])):
        dis = Dist(testpoint, B[0][i])
        if dis <= B[1][i] and r > dis:
            r = dis
            score = 1 - B[3][i]/dis
            if score < iscore and score <= threshold:
                iscore = score
                label = B[2][i]
    return label, score


def modelupdate(model, data, buffer_label, t, phi):
    # data是缓冲区中的数据
    data = np.array(data)
    update_detector_begin = time.time()
    model.append([])  # model增加一个空列表
    label = buffer_label
    Size = len(model)
    for i in range(t):
        subIndex = np.random.choice(len(data), phi, replace=False).tolist()
        subIndex = sorted(subIndex)
        subData = data[subIndex]
        B = [[] for _ in range(5)]  # 建立5个空列表
        for j in range(phi):
            curpoint, r, NNpoint, idd = hyperSphere(subData, j)
            B[0].append(curpoint)  # 存储的当前节点
            B[1].append(r)  # 存储的是当前节点与最近邻的半径
            B[2].append(label)  # 存储的是第j个数据的标签
            B[4].append(idd)  # 当前节点的最近邻的下标
        for j in range(phi):
            B[3].append(B[2][B[4][j]])  # 存储当前节点的最近邻B，B的最近邻C，存储的是B与C之间的距离
        model[-1] = B  # model的最后一个列表被赋予B
        Size = Size + 1
    print(f"senne的更新时间 time={time.time() - update_detector_begin:.4f}s")
    return model


def Predict(curnum, data, truelabel, buffersize, model, score_threshold, t, phi):
    result = np.zeros((data.shape[0], 1))
    result_score = np.zeros((data.shape[0], 1))
    buffer = []
    buffer_label = 0
    buffer_num = 0
    axispoint = [0]
    axisnum = 0
    flag = 0
    for i in range(data.shape[0]):
        testpoint = data[i, :]
        num = 0
        predictlabel = 0
        newclass = 0
        templabel = np.zeros((curnum, 1))
        scores = np.zeros((curnum, 1))
        classnum = np.zeros((curnum, 1))
        for j in range(len(model)):  # t个model
            # print("model[j]",model[j])
            idx, score = calc_score(model[j], testpoint, score_threshold)
            idx = int(idx)
            if idx != 0:
                scores[idx] = scores[idx] + score
                classnum[idx] = classnum[idx] + 1
                templabel[idx, 0] = templabel[idx, 0] + 1
            else:
                newclass = newclass + 1
                for k in range(curnum):
                    scores[k] = scores[k] + 1
                    classnum[k] = classnum[k] + 1
        minscore = 1
        minid = 0
        for jj in range(curnum):
            scores[jj] = scores[jj]/classnum[jj]
            if scores[jj] < score_threshold and minscore > scores[jj]:
                minscore = scores[jj]
                minid = jj
        if minid == 0:
            predictlabel = curnum
            if len(buffer) < buffersize:
                # a = np.concatenate((buffer, testpoint), axis=0)
                buffer.append(testpoint)
                # print("buffer", buffer, len(buffer))
                buffer_num = buffer_num + 1
                buffer_label = curnum
                if len(buffer) == buffersize:
                    flag = 1
                    # print("Update model at i = %d", i)
                    axispoint[0] = i
                    # axisnum = axisnum + 1
                    model = modelupdate(model, buffer, buffer_label, t, phi)
                    buffer = []
                    buffer_num = 1
                    curnum = curnum + 1
        else:
            maxnum = 0
            for j in range(curnum):
                if templabel[j, 0] > maxnum:
                    predictlabel = j
                    maxnum = templabel[j, 0]
        # if predictlabel != 1 and predictlabel != 2:
        if predictlabel != truelabel.any():
            predictlabel = 999
        result[i] = predictlabel
    return result, model, axispoint


# if __name__ == '__main__'
