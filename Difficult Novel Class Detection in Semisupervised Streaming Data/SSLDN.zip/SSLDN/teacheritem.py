# -*- coding: utf-8 -*-

import pandas as pd
from usfSeen2.SdndcForest2 import *
from usfSeen2.SdndcLP4 import *

import time
import numpy as np
from sklearn.metrics import precision_score, recall_score, accuracy_score

import warnings

warnings.filterwarnings('ignore')
np.random.seed(0)  # for demo reproducibility


def evaluate_acc_f1(truth, preds):
    acc = accuracy_score(truth, preds)
    precision = precision_score(truth, preds, average='macro')
    recall = recall_score(truth, preds, average='macro')
    f1 = 2 * precision * recall / (precision + recall)

    print(f"acc={acc:.4f} f1={f1:.4f}")


def load_data1():
    file_name = 'E:\\item\\teacheritem\\train.txt'
    data = pd.read_csv(file_name, header=None, delim_whitespace=True)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    return X


def load_data():
    file_name = 'E:\\item\\teacheritem\\test.txt'
    data = pd.read_csv(file_name, header=None, delim_whitespace=True)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    Y = data[:, data.shape[1]-1]
    return X,Y


if __name__ == '__main__':
    outlier_buffer_size = 200  # 异常值缓冲区的大小
    time_begin = time.time()
    X0 = load_data1()  # 初始训练集
    n = X0.shape[0]
    original_begin = time.time()
    print("训练集的大小为：", len(X0))
    detector = SdndcForest(fea=X0)
    outlier_buffer = []
    error = []
    newclass = []
    period_pred = []
    period_truth = []
    outlier_num = 0
    truep = 0
    truek = 0
    update_outlier = False
    dector_begin = time.time()
    X, Y = load_data()
    # model = SeenLP(options)
    # all_label_data = label_dat
    # print("原始数据标签为：", Y.tolist(),len(Y[Y==0]),len(Y[Y==1]))
    print("总的数据量为：", len(X))
    print("异常类的数量为，正常类的数量为：", len(Y[Y == 0]), len(Y[Y == 1]))
    for iu in range(X.shape[0]):
        ret = detector.xpredict(X[iu])
        if ret:  # 如果ret为True,则为新类
            outlier_buffer.append(Y[iu])
            if Y[iu]==0:
                truep+=1
            outlier_num += 1
        else:  # 如果ret为False，则为已知类
            error.append(Y[iu])
            if Y[iu]==1:
                truek+=1
    print(f"usfseen的检测时间 time={time.time() - dector_begin:.3f}s")
    #print("异常类为：", outlier_buffer, outlier_num)
    #print("正常类为：", error, len(error))
    print("预测异常类的正确率为：", truep/len(Y[Y == 0]))
    print("预测正常类的正确率为：", truek / len(Y[Y == 1]))



