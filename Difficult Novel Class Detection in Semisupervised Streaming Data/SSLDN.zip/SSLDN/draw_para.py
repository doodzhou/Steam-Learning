import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np

mpl.rcParams["font.sans-serif"] = ["SimHei"]
mpl.rcParams["axes.unicode_minus"] = False


SSLEN = [15.317, 24.831, 36.3542, 21.1731, 20.1501, 40.2893,  57.2041, 67.742]
SEEN = [35.7275, 42.6058, 51.5279, 50.2337, 61.1067, 132.3346, 64.0605, 76.0685]
SENNE = [56.5178, 99.8044, 108.7491, 73.3073, 115.501, 156.6712, 129.0882, 294.0847]
ORSSL = [65.6741, 93.3394, 152.3562, 116.53, 97.9092, 167.4907, 119.6493, 266.8614]


tick_label = ["2", "3", "4", "5", "10", "15", "20", "25", "30"]
x = np.arange(len(tick_label))  # x轴刻度标签位置
width = 0.2  # 柱子的宽度
# 计算每个柱子在x轴上的位置，保证x轴刻度标签居中
plt.bar(x - 1.5*width, SSLEN, width, label='SSLEN', hatch="o", color='#A0522D', edgecolor="k")
plt.bar(x - 0.5*width, SEEN, width, label='SEEN', hatch="-", color='#808080', edgecolor="k")
plt.bar(x + 0.5*width, SENNE, width, label='SENNE', hatch="x", color='#2F4F4F', edgecolor="k")
plt.bar(x + 1.5*width, ORSSL, width, label='ORSSL', hatch="|", color='#4682B4', edgecolor="k")
plt.ylabel('Time(CPU seconds)', fontsize=17)
plt.title('The runtime comparisons', fontsize=17)
# x轴刻度标签位置不进行计算
plt.xticks(x, labels=tick_label, fontsize=17)
plt.legend()

plt.show()
