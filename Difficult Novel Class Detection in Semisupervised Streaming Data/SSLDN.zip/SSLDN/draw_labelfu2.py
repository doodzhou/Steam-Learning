import matplotlib.pyplot as plt
import xlrd
import numpy as np


def pen_diff_xls(nopath):
    workbook = xlrd.open_workbook(nopath)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第11个表格
    usfacc = []
    usff1 = []
    seenacc = []
    seenf1 = []
    senneacc = []
    sennef1 = []
    datasize = []
    orsslacc = []
    orsslf1 = []
    iforestacc = []
    iforestf1 = []
    for ino in range(2, worksheet.nrows):
        dasize = worksheet.cell_value(ino, 0)
        datasize.append(dasize)
        uacc = worksheet.cell_value(ino, 3)
        usfacc.append(uacc)
        uf1 = worksheet.cell_value(ino, 4)
        usff1.append(uf1)

    DSIZE = np.array(datasize)
    UACC = np.array(usfacc)
    UF1 = np.array(usff1)

    return DSIZE, UACC, UF1


# #######################画出三维图######################################
def plot(DSIZE, UACC, UF1):
    # ######################在同一个图中####################
    plt.figure(1)
    plt.plot(DSIZE, UACC, color='#FA8072', label='ACC', ls='solid', marker='s', markersize=4.5, linewidth=1.8)   # ls或linestyl
    plt.plot(DSIZE, UF1, color='#3c73a8', label='F1', ls='solid', marker='s', markersize=4.5, linewidth=1.8)
    plt.grid(color="k", linestyle=":", axis='y')

    plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.10), ncol=2, borderaxespad=0, fancybox=True, shadow=True)
    plt.tick_params(labelsize=12)
    plt.xlabel('Ratio of labeled data', fontsize=14)



    plt.draw()
    plt.show()


if __name__ == '__main__':
    path1 = 'E:\\tow-paper\\label.xls'
    DSIZE, UACC, UF1 = pen_diff_xls(path1)
    plot(DSIZE, UACC, UF1)
