import numpy as np


def createMC(Model_temp, ex, r, currentTime, maxMC):
    # ex是个列表，用于存储数据，标签，和label_flg
    # ex= [[data],label,label_flg]
    if len(Model_temp) >= maxMC:
        ulabel_clu_cen = np.where(np.array(Model_temp)[:, 4] == 0)
        if len(ulabel_clu_cen) > 1:
            Model_temp = mergMCul(Model_temp)
        else:
            mxclabel, mxcfre = findMaxClass(Model_temp)
            label_clu_cen = np.where(np.array(Model_temp)[:, 3] == mxclabel)
            Model_temp = mergMC(label_clu_cen, Model_temp)
    ex[0] = ex[0].reshape((1, len(ex[0])))
    LS = np.sum(ex[0], axis=0)
    SS = np.sum(ex[0]**2, axis=0)
    sz = len(LS)
    LSC = np.zeros((1, sz))
    micro_clu = [LS, SS, 1]
    if ex[2] == 1:
        micro_clu.append(ex[1])
        micro_clu.append(1)
    else:
        micro_clu.append(0)
        micro_clu.append(0)
    micro_clu.append(LS)
    micro_clu.append(r)
    micro_clu.append(currentTime)
    micro_clu.append(1)
    Model_temp.append(micro_clu)
    return Model_temp


def mergMCul(Model_temp):
    clu_cent_all = np.array(Model_temp)[:, 5]
    label_clu_cen = np.where(np.array(Model_temp)[:, 4] != 0)
    clu_cent_lb = clu_cent_all[label_clu_cen, :]
    ulabel_clu_cen = np.where(np.array(Model_temp)[:, 4] == 0)
    clu_cent_ulb = clu_cent_all[ulabel_clu_cen, :]
    D = np.zeros((len(clu_cent_ulb), len(clu_cent_lb)))
    for i in range(len(clu_cent_ulb)):
        for j in range(len(clu_cent_lb)):
            D[i, j] = np.linalg.norm(clu_cent_ulb[i, :] - clu_cent_lb[j, :])
    D[D == 0] = 1000
    minMatrix = np.min(D)
    c = np.where(D == minMatrix)
    row = c[0]  # 行号,是个数组
    col = c[1]  # 列号，是个数组
    if len(col) > 1:
        col = col[0]
    elif len(col) == 0:
        col = col[0]
    if len(row) > 1:
        row = row[0]
    mc1 = Model_temp[ulabel_clu_cen[row]]
    mc2 = Model_temp[label_clu_cen[col]]
    mc = [mc1[0] + mc2[0], mc1[1] + mc2[1], mc1[2] + mc2[2], max(mc1[3], mc2[3]), max(mc1[4] + mc2[4])]
    LS = mc[0]
    SS = mc[1]
    N_pt = mc[2]
    clu_center = LS / N_pt
    clu_r = np.sqrt(sum(SS / N_pt) - sum((LS / N_pt) ** 2))
    mc.append(clu_center)
    mc.append(clu_r)
    mc.append(max(mc1[7], mc2[7]))
    mc.append(max(mc1[8], mc2[8]))
    a = len(Model_temp)
    Model_temp.append(mc)
    Model_temp[ulabel_clu_cen[row]] = []
    Model_temp[label_clu_cen[col]] = []
    return Model_temp


def mergMC(label_clu_cen, Model_temp):
    clu_cent = np.array(Model_temp)[:, 5]
    clu_cent = clu_cent[label_clu_cen]
    D = np.zeros((len(clu_cent), len(clu_cent)))
    for i in range(len(clu_cent)):
        for j in range(len(clu_cent)):
            D[i, j] = np.linalg.norm(clu_cent[i] - clu_cent[j])
    D[D == 0] = 1000
    minMatrix = np.min(D)
    c = np.where(D == minMatrix)
    row = c[0]  # 行号,是个数组
    col = c[1]  # 列号，是个数组
    mc1 = Model_temp[label_clu_cen[0][row[0]]]
    mc2 = Model_temp[label_clu_cen[0][col[0]]]
    mc = [mc1[0] + mc2[0], mc1[1] + mc2[1], mc1[2] + mc2[2], mc1[3], mc1[4]]
    LS = mc[0]
    SS = mc[1]
    N_pt = mc[2]
    clu_center = LS / N_pt
    clu_r = np.sqrt(sum(SS / N_pt) - sum((LS / N_pt) ** 2))
    mc.append(clu_center)
    mc.append(clu_r)
    mc.append(max(mc1[7], mc2[7]))
    mc.append(max(mc1[8], mc2[8]))
    Model_temp.append(mc)
    Model_temp[label_clu_cen[0][row[0]]] = []
    return Model_temp


# ##########获得不重复的数组a，但不排序，以及原数组在a中下标的位置
def np_unranked_unique(nparray):
    n_unique = len(np.unique(nparray))
    ranked_unique = np.zeros([n_unique])
    i = 0
    for x in nparray:
        if x not in ranked_unique:
            ranked_unique[i] = x
            i += 1
    m = []
    for j in nparray:
        m.append(np.where(j == ranked_unique)[0][0])
    m = np.array(m)
    return ranked_unique, m


def findMaxClass(Model_temp):
    mcs = np.array(Model_temp)[:, 3]
    label_mcs_idx = np.where(np.array(Model_temp)[:, 4] != 0)
    label_mcs = mcs[label_mcs_idx]
    train_cls_lb, cid2 = np_unranked_unique(label_mcs)
    ui_cid2 = np.unique(cid2)
    c = np.zeros((len(cid2), len(ui_cid2)))
    for i in range(len(c)):
        d = np.where(cid2[i] == ui_cid2)[0][0]
        c[i, d] = 1
    counts2 = np.sum(c, axis=0)
    counts2 = counts2.reshape((len(counts2), 1))
    fre = np.amax(counts2)  # 获得counts2的最大值
    I = np.argmax(counts2)  # 获得最大值所在位置的索引
    mxclabel = train_cls_lb[I]
    return mxclabel, fre


