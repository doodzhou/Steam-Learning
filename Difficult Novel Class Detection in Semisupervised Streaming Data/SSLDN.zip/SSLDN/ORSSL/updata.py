import numpy as np


def update_Model(Model, CurrentTime, lamda, wT):
    impr = np.array(Model)[:, 8]
    impr = impr*(2**(-lamda*(CurrentTime - np.array(Model)[:, 7])))
    np.array(Model)[:, 8] = impr
    c = []
    for i in range(len(impr)):
        if np.array(Model)[i, 8] < wT:
            c.append(i)
    np.delete(np.array(Model), c, axis=0)
    # np.array(Model)[impr < wT, :] = []
    return Model


def update_micro(Model_temp, ex, idx, currentTime):
    LS = np.array(Model_temp)[idx, 0] + ex[0]
    SS = np.array(Model_temp)[idx, 1] + ex[0]**2
    N_pt = np.array(Model_temp)[idx, 2] + 1
    clu_center = LS/N_pt
    clu_r = np.sqrt(sum(SS/N_pt)-sum((LS/N_pt)**2))
    Model_temp[idx][0] = LS  # LS
    Model_temp[idx][1] = SS  # SS
    Model_temp[idx][2] = N_pt  # total ex in mc
    if ex[2] == 1 and Model_temp[idx][4] == 0:
        Model_temp[idx][3] = ex[1]
        Model_temp[idx][4] = 1  # label flg
    Model_temp[idx][5] = clu_center
    Model_temp[idx][6] = clu_r
    Model_temp[idx][7] = currentTime  # current time
    return Model_temp
