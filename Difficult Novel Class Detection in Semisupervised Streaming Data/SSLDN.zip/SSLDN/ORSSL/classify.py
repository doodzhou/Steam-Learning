import numpy as np
from sklearn.neighbors import NearestNeighbors


# ##########获得不重复的数组a，但不排序，以及原数组在a中下标的位置
def np_unranked_unique(nparray):
    n_unique = len(np.unique(nparray))
    ranked_unique = np.zeros([n_unique])
    i = 0
    for x in nparray:
        if x not in ranked_unique:
            ranked_unique[i] = x
            i += 1
    m = []
    for j in nparray:
        m.append(np.where(j == ranked_unique)[0][0])
    m = np.array(m)
    return ranked_unique, m


def classify(ex, Model, weight,num_of_knn):
    # ex是个列表，用于存储数据，标签，和label_flg
    # ex= [[data],label,label_flg]
    #print("np.array(Model)", Model, len(Model))
    Model = np.array(Model)
    clu_cent = Model[:, 5]
    label_clu_cen = np.where(Model[:, 4] != 0)
    clu_cen = clu_cent[label_clu_cen]
    clu_cent = []
    for i in clu_cen:
        clu_cent.append(i)
    clu_cent = np.array(clu_cent)
    V = np.amax(weight)  # 获得counts2的最大值
    widx = np.argmax(weight)  # 获得最大值所在位置的索引
    knn = [1, 3, 5, 7, 9, 11]
    idxn = [[] for _ in range(num_of_knn)]
    p_label = [[] for _ in range(num_of_knn)]
    for i in range(num_of_knn):
        neigh = NearestNeighbors(n_neighbors=knn[i])
        neigh.fit(clu_cent)
        D, idx = neigh.kneighbors(ex[0].reshape(1, -1))  # D是最近邻矩阵的值，idx:最近邻的索引号
        idxn[i] = label_clu_cen[0][idx]
        nn_label = Model[idxn[i], 3]
        uninn_cls_lb, cid2 = np_unranked_unique(nn_label[0])
        ui_cid2 = np.unique(cid2)
        c = np.zeros((len(cid2), len(ui_cid2)))
        for j in range(len(c)):
            d = np.where(cid2[j] == ui_cid2)[0][0]
            c[j, d] = 1
        counts2 = np.sum(c, axis=0)
        counts2 = counts2.reshape((len(counts2), 1))
        Y = np.amax(counts2)  # 获得counts2的最大值
        I = np.argmax(counts2)  # 获得最大值所在位置的索引
        p_label[i] = uninn_cls_lb[I]
        '''
        if acc_win.shape[1] == acc_win_max_size:
            acc_win = np.delete(acc_win, acc_win.shape[1]-1, 1)
        if i == 0:
            eidx = acc_win.shape[1] + 1
        else:
            eidx = acc_win.shape[1]
        print("acc_win,i, eidx", acc_win,i, eidx)
        if ex[2] == 1:
            if ex[2] == p_label[i]:
                acc_win[i, eidx] = 1
            else:
                acc_win[i, eidx] = 0
        '''
    idxf = idxn[widx]
    final_label = p_label[widx]
    return final_label, idxf

