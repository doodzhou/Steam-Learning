import numpy as np
from sklearn.cluster import KMeans


def initial_model_construction(data, train_class_labels, num_cluster):
    # train_class_labels 是唯一标签[1,2,3,4]
    m, n = data.shape
    train_data = data[:, 0: n - 1]
    train_data_labels = data[:, n-1]
    class_data = [[] for _ in range(len(train_class_labels))]
    class_label = [[] for _ in range(len(train_class_labels))]
    for i in range(len(train_class_labels)):
        class_data[i] = train_data[train_data_labels == train_class_labels[i]]
        class_label[i] = train_data_labels[train_data_labels == train_class_labels[i]]
    num_replicates = 1
    Model = []
    for i in range(len(train_class_labels)):
        cls_data = np.array(class_data[i])
        if len(cls_data) <= num_cluster:
            KK = np.ceil(len(cls_data)/2)
        else:
            KK = num_cluster
        kmeans = KMeans(n_clusters=KK, random_state=1, max_iter=1000).fit(cls_data)
        membership = kmeans.labels_
        ctrs = kmeans.cluster_centers_
        for j in range(KK):
            clu_pt = np.where(membership == j)
            clu_data = cls_data[clu_pt[0], :]
            N_pt = clu_data.shape[0]
            clu_center = ctrs[j, :]
            LS = np.sum(clu_data, axis=0)
            SS = np.sum(clu_data**2, axis=0)
            clu_r = np.sqrt(sum(SS/N_pt) - sum((LS/N_pt)**2))
            micro_clu = [LS, SS, N_pt, train_class_labels[i], 1, LS / N_pt, clu_r, 0, 1]
            Model.append(micro_clu)
    #   Model:[[micro_clu1],[micro_clu2],[micro_clu3]...]
    return Model












