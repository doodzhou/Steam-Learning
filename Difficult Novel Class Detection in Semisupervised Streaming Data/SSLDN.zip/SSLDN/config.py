#max_height = 4
min_leaf_size = 4
tree_size = 220
max_tree = 30

# pendigite tree_size = 40,max_tree=15
# satimage tree_size = 110,max_tree=10
# HAR tree_size = 30,max_tree=10
# [1,4,9] pendigite tree_size = 70, max_tree=10
# pendigite [3,5,9] tee_size = 20,max_tree=15
# segment lowalpha tee_size = 30,max_tree=15
# alpha_fasionmnist tree_size = 9,max_tree=15
