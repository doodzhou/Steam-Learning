import matplotlib.pyplot as plt
import xlrd
import numpy as np


def pen_diff_xls(nopath):
    workbook = xlrd.open_workbook(nopath)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第11个表格
    usfacc = []
    usff1 = []
    seenacc = []
    seenf1 = []
    senneacc = []
    sennef1 = []
    datasize = []
    orsslacc = []
    orsslf1 = []
    iforestacc = []
    iforestf1 = []
    macc = []
    mf1 = []
    facc = []
    ff1 = []
    nacc = []
    nf1 = []
    for ino in range(2, worksheet.nrows):
        dasize = worksheet.cell_value(ino, 0)
        datasize.append(dasize)
        uacc = worksheet.cell_value(ino, 1)
        usfacc.append(uacc)
        uf1 = worksheet.cell_value(ino, 2)
        usff1.append(uf1)
        sacc = worksheet.cell_value(ino, 3)
        seenacc.append(sacc)
        sf1 = worksheet.cell_value(ino, 4)
        seenf1.append(sf1)
        snacc = worksheet.cell_value(ino, 5)
        senneacc.append(snacc)
        snf1 = worksheet.cell_value(ino, 6)
        sennef1.append(snf1)
        oracc = worksheet.cell_value(ino, 7)
        orsslacc.append(oracc)
        orf1 = worksheet.cell_value(ino, 8)
        orsslf1.append(orf1)
        iacc = worksheet.cell_value(ino, 9)
        iforestacc.append(iacc)
        if1 = worksheet.cell_value(ino, 10)
        iforestf1.append(if1)
        mmacc = worksheet.cell_value(ino, 11)
        macc.append(mmacc)
        mmf1 = worksheet.cell_value(ino, 12)
        mf1.append(mmf1)
        ffacc = worksheet.cell_value(ino, 13)
        facc.append(ffacc)
        fff1 = worksheet.cell_value(ino, 14)
        ff1.append(fff1)
        nnacc = worksheet.cell_value(ino, 15)
        nacc.append(nnacc)
        nnf1 = worksheet.cell_value(ino, 16)
        nf1.append(nnf1)
    DSIZE = np.array(datasize)
    UACC = np.array(usfacc)
    UF1 = np.array(usff1)
    SACC = np.array(seenacc)
    SF1 = np.array(seenf1)
    SEACC = np.array(senneacc)
    SEF1 = np.array(sennef1)
    OACC = np.array(orsslacc)
    OF1 = np.array(orsslf1)
    IACC = np.array(iforestacc)
    IF1 = np.array(iforestf1)
    MACC = np.array(macc)
    MF1 = np.array(mf1)
    FACC = np.array(facc)
    FF1 = np.array(ff1)
    NACC = np.array(nacc)
    NF1 = np.array(nf1)
    return DSIZE, UACC, UF1, SACC, SF1, SEACC, SEF1, OACC, OF1, IACC, IF1, MACC, MF1, FACC, FF1, NACC, NF1


# #######################画出三维图######################################
def plot(DSIZE, UACC, UF1, SACC, SF1, SEACC, SEF1, OACC, OF1, IACC, IF1, MACC, MF1, FACC, FF1, NACC, NF1):
    # ######################在同一个图中####################
    plt.figure(1)
    plt.plot(DSIZE, UACC, color='#7bc8f8', label='satimage', ls='solid', marker='s', markersize=4.5, linewidth=1.8)   # ls或linestyl
    plt.plot(DSIZE, SACC, color='#3c73a8', label='pendigits',  ls='solid', marker='*', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, SEACC, color='#75b841', label='HAR', ls='solid', marker='o', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, OACC, color='#fcc006', label='USPS', ls='solid', marker='*', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, IACC, color='#a66fd5', label='MNIST-10K', ls='solid', marker='x', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, MACC, color='#FF7F50', label='MNIST', ls='solid', marker='^', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, FACC, color='#5539CC', label='Fashion-MNIST', ls='solid', marker='d', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, NACC, color='#778899', label='NYTimes', ls='solid', marker='3', markersize=4.5, linewidth=1.8)
    plt.grid(color="k", linestyle=":", axis='y')
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=4, borderaxespad=0, fancybox=True, shadow=True)
    plt.tick_params(labelsize=12)
    plt.axvline(x=4, ls=":", c="red")  # 添加垂直直线
    # plt.axvline(x=30, ls=":", c="red")  # 添加垂直直线
    plt.xlabel('p', fontsize=14)
    plt.ylabel('ACC', fontsize=14)

    plt.figure(2)
    plt.plot(DSIZE, UF1, color='#7bc8f8', label='satimage', ls='solid', marker='s', markersize=4.5, linewidth=1.8)  # ls或linestyle
    plt.plot(DSIZE, SF1, color='#3c73a8', label='pendigits', ls='solid', marker='*', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, SEF1, color='#75b841', label='HAR', ls='solid', marker='o', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, OF1, color='#fcc006', label='USPS', ls='solid', marker='*', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, IF1, color='#a66fd5', label='MNIST-10K', ls='solid', marker='x', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, MF1, color='#FF7F50', label='MNIST', ls='solid', marker='^', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, FF1, color='#5539CC', label='Fashion-MNIST', ls='solid', marker='d', markersize=4.5, linewidth=1.8)
    plt.plot(DSIZE, NF1, color='#778899', label='NYTimes', ls='solid', marker='3', markersize=4.5, linewidth=1.8)
    plt.grid(color="grey", linestyle=":", axis='y')
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=4, borderaxespad=0, fancybox=True, shadow=True)
    plt.tick_params(labelsize=12)
    plt.axvline(x=4, ls=":", c="red")  # 添加垂直直线
    # plt.axvline(x=30, ls=":", c="red")  # 添加垂直直线
    plt.xlabel('p', fontsize=14)
    plt.ylabel('F1', fontsize=14)
    plt.draw()
    plt.show()


if __name__ == '__main__':
    path1 = 'E:\\tow-paper\\p.xls'
    DSIZE, UACC, UF1, SACC, SF1, SEACC, SEF1, OACC, OF1, IACC, IF1, MACC, MF1, FACC, FF1, NACC, NF1 = pen_diff_xls(path1)
    plot(DSIZE, UACC, UF1, SACC, SF1, SEACC, SEF1, OACC, OF1, IACC, IF1, MACC, MF1, FACC, FF1, NACC, NF1)
