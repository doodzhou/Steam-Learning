# -*- coding: utf-8 -*-

from usfSeen.Update import *
from usfSeen2.SENNE.model import *
import time
import numpy as np
from sklearn.metrics import precision_score, recall_score, accuracy_score

import warnings
warnings.filterwarnings('ignore')
np.random.seed(0)  # for demo reproducibility


def evaluate_acc_f1(truth, preds):
    acc = accuracy_score(truth, preds)
    precision = precision_score(truth, preds, average='macro')
    recall = recall_score(truth, preds, average='macro')
    f1 = 2 * precision * recall / (precision + recall)

    print(f"acc={acc:.4f} f1={f1:.4f}")


def load_data1(period_num, ratio):
    file_name = 'E://tow-paper//datasets//HAR/' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)-1):
        if period_num == 1:
            bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
            label_state[0:2] = 1
        else:
            bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


def load_data(period_num, ratio):
    file_name = 'E://tow-paper//datasets//HAR//' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    # fore_index = 3
    # now_index = fore_index + period_num - (period_num-1)
    ui = np.unique(Y)
    for i in range(len(ui)):
        bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


if __name__ == '__main__':
    X0, Y0, label_state0 = load_data(0, 0.01)  # 初始训练集
    num_samples = 100  # number of set
    sample_size = 20  # subsample size for each set
    CurtNumDim = X0.shape[1]
    newclass_num = 1
    all_truth = []
    all_preds = []
    time_begin = time.time()
    for period in range(1, 9):
        print(f"------ period: {period} ", end=" ")
        X, Y, label_state = load_data1(period, 0.01)  # 当前时期的文件
        # 初始化模型，senne的初始化模型是根据上一个判断过的数据建立的
        Xchus, Ychus, label_statechus = load_data1(period - 1, 0.01)  # 上一个时期的文件
        ui = np.unique(Ychus)
        train_num = len(ui)
        allabel_num = []  # 每个标签的总数 [1143, 1143, 1144, 1055, 1144, 1055, 1056, 1142, 1055, 1055]
        for i in np.unique(Ychus):
            allabel_num.append(np.sum(Y == i))
        num_per_class = min(allabel_num)  # 每个类选取的样本是已知类中数量的最小值
        choice_index = []
        for isp in range(train_num):
            sub_num = num_per_class  # int(np.ceil(allabel_num[isp] / split_num))  # 初始训练集取2倍的每个文件的数据量
            index = list(np.where(Ychus == ui[isp]))
            choice = np.random.choice(index[0], size=sub_num, replace=False).tolist()  # 得到的是数据的下标
            choice_index.append(choice)
        choice_index = sum(choice_index, [])
        choice_index = sorted(choice_index)
        Xdata = Xchus[choice_index]
        Xlabel = Ychus[choice_index]
        traindata = np.concatenate((Xdata, Xlabel.reshape((len(Xlabel), 1))), axis=1)
        # ################到此初始模型建立完成###################
        streamdata = X
        streamdatalabel = Y
        max_num = max(np.unique(streamdatalabel))
        for i in range(len(streamdatalabel)):
            if streamdatalabel[i] == max_num:
                streamdatalabel[i] = 999
        for j in streamdatalabel:
            all_truth.append(j)
        # #############准备工作完成########################
        period_begin = time.time()
        model3 = model_SENNE(traindata, num_samples, sample_size, CurtNumDim)
        buffsize = 200
        score_threshold = 0.88
        result_label, after_model, axis_point = Predict(train_num, streamdata, streamdatalabel, buffsize, model3,
                                                        score_threshold)
        for jj in result_label:
            all_preds.append(jj)
        label_com = np.zeros((len(result_label), 2))
        label_com[:, 0] = result_label[:, 0]
        label_com[:, 1] = streamdatalabel
        evaluate_acc_f1(label_com[:, 1], label_com[:, 0])
        print(f"senne的本次运行时间 time={time.time() - period_begin:.4f}s")
    evaluate_acc_f1(all_truth, all_preds)
    time_end = time.time() - time_begin
    print(f"time = {time_end:.3f}s")














