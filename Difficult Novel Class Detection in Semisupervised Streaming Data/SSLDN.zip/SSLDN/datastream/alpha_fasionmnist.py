import numpy as np
from scipy.io import loadmat
import random
import pandas as pd
from usfSeen2.read_data import *

# #################################形成流数据集,分成几个txt文件##########################################
def spilit_file(data, target_dir):
    '''
    data:数组形式
    split_num:分割成几个文件
    target_dir:分割文件的地址
    '''
    # 标签数据量
    combi1 = [0, 2]
    combi2 = [6]
    # combi1 = [3, 5]
    # combi2 = [9]
    Y = data[:, data.shape[1] - 1]
    index_x = np.arange(data.shape[0])  # 得到整个数据的索引号
    knowdata1 = data[Y == combi1[0]]
    knowdata2 = data[Y == combi1[1]]
    unknowdata3 = data[Y == combi2[0]]
    knowdata = np.concatenate((knowdata1, knowdata2), axis=0)
    knowlabel = knowdata[:, knowdata.shape[1] - 1]
    index_x = np.arange(knowdata.shape[0])  # 得到整个数据的索引号
    ui = np.unique(Y)
    print("标签：", ui)
    allabel_num = []  # 每个标签的总数 [1143, 1143, 1144, 1055, 1144, 1055, 1056, 1142, 1055, 1055]
    for i in ui:
        allabel_num.append(np.sum(Y == i))
    print("allabel_num", allabel_num)
    with open(target_dir + 'lowalpha_' + str(0) + ".txt", 'w+') as f_target:
        choice_index = []
        for isp in combi1:
            sub_num = 3000  # 初始训练集取2倍的每个文件的数据量
            print("sub_num", sub_num)
            index = list(np.where(knowlabel == isp))
            choice = np.random.choice(index[0], size=sub_num, replace=False).tolist()  # 得到的是数据的下标
            choice_index.append(choice)
        choice_index = sum(choice_index, [])
        choice_index = sorted(choice_index)
        train = knowdata[choice_index]
        m, n = train.shape
        traindata = train[:, 0:n - 1]
        trainlabel = train[:, n - 1]
        trainlabel[trainlabel == combi1[0]] = 0
        trainlabel[trainlabel == combi1[1]] = 1
        train = np.concatenate((traindata, trainlabel.reshape((len(trainlabel), 1))), axis=1)
        np.random.shuffle(train)
        np.savetxt(f_target, train, fmt='%s', delimiter=", ")
        # for temp in choice_data0:
        # f_target.write(str(temp)+"\n")

    with open(target_dir + 'lowalpha_' + str(1) + ".txt", 'w+') as f_target:
        remainder_data = knowdata[np.delete(index_x, choice_index)]
        remainder_Y = remainder_data[:, remainder_data.shape[1] - 1]
        choice_index = []
        for isp in combi1:
            sub_num = 500  # 初始训练集取2倍的每个文件的数据量
            print("sub_num", sub_num)
            index = list(np.where(remainder_Y == isp))
            choice = np.random.choice(index[0], size=sub_num, replace=False).tolist()  # 得到的是数据的下标
            choice_index.append(choice)
        choice_index = sum(choice_index, [])
        choice_index = sorted(choice_index)
        remaintrain = remainder_data[choice_index]
        sub_num = 1000  # 未知数据的随机取值数量
        unkchoice = np.random.choice(len(unknowdata3), size=sub_num, replace=False).tolist()  # 得到的是数据的下标
        unkchoice = sorted(unkchoice)
        unchoicedata = unknowdata3[unkchoice]
        test = np.concatenate((remaintrain, unchoicedata), axis=0)
        m, n = test.shape
        testdata = test[:, 0:n - 1]
        testlabel = test[:, n - 1]
        print(np.unique(testlabel))
        testlabel[testlabel == combi1[0]] = 0
        testlabel[testlabel == combi1[1]] = 1
        testlabel[testlabel == combi2[0]] = 2
        test = np.concatenate((testdata, testlabel.reshape((len(testlabel), 1))), axis=1)
        np.random.shuffle(test)
        np.savetxt(f_target, test, fmt='%s', delimiter=", ")


if __name__ == "__main__":
    path = "E:/tow-paper/datasets/Fasion_MNIST"
    alldata = load_mnist_train(path, kind='train')
    target_dir = 'E://tow-paper//datasets//Fasion_MNIST//'
    spilit_file(alldata, target_dir)
