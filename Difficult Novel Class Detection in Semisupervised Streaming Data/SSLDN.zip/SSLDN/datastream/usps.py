import numpy as np
import pandas as pd
from scipy.io import loadmat


# #################################形成流数据集,分成几个txt文件##########################################
def spilit_file(data, split_num, target_dir):
    '''
    data:数组形式
    split_num:分割成几个文件
    target_dir:分割文件的地址
    '''
    # 标签数据量
    label_num = 2
    X = data[:, 0: data.shape[1] - 1]
    Y = data[:, data.shape[1] - 1]
    index_x = np.arange(data.shape[0])  # 得到整个数据的索引号
    ui = np.unique(Y)
    print("标签：", ui)
    allabel_num = []  # 每个标签的总数 [1143, 1143, 1144, 1055, 1144, 1055, 1056, 1142, 1055, 1055]
    for i in ui:
        allabel_num.append(np.sum(Y == i))
    with open(target_dir + str(0) + ".txt", 'w+') as f_target:
        choice_index = []
        for isp in range(label_num):
            sub_num = int(2 * np.ceil(allabel_num[isp] / split_num))  # 初始训练集取2倍的每个文件的数据量
            index = list(np.where(Y == isp))
            choice = np.random.choice(index[0], size=sub_num, replace=False).tolist()  # 得到的是数据的下标
            choice_index.append(choice)
        choice_index = sum(choice_index, [])
        choice_index = sorted(choice_index)
        choice_data0 = data[choice_index]
        np.random.shuffle(choice_data0)
        np.savetxt(f_target, choice_data0, fmt='%s', delimiter=", ")
        # for temp in choice_data0:
        # f_target.write(str(temp)+"\n")
    for name in range(1, split_num-1):
        with open(target_dir + str(name) + ".txt", 'w+') as f_target:
            remainder_data = data[np.delete(index_x, choice_index)]
            remainder_Y = remainder_data[:, remainder_data.shape[1] - 1]
            choice_rem = []
            ui = np.unique(remainder_Y)
            print("ui", ui)
            allabel_re = []  # 每个标签的总数 [1143, 1143, 1144, 1055, 1144, 1055, 1056, 1142, 1055, 1055]
            for i in ui:
                allabel_re.append(np.sum(remainder_Y == i))
            for isp in range(label_num+name):
                sub_num = int(np.ceil(allabel_re[isp] / (split_num-name)))  # 初始训练集取每个文件的数据量除以分割数
                print("sub_num", sub_num)
                sub_index = list(np.where(remainder_Y == isp))
                remchoice = np.random.choice(sub_index[0], size=sub_num, replace=False).tolist()  # 得到的是数据的下标
                choice_rem.append(remchoice)
            choice_rem = sum(choice_rem, [])
            choice_rem = sorted(choice_rem)
            print("choice_rem", len(choice_rem))
            choice_dataname = remainder_data[choice_rem]
            np.random.shuffle(choice_dataname )
            np.savetxt(f_target, choice_dataname, fmt='%s', delimiter=", ")
        data = remainder_data
        index_x = np.arange(data.shape[0])  # 得到剩余数据的索引号
        choice_index = choice_rem

    with open(target_dir + str(split_num-1) + ".txt", 'w+') as f_target:
        remainder_data = data[np.delete(index_x, choice_index)]
        remainder_Y = remainder_data[:, remainder_data.shape[1] - 1]
        choice_rem = []
        ui = np.unique(remainder_Y)
        print("ui", ui)
        allabel_re = []  # 每个标签的总数 [1143, 1143, 1144, 1055, 1144, 1055, 1056, 1142, 1055, 1055]
        for i in ui:
            allabel_re.append(np.sum(remainder_Y == i))
        print("allabel_re", allabel_re)
        np.savetxt(f_target, remainder_data, fmt='%s', delimiter=", ")


if __name__ == "__main__":
    # ######################分usps数据集##################################
    alldata = loadmat("E://tow-paper/datasets/usps/USPS.mat")
    images = alldata["fea"]
    labels = alldata["gnd"]
    labels[labels == 10] = 0
    all_data = np.hstack((images, labels))
    target_usps = 'E://tow-paper//datasets//usps//'
    spilit_file(all_data, 9, target_usps)
