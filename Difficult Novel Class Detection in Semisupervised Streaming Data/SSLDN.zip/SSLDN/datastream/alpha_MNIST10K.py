import gzip
import os
import struct
import numpy as np


def load_mnist_train(path, kind='t10k'):
    # path:数据集的路径
    # kind:值为train，代表读取训练集

    labels_path = os.path.join(path, '%s-labels-idx1-ubyte.gz' % kind)
    images_path = os.path.join(path, '%s-images-idx3-ubyte.gz' % kind)
    # 使用gzip打开文件
    with gzip.open(labels_path, 'rb') as lbpath:
        # 使用struct.unpack方法读取前两个数据，>代表高位在前，I代表32位整型。lbpath.read(8)表示一次从文件中读取8个字节
        # 这样读到的前两个数据分别是magic number和样本个数
        magic, n = struct.unpack('>II', lbpath.read(8))
        # 使用np.fromstring读取剩下的数据，lbpath.read()表示读取所有的数据
        labels = np.fromstring(lbpath.read(), dtype=np.uint8)
    with gzip.open(images_path, 'rb') as imgpath:
        magic, num, rows, cols = struct.unpack('>IIII', imgpath.read(16))
        images = np.fromstring(imgpath.read(), dtype=np.uint8).reshape(len(labels), 784)
    data = np.insert(images, images.shape[1], values=labels, axis=1)  # 有10000个数据，标签在最后一列
    return data


# #################################形成流数据集,分成几个txt文件##########################################
# #################################形成流数据集,分成几个txt文件##########################################
def spilit_file(data, target_dir):
    '''
    data:数组形式
    split_num:分割成几个文件
    target_dir:分割文件的地址
    '''
    # 标签数据量
    combi1 = [9, 4]
    combi2 = [7]
    # combi1 = [3, 5]
    # combi2 = [9]
    Y = data[:, data.shape[1] - 1]
    index_x = np.arange(data.shape[0])  # 得到整个数据的索引号
    knowdata1 = data[Y == combi1[0]]
    knowdata2 = data[Y == combi1[1]]
    unknowdata3 = data[Y == combi2[0]]
    knowdata = np.concatenate((knowdata1, knowdata2), axis=0)
    knowlabel = knowdata[:, knowdata.shape[1] - 1]
    index_x = np.arange(knowdata.shape[0])  # 得到整个数据的索引号
    ui = np.unique(Y)
    print("标签：", ui)
    allabel_num = []  # 每个标签的总数 [1143, 1143, 1144, 1055, 1144, 1055, 1056, 1142, 1055, 1055]
    for i in ui:
        allabel_num.append(np.sum(Y == i))
    print("allabel_num", allabel_num)
    with open(target_dir + 'lowalpha_' + str(0) + ".txt", 'w+') as f_target:
        choice_index = []
        for isp in combi1:
            sub_num = 600  # 初始训练集取2倍的每个文件的数据量
            print("sub_num", sub_num)
            index = list(np.where(knowlabel == isp))
            choice = np.random.choice(index[0], size=sub_num, replace=False).tolist()  # 得到的是数据的下标
            choice_index.append(choice)
        choice_index = sum(choice_index, [])
        choice_index = sorted(choice_index)
        train = knowdata[choice_index]
        m, n = train.shape
        traindata = train[:, 0:n - 1]
        trainlabel = train[:, n - 1]
        trainlabel[trainlabel == combi1[0]] = 0
        trainlabel[trainlabel == combi1[1]] = 1
        train = np.concatenate((traindata, trainlabel.reshape((len(trainlabel), 1))), axis=1)
        np.random.shuffle(train)
        np.savetxt(f_target, train, fmt='%s', delimiter=", ")
        # for temp in choice_data0:
        # f_target.write(str(temp)+"\n")

    with open(target_dir + 'lowalpha_' + str(1) + ".txt", 'w+') as f_target:
        remainder_data = knowdata[np.delete(index_x, choice_index)]
        remainder_Y = remainder_data[:, remainder_data.shape[1] - 1]
        choice_index = []
        for isp in combi1:
            sub_num = 200  # 初始训练集取2倍的每个文件的数据量
            print("sub_num", sub_num)
            index = list(np.where(remainder_Y == isp))
            choice = np.random.choice(index[0], size=sub_num, replace=False).tolist()  # 得到的是数据的下标
            choice_index.append(choice)
        choice_index = sum(choice_index, [])
        choice_index = sorted(choice_index)
        remaintrain = remainder_data[choice_index]
        sub_num = 500  # 未知数据的随机取值数量
        unkchoice = np.random.choice(len(unknowdata3), size=sub_num, replace=False).tolist()  # 得到的是数据的下标
        unkchoice = sorted(unkchoice)
        unchoicedata = unknowdata3[unkchoice]
        test = np.concatenate((remaintrain, unchoicedata), axis=0)
        m, n = test.shape
        testdata = test[:, 0:n - 1]
        testlabel = test[:, n - 1]
        print(np.unique(testlabel))
        testlabel[testlabel == combi1[0]] = 0
        testlabel[testlabel == combi1[1]] = 1
        testlabel[testlabel == combi2[0]] = 2
        test = np.concatenate((testdata, testlabel.reshape((len(testlabel), 1))), axis=1)
        np.random.shuffle(test)
        np.savetxt(f_target, test, fmt='%s', delimiter=", ")


if __name__ == '__main__':

    data = load_mnist_train("E://tow-paper//datasets//MNIST-10K//")
    target_usps = 'E://tow-paper//datasets//MNIST-10K//'
    spilit_file(data, target_usps)