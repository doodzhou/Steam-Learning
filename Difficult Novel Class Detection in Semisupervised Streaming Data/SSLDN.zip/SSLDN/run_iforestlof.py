# -*- coding: utf-8 -*-

# from Update import *
from IForestKNN.iforest import *
import time
import numpy as np
import pandas as pd
from sklearn.metrics import precision_score, recall_score, accuracy_score

import warnings
warnings.filterwarnings('ignore')
np.random.seed(0)  # for demo reproducibility


def evaluate_acc_f1(truth, preds):
    acc = accuracy_score(truth, preds)
    precision = precision_score(truth, preds, average='macro')
    recall = recall_score(truth, preds, average='macro')
    f1 = 2 * precision * recall / (precision + recall)

    print(f"acc={acc:.4f} f1={f1:.4f}")


def load_data1(period_num, ratio):
    file_name = 'E://tow-paper//datasets//pendigits/' + 'varyalpha_'+str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)-1):
        if period_num == 1:
            bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
            label_state[0:2] = 1
        else:
            bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


def load_data(period_num, ratio):
    file_name = 'E://tow-paper//datasets//pendigits//' + 'varyalpha_'+ str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    # fore_index = 3
    # now_index = fore_index + period_num - (period_num-1)
    ui = np.unique(Y)
    for i in range(len(ui)):
        bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


from sklearn import svm
from LOFsvm.lofsvm import *
from sklearn.metrics import pairwise_distances
if __name__ == '__main__':
    all_truth = []
    all_preds1 = []
    all_preds2 = []
    time_begin = time.time()
    for period in range(1, 2):
        print(f"------ period: {period} ", end=" ")
        X0, Y0, label_state0 = load_data(period-1, 0.01)  # 初始训练集
        # ######################IForestKNN 的初始化############################
        period_begin1 = time.time()
        clf = IsolationForest()
        clf.fit(X0, n_samples=200)
        Average_score = sum(clf.predict(X0)) / len(X0)
        # knn = neighbors.KNeighborsClassifier()
        # knn.fit(X0, Y0)
        ssvm = svm.SVC()
        ssvm.fit(X0, Y0)
        X, Y, label_state = load_data1(period, 0.01)  # 当前时期的文件
        # period_begin1 = time.time()
        proid_lab = []
        proid_tru = [Y.tolist()]
        for j in Y:
            all_truth.append(j)
        # clf = IsolationForest()
        # clf.fit(X, n_samples=256)
        # Average_score = sum(clf.predict(X)) / len(X)
        # xi_score = clf._predict(b)
        ui = np.unique(Y)
        n = X.shape[0]
        for i in range(n):
            if label_state[i] == 1:
                proid_lab.append(Y[i])
                all_preds1.append(Y[i])
            else:
                xi_score = clf._predict(X[i])
                if xi_score < Average_score:  # 说明xi是正常值
                    # 调用KNN的分类器
                    # knn = neighbors.KNeighborsClassifier()
                    # knn.fit(X, Y)
                    predictedLabel = ssvm.predict([X[i]])
                    proid_lab.append(predictedLabel[0])
                    all_preds1.append(predictedLabel[0])
                else:
                    proid_lab.append(ui[-1])
                    all_preds1.append(ui[-1])
        evaluate_acc_f1(proid_tru[0], proid_lab)
        print(f"iforest time={time.time() - period_begin1:.4f}s")
        # #################以上是iforest+svm的实现#####################3
    for period in range(1, 2):
        print(f"------ period: {period} ", end=" ")
        X0, Y0, label_state0 = load_data(period - 1, 0.01)  # 初始训练集
        # ######################IForestKNN 的初始化############################
        period_begin = time.time()
        clf = IsolationForest()
        clf.fit(X0, n_samples=200)
        Average_score = sum(clf.predict(X0)) / len(X0)
        # knn = neighbors.KNeighborsClassifier()
        # knn.fit(X0, Y0)
        ssvm = svm.SVC()
        ssvm.fit(X0, Y0)
        X, Y, label_state = load_data1(period, 0.01)  # 当前时期的文件
        # period_begin = time.time()
        proid_lab = []
        proid_tru = [Y.tolist()]
        # clf = IsolationForest()
        # clf.fit(X, n_samples=256)
        # Average_score = sum(clf.predict(X)) / len(X)
        # xi_score = clf._predict(b)
        ui = np.unique(Y)
        n = X.shape[0]
        # pairwise distances between all points
        D = pairwise_distances(X)
        # K-nearest neighbors distances for each point (by row)
        KNN = np.sort(D, axis=1)
        # K-nearest neighbor indices for each points (by row)
        KNN_indices = np.argsort(D, axis=1)
        for i in range(n):
            if label_state[i] == 1:
                proid_lab.append(Y[i])
                all_preds2.append(Y[i])
            else:
                xi_score = LOF_k(i, 50, KNN, D, KNN_indices)
                if xi_score < 1:  # 说明xi是正常值
                    # 调用KNN的分类器
                    # knn = neighbors.KNeighborsClassifier()
                    # knn.fit(X, Y)
                    predictedLabel = ssvm.predict([X[i]])
                    proid_lab.append(predictedLabel[0])
                    all_preds2.append(predictedLabel[0])
                else:
                    proid_lab.append(ui[-1])
                    all_preds2.append(ui[-1])
        evaluate_acc_f1(proid_tru[0], proid_lab)
        print(f"LOF time={time.time() - period_begin:.4f}s")
    evaluate_acc_f1(all_truth, all_preds1)
    evaluate_acc_f1(all_truth, all_preds2)
    time_end = time.time() - time_begin
    print(f"time = {time_end:.3f}s")












