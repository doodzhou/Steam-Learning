# -*- coding: utf-8 -*-

import numpy as np
from collections import deque
import cvxopt as co
from collections import deque
co.solvers.options['show_progress'] = False


class usfSeenLP:

    def __init__(self, options, buffer_size=4):
        # self.data = label_data0
        self.data = np.zeros(shape=(0, 0))
        self.Y = np.zeros(shape=(0, 0))
        self.label = np.zeros(shape=(0, 0))
        self.buffer_size = buffer_size
        self.options = options

    def add_unlabeled_data(self, unlabeld):
        self.data = np.insert(self.data, self.data.shape[0], unlabeld, axis=0)
        self.Y = np.concatenate((self.Y, np.zeros(shape=(1, self.Y.shape[1]))), axis=0)

    def add_dist_x(self):
        m1, m2 = self.dist_x.shape
        assert (m1 == m2 and m1 > 0)
        self.dist_x = np.concatenate((self.dist_x, np.zeros(shape=(1, m2))), axis=0)
        self.dist_x = np.concatenate((self.dist_x, np.zeros(shape=(m1 + 1, 1))), axis=1)
        return self.dist_x


    def add_dist_f(self):
        m1, m2 = self.dist_f.shape
        if m1 == m2 and m1 > 0:
            self.dist_f = np.concatenate((self.dist_f, np.zeros(shape=(1, m2))), axis=0)
            self.dist_f = np.concatenate((self.dist_f, np.zeros(shape=(m1 + 1, 1))), axis=1)
        return self.dist_f

    def add_label_sample(self, x, y):
        m = self.data.shape[0]
        if m != 0:
            self.data = np.concatenate((self.data, np.zeros(shape=(1, len(x)))), axis=0)
            self.label = np.concatenate((self.label, np.array([y])))
        else:
            self.data = np.zeros(shape=(1, len(x)))
            self.label = np.array([y])
        self.data[-1:] = x
        # 判断，如果每个类有标签的数据超过规定的个数，就删除前面的数据和类，保留最近的数据
        class_label = np.unique(self.label)
        for i in range(len(class_label)):
            bb = [k for k in range(len(self.label)) if self.label[k] == class_label[i]]
            if len(bb) > self.buffer_size:
                self.data = np.delete(self.data, bb[0], axis=0)  # 删除self.data的前面的数据
                self.label = np.delete(self.label, bb[0], axis=0)  # 删除self.data的前面的数据

        # self.remove_sample()
        self.dist_x = self.calcDist(self.data)
        class_label = np.unique(self.label)
        self.Y = np.zeros((len(self.label), len(class_label)))
        if class_label[0] == 0:
            for i in range(len(self.label)):
                self.Y[i, int(self.label[i])] = 1
        else:
            for i in range(len(self.label)):
                self.Y[i, int(self.label[i]) - 1] = 1
        H = self.Y.copy()
        self.dist_f = self.calcDist(H)

    def remove_sample(self):
        reserve_data = []
        reserve_label = []
        ui_label = np.unique(self.label)
        for i in range(len(ui_label)):
            bb = [k for k in range(len(self.label)) if self.label[k] == ui_label[i]]
            if len(bb) > self.buffer_size:
                self.data = np.delete(self.data, bb[0], axis=0)  # 删除self.data的前面的数据
                self.label = np.delete(self.label, bb[0], axis=0)  # 删除self.data的前面的数据

    def reserve_sample(self):
        reserve_data = []
        reserve_label = []
        ui_label = np.unique(self.label)
        for i in range(len(ui_label)):
            bb = [k for k in range(len(self.label)) if self.label[k] == ui_label[i]]
            label = np.random.choice(len(bb), 1, replace=False)
            reserve_data.append(self.data[bb[label[0]]])
            # print("reserve_data", reserve_data)
            reserve_label.append(self.label[bb[label[0]]])
        self.data = np.array(reserve_data)
        self.label = np.array(reserve_label)
        self.dist_x = self.calcDist(self.data)
        class_label = np.unique(self.label)
        self.Y = np.zeros((len(self.label), len(class_label)))
        if class_label[0] == 0:
            for i in range(len(self.label)):
                self.Y[i, int(self.label[i])] = 1
        else:
            for i in range(len(self.label)):
                self.Y[i, int(self.label[i]) - 1] = 1
        H = self.Y.copy()
        self.dist_f = self.calcDist(H)

    # calculate distance between nodes' pair.
    def calcDist(self, X):
        n = X.shape[0]
        dist = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                dist[i, j] = dist[j, i] = np.linalg.norm(X[i] - X[j])
        return dist

    def get_distance(self, x1, x2):
        K = np.linalg.norm(x1 - x2)
        return K

    def run(self, x):
        self.add_unlabeled_data(unlabeld=x)
        self.add_dist_x()
        dist_x = self.dist_x
        # print("dist_x",dist_x)
        for idist in range(len(self.data)):
            dist_x[len(self.data)-1, idist] = self.get_distance(x, self.data[idist])
            dist_x[idist, len(self.data)-1] = dist_x[len(self.data)-1, idist]
        self.n, self.c = self.Y.shape
        lambda_ = self.options['lambda_']
        k = self.options['k']
        max_loop_times = self.options['max_loop_times']

        n = self.n
        labeled_count = len(self.Y) - 1  # 有标签数量
        unlabeled_count = 1
        # # init F, the prediction
        F = self.Y.copy()
        # # calc some useful dist matries
        self.add_dist_f()
        dist_f = self.dist_f
        for jdist in range(len(self.Y)):
            dist_f[len(self.Y)-1, jdist] = self.get_distance(F[-1:], self.Y[jdist])
            dist_f[jdist, len(self.Y)-1] = dist_f[len(self.Y)-1, jdist]
        dist_d = dist_x + lambda_ * dist_f
        # # init alpha
        alpha = 0
        sorted_dist_d = np.sort(dist_d, axis=1)
        for i in range(n):
            alpha += k * sorted_dist_d[i, k + 1] - np.sum(sorted_dist_d[i, 0:k])
        alpha /= (2 * n)
        # # init alpha ended
        # ## note that, alpha won't change any more

        # # init S
        S = np.zeros((n, n))
        cvx_P = co.matrix(np.eye(n))
        cvx_G = co.matrix(0.0, (n, n))
        cvx_G[::n + 1] = -1.0
        cvx_A = co.matrix(1.0, (1, n))
        cvx_b = co.matrix(1.0)
        cvx_h = co.matrix(0.0, (n, 1))
        for i in range(n):
            cvx_q = co.matrix(dist_x[i].T / (2 * alpha))
            solve = co.solvers.qp(cvx_P, cvx_q, cvx_G, cvx_h, cvx_A, cvx_b)
            S[i, :] = np.array(solve['x']).ravel()
        # # init S ended

        # for t in trange(max_loop_times, ascii=True, leave=False):
            # S_old = S.copy()
            # # update w
            # w = 1 / (2 / np.sqrt(np.sum(np.dot(dist_x, S))))
            # w = w / np.sum(w)
            # # update w ended

            # # update F
        S_mean = (S.T + S) / 2
        D_S = np.diag(np.sum(S_mean, axis=0))
        L_S = D_S - S_mean
        F_u = - np.matmul(
                np.matmul(
                    np.linalg.inv(L_S[labeled_count:, labeled_count:]),
                    L_S[labeled_count:, :labeled_count]
                ),
                self.Y[:labeled_count]
            )
        F[labeled_count:] = F_u
        # # update F ended

        '''
            # # update S
            dist_f = self.calcDist(F)
            dist_x = dist_x * w
            dist_d = (dist_x + lambda_ * dist_f) / (2 * alpha)

            for i in range(n):
                cvx_q = co.matrix(dist_d[i].T)
                solve = co.solvers.qp(cvx_P, cvx_q, cvx_G, cvx_h, cvx_A, cvx_b)
                S[i, :] = np.array(solve['x']).ravel()

            # # update S ended

            if (np.linalg.norm(S - S_old) / np.linalg.norm(S_old) < 1e-5):
                break
            '''
        # # re-construct F
        F_result = np.argmax(F, axis=1)
        self.data = np.delete(self.data, len(self.data)-1, axis=0)
        self.Y = np.delete(self.Y, len(self.Y)-1, axis=0)
        self.dist_x = np.delete(self.dist_x, len(self.dist_x)-1, axis=0)  # 删除添加的self.dist_x的最后一行
        self.dist_x = np.delete(self.dist_x, self.dist_x.shape[1]-1, axis=1)  # 删除添加的self.dist_x的最后一列
        self.dist_f = np.delete(self.dist_f, len(self.dist_f) - 1, axis=0)  # 删除添加的self.dist_x的最后一行
        self.dist_f = np.delete(self.dist_f, self.dist_f.shape[1] - 1, axis=1)  # 删除添加的self.dist_x的最后一列
        return F_result[-1:]

    def update_outlier(self, outlier_buffer, outlabel, selected_outlier_num):
        # select samples that are most likely to be novel labels as new class instances
        # 选择最有可能成为新标签的样本作为新的类实例
        outlier_buffer = np.array(outlier_buffer)
        outlier_num = outlier_buffer.shape[0]
        outlier_mean = np.mean(outlier_buffer, axis=0)  # 新类缓冲区的平均值
        distance = []
        for i in range(outlier_num):
            d = np.linalg.norm(outlier_buffer[i] - outlier_mean)
            distance.append([d, i])  # 缓冲区中每个数据与中心的距离
        distance = sorted(distance, key=lambda s: s[0])  # 对距离排序
        select_out = []
        for i in range(min(outlier_num, selected_outlier_num)):
            select_out.append(outlier_buffer[distance[i][1]])
        select_out = np.array(select_out)
        self.data = np.concatenate((self.data, select_out), axis=0)
        self.Y = np.concatenate((self.Y, np.zeros(shape=(len(self.Y), 1))), axis=1)
        self.Y = np.concatenate((self.Y, np.zeros(shape=(min(outlier_num, selected_outlier_num), self.Y.shape[1]))), axis=0)
        self.Y[-min(outlier_num, selected_outlier_num):, -1] = 1
        self.dist_x = self.calcDist(self.data)
        # self.dist_f = self.calcDist(self.Y)
        H = self.Y.copy()
        # H = np.concatenate((H, np.zeros(shape=(1, H.shape[1]))), axis=0)
        self.dist_f = self.calcDist(H)
        b = []
        for j in range(selected_outlier_num):
            b.append(outlabel)
        self.label = np.concatenate((self.label, b))

