import numpy as np
from usfSeen2.SEEN.SeenLP import *
from usfSeen2.SEEN.SeenForest import *
from usfSeen2.SENNE.model import *
from usfSeen2.SNECMas.detector import *
from usfSeen2.ORSSL.initialmodel import *
from usfSeen2.duibisuanfa import *
import time
import warnings

warnings.filterwarnings('ignore')


def loadalpha_data1(period_num, ratio):
    file_name = 'E://tow-paper//datasets//usps//' + 'varyalpha_' + str(1) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    Y = data[:, data.shape[1] - 1]
    label_state = np.zeros((len(Y), 1))
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui) - 1):
        if period_num == 1:
            bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
            label_state[0:2] = 1
        else:
            bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


def loadalpha_data(period_num, ratio):
    file_name = 'E://tow-paper//datasets//usps//' + 'varyalpha_' + str(0) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    Y = data[:, data.shape[1] - 1]
    label_state = np.zeros((len(Y), 1))
    # fore_index = 3
    # now_index = fore_index + period_num - (period_num-1)
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)):
        bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


options = {"lambda_": 12, "k": 1, "max_loop_times": 10}
labelratio = [0.01, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 1]
for ratio in labelratio:
    print(f"usfSeen有标签的比例 ratio={ratio}......")
    # ############ 初始训练数据集 ###################################
    X0, Y0, label_state0 = loadalpha_data(0, 0.01)  # 初始训练集

    all_sample_instance = []
    for i in range(X0.shape[0]):
        all_sample_instance.append(X0[i])
    n = X0.shape[0]
    original_time1 = time.time()
    detector = SdndcForest(fea=X0)
    model = usfSeenLP(options)
    print(f"usfSeen的初始模型时间 time={time.time() - original_time1:.4f}s")

    X, Y, label_state = loadalpha_data1(1, 0.01)
    print("~~~~~~~运行到usfSeen了~~~~~~~~~~")
    proid_time1 = time.time()
    usfSeen(X, Y, label_state, model, detector, all_sample_instance)
    print(f"usfSeen的运行时间 time={time.time() - proid_time1:.4f}s")



