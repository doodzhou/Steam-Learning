import numpy as np
import time
from usfSeen2 import config
import math


class Node:
    def __init__(self, fea=None, selected_fea=None,
                lson=None, rson=None, s_value=0, root_dist=0, size=0):
        self.fea = fea  # feature vector
        # self.center = center  # the center of current node
        # self.radius = radius  # the range that current node covers
        self.selected_fea = selected_fea  # selected feature id to divide instances
        self.s_value = s_value
        self.size = size  # number of instances in the node 节点中的实例数
        # self.lcenter = lcenter  # center of k-means for left son tree
        # self.rcenter = rcenter  # center of k-means for right son tree
        self.lson = lson  # left son id
        self.rson = rson  # right son id
        self.label = []
        self.root_dist = root_dist  # distance between current node and root node, namely the depth of current node


class SdndcTree:
    def __init__(self, fea=None):
        self.fea = fea  # all feature vector of current tree
        # self.Y = Y
        # self.label_state = label_state
        self.tree_size = config.tree_size  # number of nodes of current tree, which is fixed in advance

        # self.k_fea = (fea.shape[1] + 1) // 2  # number of randomly selected features to divide instances
        self.max_height = int(np.ceil(np.log2(self.tree_size)))  # maximum tree height, which is fixed in advance

        self.min_leaf_size = config.min_leaf_size  # minimum instances in leaf node, which is fixed in advance

        self.nodes = []  # store each nodes
        # self.leaf_type = [0, 0, 0, 0]
        self.root = self.build_tree(fea, 0)  # build tree

        self.leaf_dist = []
        self.node_dist = []
        for node in self.nodes:
            self.node_dist.append(node.root_dist)
        self.node_dist_mean = np.mean(self.node_dist)

    def same_fea_preds(self, fea):
        n, dim1 = fea.shape[0], fea.shape[1]
        for i in range(1, n):
            if sum(fea[i] == fea[0]) != dim1:  # 当fea[i]的每一项都与fea[0]相同时，sum(fea[i] == fea[0])就等于数据的维度
                return False
        return True

    def get_distance(self, x1, x2):
        # assert 用来声明哪个条件为真
        assert x1.shape == x2.shape, "x1.shape = {} x2.shape = {}".format(x1.shape, x2.shape)
        distance_node = np.linalg.norm(x1 - x2) ** 2
        return distance_node

    # ###############################为一个结点构造超球###############################
    def sigleball(self, node, curIndex):
        curpoint = node[curIndex, :]  # data的第curIndex行的数据值
        r = float("inf")
        # NNpoint = np.zeros(shape=(1, curpoint.shape[1]))
        index = 0
        for inode in range(len(node)):
            if inode == curIndex:  # 当i == curIndex时，说明是计算的是自己到自己的距离
                continue

            else:
                dis = self.get_distance(curpoint, node[inode, :])  # 第curpoint点与其他数据之间的距离
            if dis < r:
                r = dis
                # NNpoint = node[inode, :]  # 与curpoint点的最近邻点
                # index = inode

        return curpoint, r

    def hyperSphere(self, data_fea):
        B = [[] for _ in range(2)]
        # B = np.zeros(shape=(data_fea.shape[0],2))
        for idata in range(data_fea.shape[0]):
            curpoint, r = self.sigleball(data_fea, idata)

            # print("curpoint, r", curpoint, r)
            B[0].append(curpoint)
            B[1].append(r)
                # B[idata, 1] = r
        # print("B",B)
        return B

    def create_leaf(self, fea, height, n):
        leaf = Node(fea=fea, root_dist=height, size=n)
        x = fea

        # leaf.center = self.hyperSphere(x)
        return leaf

    def build_tree(self, fea, height):
        """
        input:fea:输入的数据
              height:初始树高--最初设置为1
        output:self.node_dist:每个叶节点到根节点的距离
               self.node_dist_mean: 结点到根节点的平均距离
               self.leaf_dist:每个叶节点内部的距离构成超球
               self.root: 每个结点作为根节点，向下分裂 [[79, 71, 1], [44, 35, 2], [24, 20, 3], [19, 16, 3], [47, 24, 2], [28, 19, 3], [17, 11, 4]]
        """
        cur = len(self.nodes)  # 总共被分了几个结点
        n, dim1 = fea.shape[0], fea.shape[1]
        if height >= self.max_height or n <= self.min_leaf_size or self.same_fea_preds(fea):
            if n == 0:
                return None
            elif n == 1:
                # assert (center_parent is not None)
                self.nodes.append(Node(fea=fea,
                                       root_dist=height, size=n))
            else:
                self.nodes.append(self.create_leaf(fea, height, n))
            return cur

        inter_node = Node(fea=fea, root_dist=height, size=n)
        # inter_node.node_infor = self.hyperSphere(fea)
        # inter_node.center = self.hyperSphere(fea)
        # inter_node.radius = 0
        inter_node.selected_fea = np.random.choice(dim1, 1)
        sort = sorted(fea[:, inter_node.selected_fea])  # 对S的select_dim属性进行排序
        s = (sort[n // 2] + sort[1 + n // 2]) / 2
        inter_node.s_value = s

        inter_node.lcenter = np.mean(fea[np.where(fea[:, inter_node.selected_fea] <= s)[0]], axis=0)
        inter_node.rcenter = np.mean(fea[np.where(fea[:, inter_node.selected_fea] > s)[0]], axis=0)

        left_son, right_son = [], []
        for i in range(n):
            x_i = fea[i, :]
            dis1 = self.get_distance(x_i, inter_node.lcenter)
            dis2 = self.get_distance(x_i, inter_node.rcenter)
            if dis1 <= dis2:
                left_son.append(i)
            else:
                right_son.append(i)
            #  fea[i, inter_node.selected_fea] <= s:
             #   left_son.append(i)
            # else:
            #    right_son.append(i)
            # if label_state[i] == 1:
            # inter_node.label.append(Y[i])
        # print("left_son,right_son",len(left_son),len(right_son))
        self.nodes.append(inter_node)
        self.nodes[cur].lson = self.build_tree(fea[left_son, :], height + 1)
        self.nodes[cur].rson = self.build_tree(fea[right_son, :], height + 1)
        return cur

    def predict1(self, x_fea):
        cur_index = self.root
        height = 0
        # print("cur_index",cur_index)
        while self.nodes[cur_index].lson is not None or self.nodes[cur_index].rson is not None:
            num = 0
            cur_node = self.nodes[cur_index]
            dim = cur_node.fea.shape[1]
            select_featrue = np.random.choice(dim, dim//3)
            select_featrue = sorted(select_featrue)
            cur_node.fea = cur_node.fea[:, select_featrue]
            x = x_fea[select_featrue]
            # print("cur_node.center[0]",cur_node.fea)
            B = self.hyperSphere(cur_node.fea)
            for ix in range(len(B[0])):
                dis = self.get_distance(x, B[0][ix])
            # print("dis, cur_node.center[1][ix]",dis, cur_node.center[1][ix])
                if dis <= B[1][ix]:
                    continue
                if dis > B[1][ix]:
                    num = num + 1
            if num == len(B[0]):
                height = cur_node.root_dist
                break
            if cur_node.lson != None and cur_node.rson != None:
                tx = x_fea[cur_node.selected_fea]
                # dis1 = self.get_distance(tx, cur_node.lcenter)
                # dis2 = self.get_distance(tx, cur_node.rcenter)
                if tx <= cur_node.s_value:
                    cur_index = cur_node.lson
                else:
                    cur_index = cur_node.rson
            elif cur_node.lson != None:
                cur_index = cur_node.lson
            else:
                cur_index = cur_node.rson
            height = cur_node.root_dist
        # print("height",height)
        # print("self.node_dist_mean",self.node_dist_mean)
        return height < int(self.node_dist_mean)

    def predict(self, x_fea):
        global y_label
        cur_index = self.root
        height = 0
        # print("cur_index",cur_index)
        while self.nodes[cur_index].lson is not None or self.nodes[cur_index].rson is not None:
            num = 0
            cur_node = self.nodes[cur_index]
            x = x_fea
            # print("cur_node.center[0]",cur_node.fea)
            # B = self.hyperSphere(cur_node.fea)
            center = np.mean(cur_node.fea, axis=0)
            radius = 0
            for i in range(len(cur_node.fea)):
                d = self.get_distance(cur_node.fea[i], center)
                if d > radius:
                    radius = d
            # for ix in range(len(B[0])):
            dis = self.get_distance(x, center)
                # print("dis, cur_node.center[1][ix]",dis, cur_node.center[1][ix])
            if dis >= radius:
                # height = cur_node.root_dist
                break
            else:
                height = cur_node.root_dist + np.log2(cur_node.root_dist)
            if cur_node.lson != None and cur_node.rson != None:
                # tx = x_fea[cur_node.selected_fea]
                tx = x_fea
                dis1 = self.get_distance(tx, cur_node.lcenter)
                dis2 = self.get_distance(tx, cur_node.rcenter)
                # if tx <= cur_node.s_value:
                if dis1 <= dis2:
                    cur_index = cur_node.lson
                else:
                    cur_index = cur_node.rson
            elif cur_node.lson != None:
                cur_index = cur_node.lson
            else:
                cur_index = cur_node.rson
            height = height+1
            # y_label = max(cur_node.label, key=cur_node.label .count)
        # print("height",height)
        # print("self.node_dist_mean",self.node_dist_mean)
        return height < int(self.node_dist_mean+1)


# ###############################构造SDNDCS森林###########################################
class SdndcForest:
    def __init__(self, fea=None):
        self.fea = fea  # all feature vector of current tree
        self.tree_size = config.tree_size  # number of nodes of current tree, which is fixed in advance
        # 当前树的节点数，预先确定
        self.tree_size = min(fea.shape[0], config.tree_size)
        self.max_trees = config.max_tree
        self.build_forest()

    def update(self, samples):
        samples = np.array(samples)
        self.fea = samples.copy()
        self.build_forest()

    # 选取样本
    def select_samples(self):
        n = self.fea.shape[0]  # 数据集的大小
        assert n >= self.tree_size
        selected = np.random.choice(n, self.tree_size, replace=False)  # 选择的是序列号array([1, 0, 3])
        selected = sorted(selected)  # 把序列号排序
        return selected

    def build_forest(self):
        self.forest = []
        for tree_id in range(self.max_trees):
            selected_id = self.select_samples()
            selected_fea = self.fea[selected_id, :]
            cur_tree = SdndcTree(selected_fea)
            self.forest.append(cur_tree)

    def xpredict(self, x_fea):
        ret = np.zeros((self.max_trees, 1), dtype=bool)
        for i in range(self.max_trees):
            cur_ret = self.forest[i].predict(x_fea)
            ret[i] = cur_ret
        # print(ret)
        # print(sum(ret) > self.max_trees // 2)
        return sum(ret) > self.max_trees // 2


from sklearn import datasets

if __name__ == "__main__":
    iris = datasets.load_iris()
    fea = iris.data
    # leaf_node=[]
    x_fea = np.array([5.7, 2.5, 5.0, 2.0])
    fea_labeled = np.array([[5.0, 3.6, 1.4, 0.2, 1],
                            [5.4, 3.7, 1.5, 0.2, 1],
                            [5.0, 3.5, 1.3, 0.3, 1],
                            [5.0, 3.5, 1.6, 0.6, 1],
                            [6.3, 3.3, 4.7, 1.6, 2],
                            [5.0, 2.0, 3.5, 1.0, 2],
                            [6.7, 3.1, 4.4, 1.4, 2],
                            [6.0, 2.9, 4.5, 1.5, 2],
                            [7.1, 3.0, 5.9, 2.1, 3],
                            [5.7, 2.5, 5.0, 2.0, 3],
                            [6.1, 3.0, 4.9, 1.8, 3],
                            [7.7, 3.0, 6.1, 2.3, 3],
                            [6.7, 3.1, 5.6, 2.4, 3],
                            [5.6, 2.7, 4.2, 1.3, 2],
                            [5.0, 3.2, 1.2, 0.2, 1],
                            [5.0, 3.5, 1.3, 0.3, 1]])
    # node_dist_mean = tree.build_tree(fea, 1)
    # statues = tree.labeled_tree(fea_labeled)
    # max_height, lmax, rmax = tree.getmax_tree()
    # tree.predict(x_fea)
    # Tree = SdndcTree(fea)
    SdndcForest = SdndcForest(fea)
    SdndcForest.build_forest()
    SdndcForest.xpredict(x_fea)
    # print(SdndcForest.fea_labeled)
    # SdndcForest.buildforest()
    # SdndcForest.xevery_tree( x_fea)

    # statues = SdndcForest.labeled_tree()
    # SdndcForest.build_forest(x_fea)
    # SdndcForest.judge(x_fea)
    # x_fea = np.array([4.9,3.1,1.5,0.2])
