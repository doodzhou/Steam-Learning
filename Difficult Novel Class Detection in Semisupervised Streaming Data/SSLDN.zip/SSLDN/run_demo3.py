# -*- coding: utf-8 -*-

import pandas as pd
from usfSeen2.SdndcForest2 import *
from usfSeen2.SdndcLP4 import *

import time
import numpy as np
from sklearn.metrics import precision_score, recall_score, accuracy_score

import warnings
warnings.filterwarnings('ignore')
np.random.seed(0)  # for demo reproducibility


def evaluate_acc_f1(truth, preds):
    acc = accuracy_score(truth, preds)
    precision = precision_score(truth, preds, average='macro')
    recall = recall_score(truth, preds, average='macro')
    f1 = 2 * precision * recall / (precision + recall)

    print(f"acc={acc:.4f} f1={f1:.4f}")


def load_data1(period_num, ratio):
    file_name = 'E://tow-paper//datasets//MNIST/' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)-1):
        if period_num == 1:
            bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
            label_state[0:2] = 1
        else:
            bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


def load_data(period_num, ratio):
    file_name = 'E://tow-paper//datasets//MNIST//' + str(period_num) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1]-1]
    Y = data[:, data.shape[1]-1]
    label_state = np.zeros((len(Y), 1))
    # fore_index = 3
    # now_index = fore_index + period_num - (period_num-1)
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)):
        bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


if __name__ == '__main__':
    outlier_buffer_size = 80  # 异常值缓冲区的大小
    options = {"lambda_": 12, "k": 1, "max_loop_times": 10}
    all_truth = []
    all_preds = []
    # update_outlier = False
    time_begin = time.time()
    X0, Y0, label_state0 = load_data(0, 0.1)  # 初始训练集
    all_sample_instance = []
    for i in range(X0.shape[0]):
        all_sample_instance.append(X0[i])
    detector = SdndcForest(fea=X0)
    n = X0.shape[0]
    # label_num = sum(label_state0)
    # unlabel_num = n - label_num
    # all_sample_instance = []
    # model = SeenLP(options)
    # for i in range(n):
    #    if label_state0[i] == 1:
    #        model.add_label_sample(X0[i], Y0[i])
    # model = SeenLP(options, label_data0, know_label0)
    detector_begin = time.time()
    model = usfSeenLP(options)
    for period in range(1, 9):
        print(f"------ period: {period} ", end=" ")
        # model = SeenLP(options)
        period_begin = time.time()
        outlier_buffer = []
        newclass = []
        period_pred = []
        period_truth = []
        outlier_num = 0
        update_outlier = False
        X, Y, label_state = load_data1(period, 0.1)
        # model = SeenLP(options)
        # all_label_data = label_dat
        all_truth.append(Y)  # 无标签数据，所有的真实标签
        period_truth.append(Y.tolist())  # 每一个时期的真实标签
        ui = np.unique(Y)  # 每个时期的标签有哪些[1,2,3]
        for iu in range(X.shape[0]):
            ret = False
            if label_state[iu] == 1:
                model.add_label_sample(X[iu], Y[iu])
                period_pred.append(Y[iu])
                all_preds.append(Y[iu])
            else:
                if update_outlier:
                    y_label = model.run(X[iu])
                    cur_pred = y_label.tolist()[0]
                    if ui[0] == 1:
                        cur_pred = cur_pred + 1
                else:
                    ret = detector.xpredict(X[iu])
                    if ret:  # 如果ret为True,则为新类
                        outlier_buffer.append(X[iu])
                        # all_sample_instance.append(unlabel_data[iu])
                        newclass.append(max(ui))
                        cur_pred = max(ui)  # 新类的标签为在原来最大值的类的标签上加1
                        outlier_num += 1
                    else:  # 如果ret为False，则为已知类
                        y_label = model.run(X[iu])
                        cur_pred = y_label.tolist()[0]
                        if ui[0] == 1:
                             cur_pred = cur_pred + 1
                all_preds.append(cur_pred)  # 存放所有预测的标签
                period_pred.append(cur_pred)  # 存放每个时期预测的标签
                all_sample_instance.append(X[iu])  # 添加这个时期的判断过的无标签的样本

            if update_outlier == False and outlier_num == outlier_buffer_size:
                updata_time1 = time.time()
                outlier_num = 0
                # ui = np.insert(ui, len(ui), max(ui) + 1, axis=0)  # 已知标签更新[1,2,3,4]
                # outlier_buffer = np.array(outlier_buffer)
                # new_label_data = np.insert(outlier_buffer, outlier_buffer.shape[1], len(ui), axis=1)
                # selected_outlier_num = int(len(outlier_buffer) * 0.04)
                selected_outlier_num = 4
                model.update_outlier(outlier_buffer, ui[-1], selected_outlier_num)
                detector.update(all_sample_instance)
                # outlier_buffer = []
                update_outlier = True
                print(f"usfseen的更新时间 time={time.time() - updata_time1:.4f}s")
        # model.reserve_sample()
        print(f"time={time.time() - period_begin:.3f}s")
        evaluate_acc_f1(period_truth[0], period_pred)
        if update_outlier == False:
            outlier_num = 0
            print("开始更新啦2")
            detector.update(all_sample_instance)
            # model = SeenLP(options, label_data, know_label)
            selected_outlier_num = 4
            model.update_outlier(outlier_buffer, ui[-1], selected_outlier_num)
            detector.update(all_sample_instance)
            # outlier_buffer = []
            update_outlier = True

    all_truth = sum(all_truth, [])
    evaluate_acc_f1(all_truth, all_preds)
    time_end = time.time() - time_begin
    print(f"time = {time_end:.3f}s")
    '''
    with open('all_preds.txt', 'a+', encoding='utf-8') as f:
        for data in all_preds:
            # 添加‘\n’用于换行
            f.write(str(data) + '\n')
        f.close()
    '''
















