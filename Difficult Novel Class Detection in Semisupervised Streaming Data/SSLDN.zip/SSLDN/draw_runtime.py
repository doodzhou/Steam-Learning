import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np

mpl.rcParams["font.sans-serif"] = ["SimHei"]
mpl.rcParams["axes.unicode_minus"] = False


SSLDN = [45.317, 54.831, 66.3542, 51.1731, 50.1501, 90.2893,  87.2041, 137.742]
SEEN = [65.7275, 72.6058, 81.5279, 80.2337, 91.1067, 142.3346, 94.0605, 146.0685]
SENNE = [86.5178, 129.8044, 138.7491, 103.3073, 145.501, 186.6712, 159.0882, 294.0847]
ORSSL = [95.6741, 123.3394, 182.3562, 146.53, 127.9092, 197.4907, 149.6493, 296.8614]
iForest = [8.8352, 10.0394, 13.8359, 9.4458,9.3552, 18.0012, 16.6302, 28.295]
LOF = [41.8227, 45.7994, 56.5293, 48.3667, 45.8394, 70.2746, 78.544, 100.7183]

# SSLDN = [15.317, 24.831, 36.3542, 21.1731, 20.1501, 40.2893,  57.2041, 107.742]
# SEEN = [35.7275, 42.6058, 51.5279, 50.2337, 61.1067, 132.3346, 64.0605, 116.0685]
# SENNE = [56.5178, 99.8044, 108.7491, 73.3073, 115.501, 156.6712, 129.0882, 294.0847]
# ORSSL = [65.6741, 93.3394, 152.3562, 116.53, 97.9092, 167.4907, 119.6493, 266.8614]
# iForest = [2.8352, 2.0394, 3.8359, 4.4458, 2.3552, 8.0012, 4.6302, 3.295]
# LOF=[11.8227, 15.7994, 26.5293, 18.3667, 15.8394, 40.2746, 38.544, 70.7183]


tick_label = ["satimage", "usps", "HAR", "pendigits", "MNIST-10K", "Fashion-MNIST", "MNIST", "NYTimes"]
# tick_label = ["1", "2", "3", "4", "5", "6", "7", "8"]
x = np.arange(len(tick_label))  # x轴刻度标签位置
width = 0.15  # 柱子的宽度
# hatch="-"
#F08080
# 计算每个柱子在x轴上的位置，保证x轴刻度标签居中
plt.bar(x - 2.5*width, SSLDN, width, label='SSLDN', color='#A2142F')
plt.bar(x - 1.5*width, SEEN, width, label='SEEN', color='#BF7F53')
plt.bar(x - 0.5*width, SENNE, width, label='SENNE', color='#EDB120')
plt.bar(x + 0.5*width, ORSSL, width, label='ORSSL', color='#0072BD')
plt.bar(x + 1.5*width, iForest, width, label='iForest', color='#15835E')
plt.bar(x + 2.5*width, LOF, width, label='LOF', color='#7E2F8E')
font2={'family':'Times New Roman','weight':'normal','size':20}
plt.ylabel('Time(CPU seconds)', fontsize=20,fontname="Times New Roman")
# plt.xlabel('Datasets', fontsize=20)
#plt.title('The runtime comparisons', fontsize=20)
# x轴刻度标签位置不进行计算
plt.xticks(x, labels=tick_label, fontsize=23, rotation=10,fontname="Times New Roman")
font1={'weight':'normal','size':20,'family':'Times New Roman'}
plt.legend(loc='upper left',prop=font1)

plt.show()
