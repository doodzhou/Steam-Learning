import numpy as np
from usfSeen2.SEEN.SeenLP import *
from usfSeen2.SEEN.SeenForest import *
from usfSeen2.SENNE.model import *
from usfSeen2.SNECMas.detector import *
from usfSeen2.ORSSL.initialmodel import *
from usfSeen2.duibisuanfa import *
import time
import warnings

warnings.filterwarnings('ignore')


def loadalpha_data1(period_num, ratio):
    file_name = 'E://tow-paper//datasets//NYTimes//' + 'varynumber_' + str(1) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    Y = data[:, data.shape[1] - 1]
    label_state = np.zeros((len(Y), 1))
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui) - 1):
        if period_num == 1:
            bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
            label_state[0:2] = 1
        else:
            bb = [k for k in range(len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


def loadalpha_data(period_num, ratio):
    file_name = 'E://tow-paper//datasets//NYTimes//' + 'varynumber_' + str(0) + '.txt'
    data = pd.read_csv(file_name, header=None)
    data = np.array(data)
    X = data[:, 0:data.shape[1] - 1]
    Y = data[:, data.shape[1] - 1]
    label_state = np.zeros((len(Y), 1))
    # fore_index = 3
    # now_index = fore_index + period_num - (period_num-1)
    label_state[0:2] = 1
    ui = np.unique(Y)
    for i in range(len(ui)):
        bb = [k for k in range(2, len(Y)) if Y[k] == ui[i]]
        label = np.random.choice(bb, int(len(bb) * ratio), replace=False)
        label = sorted(label)
        label_state[label] = 1
    label_state = label_state.flatten()

    return X, Y, label_state


options = {"lambda_": 12, "k": 1, "max_loop_times": 10}

# update_outlier = False
# ############ 初始训练数据集 ###################################
X0, Y0, label_state0 = loadalpha_data(0, 0.01)  # 初始训练集
traindata = np.concatenate((X0, Y0.reshape((len(Y0), 1))), axis=1)
# X0 = X0/10

# #####################usfSeen的开始时间，初始模型detector和model################
all_sample_instance = []
all_sample_weight = []
for i in range(X0.shape[0]):
    all_sample_instance.append(X0[i])
n = X0.shape[0]
# pairwise distances between all points
# D = pairwise_distances(X0)
# K-nearest neighbors distances for each point (by row)
# KNN = np.sort(D, axis=1)
# K-nearest neighbor indices for each points (by row)
# KNN_indices = np.argsort(D, axis=1)

original_time1 = time.time()
detector = SdndcForest(fea=X0)
model = usfSeenLP(options)
print(f"usfSeen的初始模型时间 time={time.time() - original_time1:.4f}s")
# ####################seen的开始时间，初始模型detector和model###################
all_truth = []
all_preds = []
gamma = 0.1
all_sample_instance2 = []
all_sample_weight = []
label_num = sum(label_state0)
unlabel_num = n - label_num
Xs = X0 # / 10  # MNIST-10K /100,剩下的数据集都是/10
original_time2 = time.time()
model2 = SeenLP(gamma=gamma)
for i in range(n):
    if label_state0[i] == 1:
        model2.add_labeled_sample(Xs[i], Y0[i])
    else:
        cur_preds = np.argmax(model2.predict(Xs[i]))
        all_preds.append(cur_preds)
        all_truth.append(Y0[i])

for i in range(X0.shape[0]):
    all_sample_instance2.append(Xs[i])
    all_sample_weight.append(1.0)

detector2 = SeenForest(fea=Xs)
model2 = SeenLP(gamma=gamma)
print(f"seen的初始模型时间 time={time.time() - original_time2:.4f}s")

# ##################senne的开始时间，初始模型model########################

num_samples = 100  # number of set
sample_size = 20  # subsample size for each set
CurtNumDim = X0.shape[1]
newclass_num = 1
train_num = 2
original_time3 = time.time()
model3 = model_SENNE(traindata, num_samples, sample_size, CurtNumDim)
print(f"senne的初始模型时间 time={time.time() - original_time3:.4f}s")
# ################# snecmas的开始时间，初始模型############################

'''
original_time4 = time.time()
global_mat, local_mat = getMatrixSketch(traindata)
threshold, Q = thres(traindata, global_mat)
print(f"snecmas的初始模型时间 time={time.time() - original_time4:.4f}s")
'''
# ################orssl的开始时间，初始模型##################################

train_cls_lb = np.unique(Y0)
num_cluster = 50
original_time5 = time.time()
model4 = initial_model_construction(traindata, train_cls_lb, num_cluster)
print(f"orssl的初始模型时间 time={time.time() - original_time5:.4f}s")

# ######################IForestKNN 的初始化############################
original_time6 = time.time()
clf = IsolationForest()
clf.fit(X0, n_samples=200)
Average_score = sum(clf.predict(X0)) / len(X0)
# knn = neighbors.KNeighborsClassifier()
# knn.fit(X0, Y0)

ssvm = svm.SVC()
ssvm.fit(X0, Y0)
print(f"IForestKNN的初始模型时间 time={time.time() - original_time6:.4f}s")

print("#########################所有方法的初始化结束啦！###########################")


print(f"------ period: ", end=" ")
X, Y, label_state = loadalpha_data1(1, 0.01)

print("~~~~~~~运行到usfSeen了~~~~~~~~~~")
proid_time1 = time.time()
usfSeen(X, Y, label_state, model, detector, all_sample_instance)
print(f"usfSeen的运行时间 time={time.time() - proid_time1:.4f}s")
print("~~~~~~~运行到seen了~~~~~~~~~~~~~")
X1 = X #/ 10
proid_time2 = time.time()
seen(X1, Y, label_state, model2, detector2, all_preds, all_truth, all_sample_instance2, all_sample_weight)
print(f"seen的运行时间 time={time.time() - proid_time2:.4f}s")

print("~~~~~~~运行到IForestKNN了~~~~~~~~~~~~~")
proid_time6 = time.time()
iforestknn(X, Y, label_state, clf, ssvm, Average_score)
print(f"IForestKNN的运行时间 time={time.time() - proid_time6:.4f}s")

print("~~~~~~~运行到LOFSVM了~~~~~~~~~~~~~")
proid_time7 = time.time()
lofsvm(X, Y, label_state, ssvm)  # , D, KNN, KNN_indices
print(f"LOFSVM的运行时间 time={time.time() - proid_time7:.4f}s")
# ##############senne##############
# 初始化模型，senne的初始化模型是根据上一个判断过的数据建立的
# ################到此初始模型建立完成###################3333

streamdata = X
streamdatalabel = Y
max_num = max(np.unique(streamdatalabel))
for i in range(len(streamdatalabel)):
    if streamdatalabel[i] == max_num:
        streamdatalabel[i] = 999
print("~~~~~~~运行到senne了~~~~~~~~~~~~~")
proid_time3 = time.time()
senne(train_num, streamdata, streamdatalabel, model3)
print(f"senne的运行时间 time={time.time() - proid_time3:.4f}s")
# #################################

'''
print("~~~~~~~运行到snecmas了~~~~~~~~~~~~~")
proid_time4 = time.time()
snecmas(X, Y, label_state, X0, global_mat, local_mat, threshold, Q)
print(f"snecmas的运行时间 time={time.time() - proid_time4:.4f}s")
'''

print("~~~~~~~运行到orssl了~~~~~~~~~~~~~")
proid_time5 = time.time()
no_label_data = np.ceil(1*len(Y)/100)
rno = np.random.choice(len(Y), int(no_label_data), replace=False)
testlabel_state = np.zeros((len(Y), 1))
testlabel_state[rno] = 1
testlabel_state = testlabel_state.tolist()
orssl(X, Y, testlabel_state, model4)
print(f"orssl的运行时间 time={time.time() - proid_time5:.4f}s")


