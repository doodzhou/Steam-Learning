function [indexKNN,kdist]=search_knn(dataset,k)
%用于搜索 k 个最近邻
%indxKNN为k个最近邻索引，kdist为最近邻距离
    kdtreeNS = KDTreeSearcher(dataset,'bucketsize',500);
    rows=size(dataset,1);
    indexKNN=zeros(rows,k);
    kdist=zeros(rows,k);
    for i=1:rows        
          [temp,d] = knnsearch(kdtreeNS,dataset(i,:),'k',k+1);
          indexKNN(i,:) = temp(2:end);
          kdist(i,:) = d(2:end);
    end    
