tic;
d=size(data,2);
data(:,1:d) = MinMaxNormalize(data(:,1:d));
mydata=[data(:,1:d) label(:,1)];%数据集数据和标签分开的代码
% d=size(data,2);
% %data(:,1:d) = MinMaxNormalize(data(:,1:d));
% N=size(data,1);
% n=round(0.01*N);
% mydata=[data(1:n,1:d) label(1:n,1)];%数据集数据和标签分开的代码
WindowLengthArr = [1000]';
for windowLengthIterator = 1:length(WindowLengthArr)
    wl= WindowLengthArr(windowLengthIterator);  

     [ri,E_num,D_num,F_num,N_num]= CED_FS(mydata,d,wl);  
end

toc;

