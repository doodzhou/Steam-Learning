function nb=search_rknn(indexKNN)
rows=size(indexKNN,1);
cols=size(indexKNN,2);
%clearvars nb dist value index;
nb=zeros(rows,1);% nb saves the number of accurrence
for i=1:rows
    for j=1:cols
        nb(indexKNN(i,j))=nb(indexKNN(i,j))+1;
    end
end


