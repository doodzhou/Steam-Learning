function NMI= performance(cluster,label )
%算法的功能主要计算的算法的评价指标NMI(标准互信息)
%cluster为1*k的元组, 每一个单元为一个聚类的结果   label为数据的真实标签n*1,每一行代表一个样本
NMI=0;
Ylabel=cell(1,length(unique(label(:,1))));%找到同一类的样本序号,并把序号保存到相应的数组元素中去
A=(unique(label))';%A为保存的是原样本的类标签的个数
for i=1:length(unique(label(:,1)))
    Ylabel{1,i}=(find(label(:,1)==A(i)))';
end
N=size(label,1);%样本的总数
sum1=0;
sum2=0;
sum3=0;
for i=1:size(cluster,2)   
    Ni=length(cluster{i});
    if Ni>0
       sum2=sum2+Ni*log(Ni/N);
    end
    for j=1:size(Ylabel,2)
        Nj=length(Ylabel{j});
        Nij=length(intersect(cluster{i},Ylabel{j}));%获取交集的数目
        if (Nij>0)&&(Ni>0)&&(Nj>0)
            sum1=sum1+Nij*log2(N*Nij/(Ni*Nj));
        end        
    end    
end
for j=1:size(Ylabel,2)
    Nj=length(Ylabel{j});
    if Nj>0
      sum3=sum3+Nj*log2(Nj/N);
    end
end
NMI=sum1/sqrt(sum2*sum3);%计算标准互信息
end