function  display_graph(s)
%FIND_MAX_WEIGHT 找s矩阵每行元素最大值 
[M,N]=size(s);
max_num = max(M, N);
temp = max_num - 1;
figure;
cla
set( gca, 'XTick', [], 'YTick', [] );
set( gca, 'TickLength', [0 0]);
box on
hold on;
xlim([-1, 2]);
ylim([-max_num, 1]);

% 绘制边
for i=1:M    
      smax=max(s(i,:)); 
      [~,j]=find(s(i,:)==smax); 
      if (0.5<=smax) && (smax<1)
   plot([0, 1], [(i - 1) * -temp/(M-1), (j - 1) * -temp/(N-1)], 'k', 'LineWidth', 2);
      end
      if smax==1
   plot([0, 1], [(i - 1) * -temp/(M-1), (j - 1) * -temp/(N-1)], 'r', 'LineWidth', 2);
      end
end
% 绘制点
scatter(zeros(1, M), 0:-temp/(M-1):-temp, 40, [217/255 83/255 25/255], 'filled');
scatter(ones(1, N), 0:-temp/(N-1):-temp, 40, [0 114/255 189/255], 'filled');
for i = 1: M
    text(-0.2, (i - 1) * -temp/(M-1), ['C_i_' num2str(i)]);
end
for j = 1: N
    text(1.1, (j - 1) * -temp/(N-1), ['C_j_' num2str(j)]);
end 
title('Bipartite graph');
end


