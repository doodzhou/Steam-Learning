function [ri,E_num,D_num,F_num,N_num]= CED_FS(X,d,winsize)%X带标签数据集，d数据维度
%新兴概念和概念漂移检测
RII=[];
currcluster=[];
sequence=0;
%X(:,1:d) = MinMaxNormalize(X(:,1:d));%数据集归一化
label=X(:,d+1);
E_num=[];
D_num=[];
F_num=[];
N_num=[];

% Sliding over data set（静态数据处理成特征流）
parts = round((size(X,2)-1)/winsize);%窗口个数
% lama=2;%预定义参数（超参数），可不要
% Sliding over data set（在数据集上滑行）
for i = 1 : parts%从第一个窗口到最后一个窗口的循环    
    beginincomming = (i-1)*winsize+1;
    sequence=sequence+1;    
    if i == parts&&mod(d,winsize)>=winsize/2
        endincomming = size(X,2)-1;
    else
        endincomming = i*winsize;%beginincomming,endincomming都是一个数
    end    
    incommingStream = X(:,beginincomming:endincomming);%用滑动窗口模拟特征流，incommingStream是窗口的数据
    %     Lambda=zeros(1,size(incommingStream,2));      
%         for f=1:size(incommingStream,2)%计算各个特征的权值
%             Lambda(f)=exp(-lama*( winsize-f));%winsize作为当前时间，f特征序号（我们认为时间步长等于特征序号）
%         end
dim=size(incommingStream,2);%窗口数据维度
    if sequence==1%第一次聚类
    [currcluster,currcenter, currk]=k_r_dpc(incommingStream);
    else
     %不保留/重用旧模型 
      pastcluster=currcluster;
      pastcenter=currcenter;
      pastk=currk;                 
%后面块聚类
 [currcluster,currcenter, currk]=k_r_dpc(incommingStream);
[s] = weight_s1(pastcluster,pastk,currcluster,currk);
%[s] = weight_s2(pastStream,pastcluster,pastcenter,pastk,incommingStream,currcluster,currcenter,currk,dim);
 display_graph(s);
 [M,N]=size(s);
 e_num=0;%统计发生新兴概念的次数
d_num=0;%统计发生概念漂移的次数
f_num=0;%统计发生概念遗忘的次数
n_num=0;%统计没有发生概念演化的次数
 for a=1:M    
      smax=max(s(a,:));
      [~,j]=find(s(a,:)==smax);
      if (0.5<=smax) && (smax<1)
    disp(['第',num2str(sequence),'块中序列为',num2str(j),'的簇相对于第',num2str(sequence-1),'块中序列为',num2str(a),'发生了概念漂移']);
     d_num=d_num+1;
      end
      if smax==1
   disp(['第',num2str(sequence),'块中序列为',num2str(j),'的簇相对于第',num2str(sequence-1),'块中序列为',num2str(a),'没有发生概念演化']);
      n_num=n_num+1;
      end
      if smax<0.5
   disp(['第',num2str(sequence-1),'块中序列为',num2str(a),'的簇发生了概念遗忘']);
   f_num=f_num+1;
      end
 end
 t=s';
for b=1:N
    tmax=max(t(b,:));  
      if tmax<0.5
   disp(['第',num2str(sequence),'块中序列为',num2str(b),'的簇发生了新兴概念']);
   e_num=e_num+1;
      end
end

         E_num=[E_num,e_num];
         D_num=[D_num,d_num];
         F_num=[F_num,f_num];
         N_num=[N_num,n_num];
    end%所有块聚类，漂移判断结束 
   
    pastStream = incommingStream;
    %此模块为对结果的评价
    RI = rand_index(currcluster, label);  
    disp(['第',num2str(i),'个块中','当聚类数目k=',num2str(currk),'时聚类的结果为:RI=',num2str(RI)]);   
    RII=[RII,RI];%[]里面的RII为之前结果，RI为最新结果 
end 
 ri=max(RII);
    disp(['聚类结果RII的最大值:ri=',num2str(ri)]);
end
        
    
        
       
        
        
       
            
      
    



