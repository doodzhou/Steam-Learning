figure(1);
plot(a(:,1), a(:,2),'k-o');
xlabel('window size')
ylabel('score')