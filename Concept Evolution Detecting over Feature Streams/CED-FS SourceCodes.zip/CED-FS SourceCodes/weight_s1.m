function [s] = weight_s1(pastcluster,pastk,currcluster,currk)
%使用簇中样本个数，计算past和curr的每个簇之间的权重
%计算聚类向量
s=[];
s1=[];
         pastcluster=pastcluster';        
         pastclu=cell(1,pastk);%pastclu为1*pastk的元组, 每一个单元为一个聚类的结果
         for j=1:pastk
             pastclu{j}=find(pastcluster(:,1)==j);%把聚类结果转化成元组
         end
         currcluster=currcluster';        
         currclu=cell(1,currk);%currclu为1*currk的元组, 每一个单元为一个聚类的结果
         for j=1:currk
             currclu{j}=find(currcluster(:,1)==j);%把聚类结果转化成元组
         end
%此时每一个簇被转换成一个元组
   for i=1:currk
    for j=1:pastk
        c_i=length(currclu{1,i});
        c_j=length(pastclu{1,j});
        c_ij=length(intersect(currclu{1,i},pastclu{1,j}));
        sc=(2*c_ij)/(c_i+c_j);
       s1=[s1,sc];  
    end 
    s=[s;s1];
   s1=[];
   end
   s=s';
end

