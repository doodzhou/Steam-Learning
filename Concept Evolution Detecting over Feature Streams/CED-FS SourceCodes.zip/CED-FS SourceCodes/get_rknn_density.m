function [rhos]=get_rknn_density(indexKNN,kdist)
%用于搜索逆K最近邻,计算局部密度
%indxKNN为k个最近邻索引，kdist为最近邻距离  
rows=size(indexKNN,1);
rhos=[];
nb=search_rknn(indexKNN);
%%
%     for i=1:rows        
%         nb=RkNNSearch(indexKNN);
%         rk=nb(i,1);
%         [m,n] = find(indexKNN==i);         % 返回行索引        
%         rkdist = (diag(kdist(m,n)))';   % 返回逆KNN距离
%         s=sum(rkdist);
%         p=rk./s;
%         rhos=[rhos,p];
%     end
%%
%%
%     for i=1:rows       
%          [m,n] = find(indexKNN==i);         % 返回行索引        
%          rkdist = (diag(kdist(m,n)))';   % 返回逆KNN距离
%          gaus = exp(-(rkdist) );
%          p = sum(gaus);
%          rhos=[rhos,p];
%     end
% %%
%%
    for i=1:rows        
        rk=nb(i,1);
        [m,n] = find(indexKNN==i);         % 返回行索引        
        rkdist = (diag(kdist(m,n)))';   % 返回逆KNN距离
        gaus = exp(-((rkdist./rk).^ 2));
        p = sum(gaus);
        rhos=[rhos,p];
    end
%%
%%
%     for i=1:rows
%         nb=RkNNSearch(indexKNN);
%         rk=nb(i,1);
%         [m,n] = find(indexKNN==i);         % 返回行索引        
%         rkdist = (diag(kdist(m,n)))';   % 返回逆KNN距离
%         rkdist=rkdist.^ 2;
%         d = sum(rkdist)./rk;
%        p = exp(-(d));     
%         rhos=[rhos,p];
%     end
%%
end
    
   
