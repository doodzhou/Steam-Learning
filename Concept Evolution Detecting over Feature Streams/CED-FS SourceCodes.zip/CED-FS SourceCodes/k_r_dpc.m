function  [cluster,ords, cluster_num]=k_r_dpc(data)
%data无标签数据集
%基于rknn和kpca的dpc聚类算法
choice  = 1;          % 1代表高斯核，2代表多项式核，3代表线性核,4代表指数核，5代表拉普拉斯核
 sigma=6;             % 核参数
 p=0.05;
[n,~]=size(data);
k=round(p*n);%KNN的参数
target_dimension = round(n/3);% KPCA后保留的维度
Y = k_pca(data, sigma, choice, target_dimension);
shapeset =Y;
[indexKNN,kdist]=search_knn(Y,k);
[rhos]=get_rknn_density(indexKNN,kdist);%局部密度ρ
distset = shapeset2distset(shapeset); 
[deltas, nneigh] = getderta(distset, rhos);%deltas
showDeltas(rhos, deltas);
    [min_rho, min_delta] = selectRect();
    filter = (rhos > min_rho) & (deltas > min_delta);
    cluster_num = sum(filter);
    fprintf('rho: %f, delta: %f, number of clusters: %i \n', min_rho, min_delta, cluster_num);
    ords = find(filter);
    cluster = zeros(size(rhos));
    color = 1;
    for i = 1:size(ords, 2)
        cluster(ords(i)) = color;
        color = color + 1;
    end
    [sorted_rhos, rords] = sort(rhos, 'descend');
    for i = 1:size(rords, 2)
        if cluster(rords(i)) == 0
            neigh_cluster = cluster(nneigh(rords(i)));
            assert(neigh_cluster ~= 0, 'neigh_cluster has not assign!');
            cluster(rords(i)) = neigh_cluster;
        end
    end
%     showColorShape(shapeset, cluster, cluster_num, ords);
%     
%     halo = cluster;
%     dc_filter = (distset ~= 0) & (distset < dc);%有疑问
%     elnum = size(distset, 1);
%     rhos_matrix = repmat(rhos', 1, elnum);
%     rhos_items = repmat(rhos, elnum, 1);
%     rho_filter = rhos_matrix > rhos_items;
%     cluster_filter = repmat(cluster', 1, elnum) ~= repmat(cluster, elnum, 1);
%     halo_filter = dc_filter & rho_filter & cluster_filter;
%     bord_rhos = zeros(size(halo_filter));
%     bord_rhos(halo_filter) = (rhos_matrix(halo_filter) + rhos_items(halo_filter)) / 2;
%     r = max(bord_rhos, [], 1);
%     c = max(bord_rhos, [], 2);
%     d = [r; c'];
%     e = max(d, [], 1);
%     [row, col, v] = find(e);
%     cluster_rho = zeros(cluster_num);
%     for i = col
%         if e(i) > cluster_rho(cluster(i))
%             cluster_rho(cluster(i)) = e(i);
%         end
%     end
%     for i = 1:elnum
%         if rhos(i) < cluster_rho(cluster(i))
%             halo(i) = 0;
%         end
%     end
%     showElementCount(cluster, halo, cluster_num);
%     showHaloShape(shapeset, cluster, halo, cluster_num, ords);
% end
