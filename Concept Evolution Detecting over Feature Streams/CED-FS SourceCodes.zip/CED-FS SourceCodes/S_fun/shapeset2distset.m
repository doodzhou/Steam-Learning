function distset = shapeset2distset(shapeset)
    distvar = pdist(shapeset, 'euclidean');
    distset = squareform(distvar);
end

