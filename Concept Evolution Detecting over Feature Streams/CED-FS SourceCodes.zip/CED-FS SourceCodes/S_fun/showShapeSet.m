function showShapeSet(shapeset)
    scrsz = get(0,'ScreenSize');
    figure('Position', [6 72 scrsz(3)/2. scrsz(4)/1.3]);
    subplot(2,2,1); 
    tt = plot(shapeset(:, 1), shapeset(:, 2), 'o', 'MarkerSize', 2, 'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'k');
    text = 'LoadShape';
    title (text, 'FontSize', 15.0);
    xlabel ('x');
    ylabel ('y');       
end
