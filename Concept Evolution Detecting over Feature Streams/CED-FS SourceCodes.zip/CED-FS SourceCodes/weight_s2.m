function [s] = weight_s2(pastdata,pastcluster,pastcenter,pastk,currdata,currcluster,currcenter,currk,dim)
%使用簇中样本个数，计算past和curr的每个簇之间的权重
%计算聚类向量
s=[];
s1=[];
         pastcluster=pastcluster';        
         pastclu=cell(1,pastk);%pastclu为1*pastk的元组, 每一个单元为一个聚类的结果
         for j=1:pastk
             pastclu{j}=find(pastcluster(:,1)==j);%把聚类结果转化成元组
         end
         currcluster=currcluster';        
         currclu=cell(1,currk);%currclu为1*currk的元组, 每一个单元为一个聚类的结果
         for j=1:currk
             currclu{j}=find(currcluster(:,1)==j);%把聚类结果转化成元组
         end
%此时每一个簇被转换成一个元组
   for i=1:currk
    for j=1:pastk
        index_currcenter=currcenter(1,i);%中心索引
        u1=currdata(index_currcenter,1:dim);%中心数据
        index_pastcenter=pastcenter(1,j);%中心索引
        u2=pastdata(index_pastcenter,1:dim);%中心数据
        Y=[u1;u2]';
        mult = 1;
        co = DRenyi_kNN_k_initialization(mult); 
        D = DRenyi_kNN_k_estimation(u1,u2,co);       
       s1=[s1,D];  
    end 
    s=[s;s1];
   s1=[];
   end
end
